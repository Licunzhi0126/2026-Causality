#!/usr/bin/env bash

# ============================================================
# Path configuration for network-only coarse-graining.
#
# Users usually only need to edit this file when changing input data.
# The package folder should be placed directly under:
#   /home/jovyan/work/CE/2026-Causality/
# ============================================================

# Package root and project root.
# Example:
# PROJECT_ROOT=/home/jovyan/work/CE/2026-Causality
# PKG_ROOT=/home/jovyan/work/CE/2026-Causality/network_only_coarse_grain

if [[ -n "${BASH_SOURCE[0]:-}" ]]; then
  THIS_FILE="${BASH_SOURCE[0]}"
else
  THIS_FILE="$0"
fi

THIS_DIR="$(cd "$(dirname "$THIS_FILE")" && pwd)"
PKG_ROOT="$(cd "$THIS_DIR/../.." && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "$PKG_ROOT/.." && pwd)}"

# Output root.
# All generated features, integrated networks, and model outputs will be saved under OUT_ROOT.
OUT_ROOT="${OUT_ROOT:-$PROJECT_ROOT/output/coarse_grain/scheme_A_PIJ}"

# Dataset root.
# Change this if your real data are stored in a different location.
DATA_ROOT="${DATA_ROOT:-/home/jovyan/public/datasets/Mouse-embryo/E1S1_domain_factory}"

# Required CCI network inputs.
# Format: scipy sparse .npz
# Shape: N x N spot-level network.
P11_FULL="${P11_FULL:-$DATA_ROOT/cci/spot/spot_heart_11.5_CCI_total.npz}"
P12_FULL="${P12_FULL:-$DATA_ROOT/cci/spot/spot_heart_12.5_CCI_total.npz}"

# Optional GRN spot-level feature inputs for CCI+GRN integrated mode.
# Format: CSV
# Rows: spots
# Columns: GRN / regulon / module features
# Row order must match the corresponding CCI network.
GRN_DIR="${GRN_DIR:-$OUT_ROOT/graph_nis_v40_feature_align/grn_aug_features_v48}"
GRN_F11="${GRN_F11:-$GRN_DIR/heart_11p5_grn_obs_features.csv}"
GRN_F12="${GRN_F12:-$GRN_DIR/heart_12p5_grn_obs_features.csv}"

# Optional coordinate files for visualization only.
COORD_DIR="${COORD_DIR:-$OUT_ROOT/graph_nis_v40_feature_align/coords_for_viz}"
COORD_T="${COORD_T:-$COORD_DIR/heart_11p5_xy.csv}"
COORD_TP="${COORD_TP:-$COORD_DIR/heart_12p5_xy.csv}"

export PROJECT_ROOT
export PKG_ROOT
export OUT_ROOT
export DATA_ROOT
export P11_FULL
export P12_FULL
export GRN_DIR
export GRN_F11
export GRN_F12
export COORD_DIR
export COORD_T
export COORD_TP

# Note:
# OUT_ROOT/graph_nis_v40_feature_align will be created automatically by the run scripts.
# However, GRN_F11 and GRN_F12 must point to existing CSV files if running CCI+GRN integrated mode.
