# Results Examples

This folder contains summary examples from clean reproduced runs.

These files are not complete model output directories.

## Files

- summary_cci_network_only_clean.txt
- summary_cci_grn_integrated_clean.txt

## What these summaries contain

Each summary includes:

- EI_micro
- EI_macro
- DeltaEI
- Lalign
- hardK
- Keff
- assignment matrix shapes
- active cluster sizes
- latent representation shapes
- saved output file names

## Complete outputs

Complete model outputs are saved under:

OUT_ROOT/graph_nis_v40_feature_align/

For example:

- routeA_k64_kl_networkonly_ei20_svd32_clean/
- routeA_k64_kl_networkonly_grnint_w02_ei20_svd32_clean/

The OUT_ROOT variable is configured in:

experiments/common/paths.sh
