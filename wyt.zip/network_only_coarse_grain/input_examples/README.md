# Input Examples

This folder contains input format examples only.

These files are not formal training data.

## Toy CCI network examples

- sample_11p5_CCI_total.npz
- sample_12p5_CCI_total.npz

These are small toy scipy sparse .npz files.  
They show the expected format of spot-level CCI networks.

Real CCI networks should be configured in:

experiments/common/paths.sh

Variables:

- P11_FULL
- P12_FULL

## Toy GRN feature examples

- sample_11p5_GRN_features.csv
- sample_12p5_GRN_features.csv

These are small toy CSV files.  
They show the expected format of spot-level GRN feature matrices.

Rows are spots.  
Columns are GRN / regulon / module features.

Real GRN feature paths should be configured in:

experiments/common/paths.sh

Variables:

- GRN_F11
- GRN_F12

## Real head examples

- real_11p5_GRN_features_head5x10.csv
- real_12p5_GRN_features_head5x10.csv

These are small previews from real GRN feature files.  
They only contain the first 5 rows and first 10 columns.

They are used only to show the real file style and column names.

## make_input_examples.py

This script generates the toy input examples in this folder.

It is not used in formal training.
