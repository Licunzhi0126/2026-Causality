#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import os
import numpy as np
import pandas as pd
import scipy.sparse as sp

OUT = Path(__file__).resolve().parent
rng = np.random.default_rng(7)

def make_row_normalized_network(n, density=0.45):
    A = rng.random((n, n)).astype(np.float32)
    mask = rng.random((n, n)) < density
    A = A * mask
    np.fill_diagonal(A, np.diag(A) + 0.05)
    A = A / (A.sum(axis=1, keepdims=True) + 1e-12)
    return sp.csr_matrix(A)

P11 = make_row_normalized_network(8, density=0.5)
P12 = make_row_normalized_network(7, density=0.5)

sp.save_npz(OUT / "sample_11p5_CCI_total.npz", P11)
sp.save_npz(OUT / "sample_12p5_CCI_total.npz", P12)

G11 = pd.DataFrame(
    rng.normal(size=(8, 5)).astype(np.float32),
    columns=["Regulon_A", "Regulon_B", "Regulon_C", "Module_1", "Module_2"],
)
G12 = pd.DataFrame(
    rng.normal(size=(7, 5)).astype(np.float32),
    columns=["Regulon_A", "Regulon_B", "Regulon_C", "Module_1", "Module_2"],
)

G11.to_csv(OUT / "sample_11p5_GRN_features.csv", index=False)
G12.to_csv(OUT / "sample_12p5_GRN_features.csv", index=False)

try:
    root = Path(os.environ["OUT_ROOT"]) / "graph_nis_v40_feature_align"
    grn_dir = root / "grn_aug_features_v48"

    real_items = [
        ("real_11p5_GRN_features_head5x10.csv", grn_dir / "heart_11p5_grn_obs_features.csv"),
        ("real_12p5_GRN_features_head5x10.csv", grn_dir / "heart_12p5_grn_obs_features.csv"),
    ]

    for out_name, p in real_items:
        if p.exists():
            df = pd.read_csv(p)
            df.iloc[:5, :10].to_csv(OUT / out_name, index=False)
            print("real sample saved:", out_name, df.iloc[:5, :10].shape)

except Exception as e:
    print("Skip real head samples:", e)

print("Toy samples saved to:", OUT)
print("sample_11p5_CCI_total.npz", P11.shape, "nnz", P11.nnz)
print("sample_12p5_CCI_total.npz", P12.shape, "nnz", P12.nnz)
print("sample_11p5_GRN_features.csv", G11.shape)
print("sample_12p5_GRN_features.csv", G12.shape)
