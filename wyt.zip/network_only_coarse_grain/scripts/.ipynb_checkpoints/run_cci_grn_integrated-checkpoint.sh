#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "$PKG_DIR/.." && pwd)}"

cd "$PROJECT_ROOT"

set -a
source "$PKG_DIR/experiments/common/paths.sh"
set +a

export PYTHONPATH="$PROJECT_ROOT:${PYTHONPATH:-}"

check_file() {
  if [[ ! -f "$1" ]]; then
    echo "[ERROR] Missing file: $1"
    echo "Please edit: $PKG_DIR/experiments/common/paths.sh"
    exit 1
  fi
}

check_file "$P11_FULL"
check_file "$P12_FULL"
check_file "$GRN_F11"
check_file "$GRN_F12"

ROOT="$OUT_ROOT/graph_nis_v40_feature_align"

INT_DIR="$ROOT/integrated_cci_grn_networks_clean"
FEAT_DIR="$ROOT/network_only_features_clean_integrated_grn"

RUN="routeA_k64_kl_networkonly_grnint_w02_ei20_svd32_clean"
OUT="$ROOT/$RUN"

mkdir -p "$INT_DIR" "$FEAT_DIR" "$OUT"

P11_INT="$INT_DIR/heart_11p5_cci_grn_w02_knn50_integrated.npz"
P12_INT="$INT_DIR/heart_12p5_cci_grn_w02_knn50_integrated.npz"
INT_META="$INT_DIR/heart_11p5_12p5_cci_grn_w02_knn50_meta.json"

F11_NET="$FEAT_DIR/heart_11p5_cci_grn_w02_networkonly_svd32_features.csv"
F12_NET="$FEAT_DIR/heart_12p5_cci_grn_w02_networkonly_svd32_features.csv"
FEAT_META="$FEAT_DIR/heart_11p5_12p5_cci_grn_w02_networkonly_svd32_meta.json"

echo "Project root: $PROJECT_ROOT"
echo "Package dir:  $PKG_DIR"
echo "P11_FULL:     $P11_FULL"
echo "P12_FULL:     $P12_FULL"
echo "GRN_F11:      $GRN_F11"
echo "GRN_F12:      $GRN_F12"
echo "Output dir:   $OUT"

{
  echo "=============================="
  echo "Step 1: build CCI+GRN integrated networks"
  echo "=============================="

  python "$PKG_DIR/scripts/build_integrated_cci_grn_network_v58.py" \
    --cci-t "$P11_FULL" \
    --cci-tp "$P12_FULL" \
    --grn-feature-t "$GRN_F11" \
    --grn-feature-tp "$GRN_F12" \
    --grn-weight 0.2 \
    --knn-k 50 \
    --out-t "$P11_INT" \
    --out-tp "$P12_INT" \
    --meta-out "$INT_META"

  echo "=============================="
  echo "Step 2: build network-only features from integrated networks"
  echo "=============================="

  python "$PKG_DIR/scripts/build_network_only_features_v57.py" \
    --pij-t "$P11_INT" \
    --pij-tp "$P12_INT" \
    --svd-dim 32 \
    --out-t "$F11_NET" \
    --out-tp "$F12_NET" \
    --meta-out "$FEAT_META"

  echo "=============================="
  echo "Step 3: train coarse-graining model"
  echo "=============================="

  python "$PKG_DIR/scripts/train_feature_align_deltaei_v40.py" \
    --pij-t "$P11_INT" \
    --pij-tp "$P12_INT" \
    --feature-t "$F11_NET" \
    --feature-tp "$F12_NET" \
    --k 64 \
    --hidden-dim 64 \
    --mid-dim 32 \
    --gnn-layers 2 \
    --macro-layers 2 \
    --knn-k 30 \
    --local-dims 2 \
    --temperature 0.07 \
    --pij-method kl \
    --pij-temperature 1.0 \
    --align-temperature 1.0 \
    --epochs 1500 \
    --lr 5e-4 \
    --lambda-align 1.0 \
    --lambda-ei 2.0 \
    --lambda-var 1.0 \
    --lambda-local 0.0 \
    --lambda-sharp 0.02 \
    --lambda-proto 0.2 \
    --lambda-min-usage 10.0 \
    --lambda-max-usage 10.0 \
    --embedding-target-std 0.05 \
    --prototype-max-cosine 0.2 \
    --min-usage-frac 0.01 \
    --max-usage-frac 8.0 \
    --log-every 50 \
    --out-dir "$OUT"

  echo "ALL DONE"
  echo "Output: $OUT"
} 2>&1 | tee "$OUT/train.log"
