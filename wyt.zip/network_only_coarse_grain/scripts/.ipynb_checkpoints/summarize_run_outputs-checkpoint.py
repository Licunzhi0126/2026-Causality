#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import re
from pathlib import Path

import numpy as np


def parse_log(log_path):
    txt = Path(log_path).read_text(errors="ignore")
    out = {}

    for key, name in [
        ("EI_micro fixed", "EI_micro"),
        ("EI_macro", "EI_macro"),
        ("Delta EI", "DeltaEI"),
    ]:
        vals = re.findall(rf"{re.escape(key)}:\s*([-+]?\d*\.\d+|\d+)", txt)
        out[name] = float(vals[-1]) if vals else None

    v4_lines = [x for x in txt.splitlines() if "[v4]" in x and "hardK=" in x]
    if v4_lines:
        last = v4_lines[-1]
        out["last_train_line"] = last

        m = re.search(r"Lalign=([-+]?\d*\.\d+|\d+)", last)
        out["Lalign_last"] = float(m.group(1)) if m else None

        m = re.search(r"hardK=\[([0-9]+),([0-9]+)\]", last)
        if m:
            out["hardK_t_train"] = int(m.group(1))
            out["hardK_tp_train"] = int(m.group(2))

        m = re.search(r"Keff=\[([0-9.]+),([0-9.]+)\]", last)
        if m:
            out["Keff_t_train"] = float(m.group(1))
            out["Keff_tp_train"] = float(m.group(2))

    return out


def summarize_assignment(path):
    S = np.load(path)
    labels = S.argmax(axis=1)
    counts = np.bincount(labels, minlength=S.shape[1])
    active = counts[counts > 0]

    return {
        "shape": list(S.shape),
        "hardK": int(len(active)),
        "min_size": int(active.min()),
        "max_size": int(active.max()),
        "mean_size": float(active.mean()),
        "mean_confidence": float(S.max(axis=1).mean()),
        "active_cluster_ids": np.where(counts > 0)[0].tolist(),
        "active_cluster_sizes": active.tolist(),
    }


def shape_or_missing(path):
    p = Path(path)
    if not p.exists():
        return "missing"
    arr = np.load(p)
    return list(arr.shape)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    args = ap.parse_args()

    rdir = Path(args.run_dir)

    print("=" * 80)
    print("Run directory:")
    print(rdir)
    print("=" * 80)

    log = rdir / "train.log"
    if log.exists():
        print("\n[Final metrics from train.log]")
        metrics = parse_log(log)
        for k, v in metrics.items():
            if k != "last_train_line":
                print(f"{k}: {v}")
        if "last_train_line" in metrics:
            print("\nLast training line:")
            print(metrics["last_train_line"])
    else:
        print("train.log missing")

    print("\n[Assignment matrices]")
    for fname in ["S_t.npy", "S_tp.npy"]:
        p = rdir / fname
        if p.exists():
            print("\n" + fname)
            d = summarize_assignment(p)
            for k, v in d.items():
                print(f"{k}: {v}")
        else:
            print(fname, "missing")

    print("\n[Latent feature outputs]")
    for fname in [
        "Z_micro_t.npy",
        "Z_micro_tp.npy",
        "Z_macro_t.npy",
        "Z_macro_tp.npy",
        "P_macro_t.npy",
        "P_macro_tp.npy",
    ]:
        print(fname + ":", shape_or_missing(rdir / fname))

    print("\n[All files]")
    for p in sorted(rdir.glob("*")):
        if p.is_file():
            print(p.name)


if __name__ == "__main__":
    main()
