#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

EPS = 1e-12


def row_normalize_np(P):
    P = np.asarray(P, dtype=np.float32)
    P[~np.isfinite(P)] = 0.0
    P = np.maximum(P, 0.0)
    rs = P.sum(axis=1, keepdims=True)
    zero = rs[:, 0] <= EPS
    if np.any(zero):
        P = P.copy()
        P[zero] = 1.0 / P.shape[1]
        rs = P.sum(axis=1, keepdims=True)
    return P / (rs + EPS)


def row_normalize_torch(P):
    P = torch.clamp(P, min=0.0)
    rs = P.sum(dim=1, keepdim=True)
    zero = rs[:, 0] <= EPS
    if torch.any(zero):
        P = P.clone()
        P[zero] = 1.0 / P.shape[1]
        rs = P.sum(dim=1, keepdim=True)
    return P / (rs + EPS)


def load_matrix(path):
    path = Path(path)
    if path.suffix == ".npy":
        P = np.load(path)
    elif path.suffix == ".csv":
        P = np.loadtxt(path, delimiter=",")
    elif path.suffix == ".npz":
        try:
            import scipy.sparse as sp
            P = sp.load_npz(path).toarray()
        except Exception:
            data = np.load(path)
            key = "arr_0"
            for cand in ["P", "pij", "Pij", "transition", "arr_0"]:
                if cand in data:
                    key = cand
                    break
            P = data[key]
    else:
        raise ValueError(f"Unsupported matrix file: {path}")
    P = np.asarray(P, dtype=np.float32)
    if P.ndim != 2 or P.shape[0] != P.shape[1]:
        raise ValueError(f"Matrix must be square, got {P.shape}")
    return row_normalize_np(P)


def load_feature(path):
    path = Path(path)
    if path.suffix == ".npy":
        X = np.load(path)
    elif path.suffix == ".csv":
        X = np.loadtxt(path, delimiter=",")
    else:
        raise ValueError(f"Unsupported feature file: {path}")
    X = np.asarray(X, dtype=np.float32)
    X[~np.isfinite(X)] = 0.0
    return X


def preprocess_route_a(X_t, X_tp, local_dims):
    X_t = X_t.copy().astype(np.float32)
    X_tp = X_tp.copy().astype(np.float32)
    X_all = np.vstack([X_t, X_tp])
    if local_dims > 0:
        Z = X_all[:, :local_dims]
        mean = Z.mean(axis=0, keepdims=True)
        std = Z.std(axis=0, keepdims=True)
        std[std < 1e-6] = 1.0
        X_all[:, :local_dims] = (Z - mean) / std
    n = X_t.shape[0]
    return X_all[:n].astype(np.float32), X_all[n:].astype(np.float32)


def fixed_pca_features(X_t, X_tp, mid_dim):
    X_all = np.vstack([X_t, X_tp]).astype(np.float64)
    mean = X_all.mean(axis=0, keepdims=True)
    std = X_all.std(axis=0, keepdims=True)
    std[std < 1e-8] = 1.0
    X_all = (X_all - mean) / std

    max_dim = min(X_all.shape[0] - 1, X_all.shape[1], mid_dim)
    if max_dim <= 0:
        raise ValueError("Cannot build PCA features.")

    _, _, Vt = np.linalg.svd(X_all, full_matrices=False)
    Z = X_all @ Vt[:max_dim].T

    if max_dim < mid_dim:
        pad = np.zeros((Z.shape[0], mid_dim - max_dim), dtype=np.float64)
        Z = np.hstack([Z, pad])

    n = X_t.shape[0]
    return Z[:n].astype(np.float32), Z[n:].astype(np.float32)


def build_knn_adj(X, k, local_dims):
    from sklearn.neighbors import NearestNeighbors

    Z = X[:, :local_dims] if local_dims > 0 else X
    n = Z.shape[0]
    kk = min(k + 1, n)
    nbrs = NearestNeighbors(n_neighbors=kk, metric="euclidean")
    nbrs.fit(Z)
    _, idx = nbrs.kneighbors(Z)

    A = np.zeros((n, n), dtype=np.float32)
    for i in range(n):
        A[i, idx[i, 1:]] = 1.0

    A = np.maximum(A, A.T)
    np.fill_diagonal(A, 1.0)
    return row_normalize_np(A)


def effective_information(P):
    P = row_normalize_torch(P)
    avg = torch.clamp(P.mean(dim=0), min=EPS)
    H_y = -(avg * torch.log2(avg)).sum()
    P_safe = torch.clamp(P, min=EPS)
    H_cond = -(P_safe * torch.log2(P_safe)).sum(dim=1).mean()
    return H_y - H_cond


def cosine_pij(Z_t, Z_tp, temperature):
    A = F.normalize(Z_t, dim=1, eps=EPS)
    B = F.normalize(Z_tp, dim=1, eps=EPS)
    sim = A @ B.T
    return F.softmax(sim / temperature, dim=1)


def kl_pij(Z_t, Z_tp, temperature):
    P = F.softmax(Z_t, dim=1)
    Q = F.softmax(Z_tp, dim=1)
    P_safe = torch.clamp(P, min=EPS)
    Q_safe = torch.clamp(Q, min=EPS)

    logP = torch.log(P_safe)
    logQ = torch.log(Q_safe)

    cost = (P_safe[:, None, :] * (logP[:, None, :] - logQ[None, :, :])).sum(dim=2)
    return F.softmax(-cost / temperature, dim=1)


def make_pij(Z_t, Z_tp, method, temperature):
    if method == "cos":
        return cosine_pij(Z_t, Z_tp, temperature)
    if method == "kl":
        return kl_pij(Z_t, Z_tp, temperature)
    raise ValueError(f"Training PIJ method must be cos or kl, got {method}")


def sym_kl_feature(A, B, temperature):
    P = F.softmax(A / temperature, dim=1)
    Q = F.softmax(B / temperature, dim=1)
    P = torch.clamp(P, min=EPS)
    Q = torch.clamp(Q, min=EPS)
    kl_pq = (P * (torch.log(P) - torch.log(Q))).sum(dim=1).mean()
    kl_qp = (Q * (torch.log(Q) - torch.log(P))).sum(dim=1).mean()
    return 0.5 * (kl_pq + kl_qp)


def pool_to_macro(Z_micro_node, S):
    mass = S.sum(dim=0) + EPS
    return (S.T @ Z_micro_node) / mass.unsqueeze(1)


def macro_matrix(P_micro, S):
    return row_normalize_torch(S.T @ P_micro @ S)


def usage_stats(S):
    usage = torch.clamp(S.mean(dim=0), min=EPS)
    H = -(usage * torch.log(usage)).sum()
    Keff = torch.exp(H)
    return usage, Keff


def assignment_entropy(S):
    K = S.shape[1]
    S = torch.clamp(S, min=EPS)
    return (-(S * torch.log(S)).sum(dim=1).mean()) / math.log(K)


def variance_loss(H, target_std):
    std = torch.sqrt(H.var(dim=0) + EPS)
    return F.relu(target_std - std).mean()


def local_smoothness(S, A):
    return (S - A @ S).pow(2).sum(dim=1).mean()


def prototype_repulsion(C, max_cos):
    Cn = F.normalize(C, dim=1, eps=EPS)
    sim = Cn @ Cn.T
    mask = ~torch.eye(sim.shape[0], dtype=torch.bool, device=sim.device)
    return F.relu(sim[mask] - max_cos).pow(2).mean()


def usage_penalty(S_t, S_tp, min_frac, max_frac):
    K = S_t.shape[1]
    min_u = min_frac / K
    max_u = max_frac / K
    u_t, _ = usage_stats(S_t)
    u_tp, _ = usage_stats(S_tp)
    min_pen = 0.5 * (F.relu(min_u - u_t).pow(2).sum() + F.relu(min_u - u_tp).pow(2).sum())
    max_pen = 0.5 * (F.relu(u_t - max_u).pow(2).sum() + F.relu(u_tp - max_u).pow(2).sum())
    return min_pen, max_pen


class GraphConv(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.lin = nn.Linear(dim, dim)

    def forward(self, H, A):
        return self.lin(A @ H)


class PrototypeEncoder(nn.Module):
    def __init__(self, in_dim, hidden_dim, K, layers):
        super().__init__()
        self.in_proj = nn.Linear(in_dim, hidden_dim)
        self.layers = nn.ModuleList([GraphConv(hidden_dim) for _ in range(layers)])
        self.prototypes = nn.Parameter(torch.randn(K, hidden_dim) * 0.02)

    def embed(self, X, A):
        H = F.relu(self.in_proj(X))
        for layer in self.layers:
            H = F.relu(H + layer(H, A))
        return H

    def forward(self, X, A, temperature, return_embed=False):
        H = self.embed(X, A)
        logits = F.normalize(H, dim=1, eps=EPS) @ F.normalize(self.prototypes, dim=1, eps=EPS).T
        S = F.softmax(logits / temperature, dim=1)
        if return_embed:
            return S, H
        return S


class MacroFeatureNet(nn.Module):
    def __init__(self, K, hidden_dim, mid_dim, layers):
        super().__init__()
        self.in_proj = nn.Linear(K + 1, hidden_dim)
        self.layers = nn.ModuleList([GraphConv(hidden_dim) for _ in range(layers)])
        self.out = nn.Linear(hidden_dim, mid_dim)

    def forward(self, P_macro, mass):
        X = torch.cat([P_macro, mass.unsqueeze(1)], dim=1)
        A = row_normalize_torch(P_macro + torch.eye(P_macro.shape[0], device=P_macro.device))
        H = F.relu(self.in_proj(X))
        for layer in self.layers:
            H = F.relu(H + layer(H, A))
        return self.out(H)


def save_csv(path, rows):
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument("--pij-t", required=True)
    ap.add_argument("--pij-tp", required=True)
    ap.add_argument("--feature-t", required=True)
    ap.add_argument("--feature-tp", required=True)
    ap.add_argument("--k", type=int, required=True)

    ap.add_argument("--hidden-dim", type=int, default=64)
    ap.add_argument("--mid-dim", type=int, default=32)
    ap.add_argument("--gnn-layers", type=int, default=2)
    ap.add_argument("--macro-layers", type=int, default=2)
    ap.add_argument("--knn-k", type=int, default=30)
    ap.add_argument("--local-dims", type=int, default=2)

    ap.add_argument("--temperature", type=float, default=0.07)
    ap.add_argument("--pij-method", choices=["cos", "kl"], default="cos")
    ap.add_argument("--pij-temperature", type=float, default=1.0)
    ap.add_argument("--align-temperature", type=float, default=1.0)

    ap.add_argument("--epochs", type=int, default=1500)
    ap.add_argument("--lr", type=float, default=5e-4)

    ap.add_argument("--lambda-align", type=float, default=1.0)
    ap.add_argument("--lambda-ei", type=float, default=1.0)
    ap.add_argument("--lambda-var", type=float, default=1.0)
    ap.add_argument("--lambda-local", type=float, default=0.1)
    ap.add_argument("--lambda-sharp", type=float, default=0.02)
    ap.add_argument("--lambda-proto", type=float, default=0.2)
    ap.add_argument("--lambda-min-usage", type=float, default=10.0)
    ap.add_argument("--lambda-max-usage", type=float, default=10.0)

    ap.add_argument("--embedding-target-std", type=float, default=0.05)
    ap.add_argument("--prototype-max-cosine", type=float, default=0.2)
    ap.add_argument("--min-usage-frac", type=float, default=0.01)
    ap.add_argument("--max-usage-frac", type=float, default=8.0)

    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--log-every", type=int, default=50)
    ap.add_argument("--out-dir", required=True)

    args = ap.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    with open(out / "config.json", "w", encoding="utf-8") as f:
        json.dump(vars(args), f, indent=2)

    P_t_np = load_matrix(args.pij_t)
    P_tp_np = load_matrix(args.pij_tp)
    X_t_raw = load_feature(args.feature_t)
    X_tp_raw = load_feature(args.feature_tp)

    X_t_enc, X_tp_enc = preprocess_route_a(X_t_raw, X_tp_raw, args.local_dims)

    Z_micro_t_np, Z_micro_tp_np = fixed_pca_features(X_t_raw, X_tp_raw, args.mid_dim)

    A_t_np = build_knn_adj(X_t_enc, args.knn_k, args.local_dims)
    A_tp_np = build_knn_adj(X_tp_enc, args.knn_k, args.local_dims)

    device = torch.device(args.device)

    P_t = torch.tensor(P_t_np, dtype=torch.float32, device=device)
    P_tp = torch.tensor(P_tp_np, dtype=torch.float32, device=device)
    X_t = torch.tensor(X_t_enc, dtype=torch.float32, device=device)
    X_tp = torch.tensor(X_tp_enc, dtype=torch.float32, device=device)
    Z_micro_t = torch.tensor(Z_micro_t_np, dtype=torch.float32, device=device)
    Z_micro_tp = torch.tensor(Z_micro_tp_np, dtype=torch.float32, device=device)
    A_t = torch.tensor(A_t_np, dtype=torch.float32, device=device)
    A_tp = torch.tensor(A_tp_np, dtype=torch.float32, device=device)

    with torch.no_grad():
        PIJ_micro = make_pij(Z_micro_t, Z_micro_tp, args.pij_method, args.pij_temperature)
        EI_micro = effective_information(PIJ_micro)

    encoder = PrototypeEncoder(
        in_dim=X_t.shape[1],
        hidden_dim=args.hidden_dim,
        K=args.k,
        layers=args.gnn_layers,
    ).to(device)

    macro_net = MacroFeatureNet(
        K=args.k,
        hidden_dim=args.hidden_dim,
        mid_dim=args.mid_dim,
        layers=args.macro_layers,
    ).to(device)

    opt = torch.optim.Adam(
        list(encoder.parameters()) + list(macro_net.parameters()),
        lr=args.lr,
    )

    print("========== FeatureAlign-DeltaEI v4 ==========")
    print("P_t:", tuple(P_t.shape), "P_tp:", tuple(P_tp.shape))
    print("X_t:", tuple(X_t.shape), "X_tp:", tuple(X_tp.shape))
    print("K:", args.k, "mid_dim:", args.mid_dim)
    print("training PIJ method:", args.pij_method)
    print("fixed EI_micro:", f"{EI_micro.item():.6f}")
    print("No macro dynamics. No anti-coarsening. No reconstruction.")
    print("============================================")

    rows = []
    best_delta = -1e9

    for epoch in range(1, args.epochs + 1):
        encoder.train()
        macro_net.train()

        opt.zero_grad()

        S_t, H_t = encoder(X_t, A_t, args.temperature, return_embed=True)
        S_tp, H_tp = encoder(X_tp, A_tp, args.temperature, return_embed=True)

        P_macro_t = macro_matrix(P_t, S_t)
        P_macro_tp = macro_matrix(P_tp, S_tp)

        mass_t = S_t.mean(dim=0)
        mass_tp = S_tp.mean(dim=0)

        Z_macro_t = macro_net(P_macro_t, mass_t)
        Z_macro_tp = macro_net(P_macro_tp, mass_tp)

        Z_micro_pool_t = pool_to_macro(Z_micro_t, S_t)
        Z_micro_pool_tp = pool_to_macro(Z_micro_tp, S_tp)

        L_align_t = sym_kl_feature(Z_micro_pool_t.detach(), Z_macro_t, args.align_temperature)
        L_align_tp = sym_kl_feature(Z_micro_pool_tp.detach(), Z_macro_tp, args.align_temperature)
        L_align = 0.5 * (L_align_t + L_align_tp)

        PIJ_macro = make_pij(Z_macro_t, Z_macro_tp, args.pij_method, args.pij_temperature)
        EI_macro = effective_information(PIJ_macro)
        delta = EI_macro - EI_micro

        L_var = 0.5 * (
            variance_loss(H_t, args.embedding_target_std)
            + variance_loss(H_tp, args.embedding_target_std)
        )

        L_local = 0.5 * (
            local_smoothness(S_t, A_t)
            + local_smoothness(S_tp, A_tp)
        )

        L_sharp = 0.5 * (
            assignment_entropy(S_t)
            + assignment_entropy(S_tp)
        )

        L_proto = prototype_repulsion(encoder.prototypes, args.prototype_max_cosine)
        L_min, L_max = usage_penalty(S_t, S_tp, args.min_usage_frac, args.max_usage_frac)

        loss = (
            args.lambda_align * L_align
            - args.lambda_ei * delta
            + args.lambda_var * L_var
            + args.lambda_local * L_local
            + args.lambda_sharp * L_sharp
            + args.lambda_proto * L_proto
            + args.lambda_min_usage * L_min
            + args.lambda_max_usage * L_max
        )

        if not torch.isfinite(loss):
            raise RuntimeError("Non-finite loss")

        loss.backward()
        torch.nn.utils.clip_grad_norm_(
            list(encoder.parameters()) + list(macro_net.parameters()),
            5.0,
        )
        opt.step()

        u_t, Keff_t = usage_stats(S_t)
        u_tp, Keff_tp = usage_stats(S_tp)
        hardK_t = int(torch.unique(torch.argmax(S_t, dim=1)).numel())
        hardK_tp = int(torch.unique(torch.argmax(S_tp, dim=1)).numel())

        row = {
            "epoch": epoch,
            "loss": float(loss.detach().cpu()),
            "L_align": float(L_align.detach().cpu()),
            "L_align_t": float(L_align_t.detach().cpu()),
            "L_align_tp": float(L_align_tp.detach().cpu()),
            "EI_micro_fixed": float(EI_micro.detach().cpu()),
            "EI_macro": float(EI_macro.detach().cpu()),
            "delta_EI": float(delta.detach().cpu()),
            "L_var": float(L_var.detach().cpu()),
            "L_local": float(L_local.detach().cpu()),
            "L_sharp": float(L_sharp.detach().cpu()),
            "L_proto": float(L_proto.detach().cpu()),
            "L_min_usage": float(L_min.detach().cpu()),
            "L_max_usage": float(L_max.detach().cpu()),
            "Keff_t": float(Keff_t.detach().cpu()),
            "Keff_tp": float(Keff_tp.detach().cpu()),
            "hardK_t": hardK_t,
            "hardK_tp": hardK_tp,
            "usage_t_min": float(u_t.min().detach().cpu()),
            "usage_t_max": float(u_t.max().detach().cpu()),
            "usage_tp_min": float(u_tp.min().detach().cpu()),
            "usage_tp_max": float(u_tp.max().detach().cpu()),
        }
        rows.append(row)

        if row["delta_EI"] > best_delta:
            best_delta = row["delta_EI"]
            torch.save(
                {
                    "encoder": encoder.state_dict(),
                    "macro_net": macro_net.state_dict(),
                    "epoch": epoch,
                    "delta_EI": row["delta_EI"],
                },
                out / "best_model.pt",
            )

        if epoch == 1 or epoch % args.log_every == 0 or epoch == args.epochs:
            print(
                f"[v4] {epoch:04d} "
                f"loss={row['loss']:.6f} | "
                f"Lalign={row['L_align']:.6f} | "
                f"EI_macro={row['EI_macro']:.6f} | "
                f"delta={row['delta_EI']:.6f} | "
                f"Keff=[{row['Keff_t']:.1f},{row['Keff_tp']:.1f}] | "
                f"hardK=[{row['hardK_t']},{row['hardK_tp']}] | "
                f"usage_t=[{row['usage_t_min']:.4f},{row['usage_t_max']:.4f}] | "
                f"usage_tp=[{row['usage_tp_min']:.4f},{row['usage_tp_max']:.4f}]"
            )

    save_csv(out / "metrics.csv", rows)

    encoder.eval()
    macro_net.eval()

    with torch.no_grad():
        S_t, H_t = encoder(X_t, A_t, args.temperature, return_embed=True)
        S_tp, H_tp = encoder(X_tp, A_tp, args.temperature, return_embed=True)

        P_macro_t = macro_matrix(P_t, S_t)
        P_macro_tp = macro_matrix(P_tp, S_tp)

        mass_t = S_t.mean(dim=0)
        mass_tp = S_tp.mean(dim=0)

        Z_macro_t = macro_net(P_macro_t, mass_t)
        Z_macro_tp = macro_net(P_macro_tp, mass_tp)

        PIJ_macro = make_pij(Z_macro_t, Z_macro_tp, args.pij_method, args.pij_temperature)
        EI_macro = effective_information(PIJ_macro)
        delta = EI_macro - EI_micro

    np.save(out / "S_t.npy", S_t.cpu().numpy())
    np.save(out / "S_tp.npy", S_tp.cpu().numpy())
    np.save(out / "P_macro_t.npy", P_macro_t.cpu().numpy())
    np.save(out / "P_macro_tp.npy", P_macro_tp.cpu().numpy())
    np.save(out / "Z_micro_t.npy", Z_micro_t.cpu().numpy())
    np.save(out / "Z_micro_tp.npy", Z_micro_tp.cpu().numpy())
    np.save(out / "Z_macro_t.npy", Z_macro_t.cpu().numpy())
    np.save(out / "Z_macro_tp.npy", Z_macro_tp.cpu().numpy())
    np.save(out / "PIJ_micro_train.npy", PIJ_micro.cpu().numpy())
    np.save(out / "PIJ_macro_train.npy", PIJ_macro.cpu().numpy())

    print("========== Final ==========")
    print("EI_micro fixed:", f"{EI_micro.item():.6f}")
    print("EI_macro:", f"{EI_macro.item():.6f}")
    print("Delta EI:", f"{delta.item():.6f}")
    print("Saved to:", out)


if __name__ == "__main__":
    main()
