# Scripts Description

This folder contains all scripts used in the network-only coarse-graining pipeline.

## 1. build_network_only_features_v57.py

Purpose:
Build node features directly from input networks.

Input:
- P_t: spot-level network at time t
- P_tp: spot-level network at time t+1

Output:
- network-derived feature CSV for time t
- network-derived feature CSV for time t+1
- meta JSON file

Main feature components:
- 16 network summary statistics
- 32 outgoing row-profile SVD features
- 32 incoming column-profile SVD features

Total feature dimension:
80

Important:
This script does not use h5ad, spatial coordinates, domain labels, or external spatial-domain features.

## 2. build_integrated_cci_grn_network_v58.py

Purpose:
Build CCI+GRN integrated spot-level networks.

Input:
- CCI network at time t
- CCI network at time t+1
- spot-level GRN feature CSV at time t
- spot-level GRN feature CSV at time t+1

Main steps:
1. Load CCI networks.
2. Load GRN spot-level feature matrices.
3. Build GRN similarity networks using kNN and cosine similarity.
4. Integrate CCI network and GRN similarity network by weighted summation.
5. Save integrated networks as sparse .npz files.

Output:
- integrated network at time t
- integrated network at time t+1
- meta JSON file

Important:
The GRN CSV is not directly used as the final model feature. It is used to build a GRN similarity network first.

## 3. train_feature_align_deltaei_v40.py

Purpose:
Core coarse-graining training script.

Input:
- P_t / P_tp: input networks
- X_t / X_tp: network-derived node features
- K: number of macro nodes

Main learned objects:
- S_t: spot-to-macro assignment matrix at time t
- S_tp: spot-to-macro assignment matrix at time t+1
- Z_micro_t / Z_micro_tp: learned micro-level latent representations
- Z_macro_t / Z_macro_tp: learned macro-level latent representations

Main computed objects:
- P_macro_t = S_t^T P_t S_t
- P_macro_tp = S_tp^T P_tp S_tp
- EI_micro
- EI_macro
- DeltaEI = EI_macro - EI_micro

Output files:
- S_t.npy
- S_tp.npy
- Z_micro_t.npy
- Z_micro_tp.npy
- Z_macro_t.npy
- Z_macro_tp.npy
- P_macro_t.npy
- P_macro_tp.npy
- PIJ_micro_train.npy
- PIJ_macro_train.npy
- best_model.pt
- config.json
- metrics.csv
- train.log

## 4. run_cci_network_only.sh

Purpose:
Run the full CCI network-only pipeline.

Pipeline:
CCI networks
-> build_network_only_features_v57.py
-> train_feature_align_deltaei_v40.py
-> output coarse-graining results

Required input paths are configured in:
experiments/common/paths.sh

## 5. run_cci_grn_integrated.sh

Purpose:
Run the full CCI+GRN integrated network-only pipeline.

Pipeline:
CCI networks + GRN spot-level features
-> build_integrated_cci_grn_network_v58.py
-> build_network_only_features_v57.py
-> train_feature_align_deltaei_v40.py
-> output coarse-graining results

Required input paths are configured in:
experiments/common/paths.sh

This is the current main recommended pipeline.

## 6. summarize_run_outputs.py

Purpose:
Summarize a completed run directory.

Input:
- a run directory

Output:
- final EI metrics
- hardK and Keff
- assignment matrix shapes
- cluster sizes
- latent representation shapes
- list of saved files

## 7. visualize_spatial_assignments_v54_bigger_vivid.py

Purpose:
Optional visualization script.

Input:
- run directory containing S_t.npy and S_tp.npy
- coordinate CSV files for time t and time t+1

Output:
- hard assignment spatial map
- cluster size bar plot
- assignment entropy spatial map

Important:
This script is only for visualization. It is not required for training.
