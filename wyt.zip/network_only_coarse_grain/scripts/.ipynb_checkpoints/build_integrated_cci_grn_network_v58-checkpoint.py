#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Build CCI+GRN integrated spot-level networks.

Input:
  1. CCI network at t / tp
  2. GRN-derived spot-level feature at t / tp

Output:
  Integrated spot-level network at t / tp:
    P_integrated = (1 - grn_weight) * row_norm(CCI)
                 + grn_weight * row_norm(GRN_similarity_network)

This produces two network files, which can then be used by the network-only pipeline.
"""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler


EPS = 1e-12


def load_sparse_matrix(path):
    path = Path(path)
    try:
        return sp.load_npz(path).astype(np.float32).tocsr()
    except Exception:
        z = np.load(path, allow_pickle=True)
        if isinstance(z, np.lib.npyio.NpzFile):
            for k in ["P", "pij", "arr_0", "matrix", "data"]:
                if k in z.files:
                    arr = z[k]
                    return sp.csr_matrix(arr, dtype=np.float32)
            if len(z.files) == 1:
                return sp.csr_matrix(z[z.files[0]], dtype=np.float32)
            raise ValueError(f"Cannot infer matrix key from {path}; keys={z.files}")
        return sp.csr_matrix(z, dtype=np.float32)


def row_normalize_sparse(M):
    M = M.tocsr().astype(np.float32)
    M.data[~np.isfinite(M.data)] = 0.0
    M.data[M.data < 0] = 0.0
    row_sum = np.asarray(M.sum(axis=1)).ravel()
    inv = 1.0 / (row_sum + EPS)
    D = sp.diags(inv.astype(np.float32))
    return D @ M


def build_grn_similarity_network(X, k=50):
    """
    Build sparse kNN graph from GRN spot-level features using cosine similarity.
    """
    X = np.asarray(X, dtype=np.float32)
    X[~np.isfinite(X)] = 0.0

    X = StandardScaler().fit_transform(X).astype(np.float32)

    n = X.shape[0]
    k_eff = min(k + 1, n)

    nbrs = NearestNeighbors(n_neighbors=k_eff, metric="cosine", algorithm="auto")
    nbrs.fit(X)
    dist, ind = nbrs.kneighbors(X)

    rows = []
    cols = []
    vals = []

    for i in range(n):
        for d, j in zip(dist[i], ind[i]):
            if j == i:
                continue
            sim = max(0.0, 1.0 - float(d))
            if sim <= 0:
                continue
            rows.append(i)
            cols.append(j)
            vals.append(sim)

    G = sp.csr_matrix((vals, (rows, cols)), shape=(n, n), dtype=np.float32)

    # Symmetrize to avoid one-direction kNN artifacts
    G = G.maximum(G.T)

    return row_normalize_sparse(G)


def integrate_network(P_cci, P_grn, grn_weight):
    P_cci = row_normalize_sparse(P_cci)
    P_grn = row_normalize_sparse(P_grn)

    P = (1.0 - grn_weight) * P_cci + grn_weight * P_grn
    P = row_normalize_sparse(P)

    return P.tocsr().astype(np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cci-t", required=True)
    ap.add_argument("--cci-tp", required=True)
    ap.add_argument("--grn-feature-t", required=True)
    ap.add_argument("--grn-feature-tp", required=True)
    ap.add_argument("--grn-weight", type=float, default=0.2)
    ap.add_argument("--knn-k", type=int, default=50)
    ap.add_argument("--out-t", required=True)
    ap.add_argument("--out-tp", required=True)
    ap.add_argument("--meta-out", required=True)
    args = ap.parse_args()

    print("Loading CCI networks...")
    P_t = load_sparse_matrix(args.cci_t)
    P_tp = load_sparse_matrix(args.cci_tp)

    print("CCI P_t:", P_t.shape, "nnz:", P_t.nnz)
    print("CCI P_tp:", P_tp.shape, "nnz:", P_tp.nnz)

    print("Loading GRN spot-level features...")
    Gfeat_t = pd.read_csv(args.grn_feature_t).to_numpy(dtype=np.float32)
    Gfeat_tp = pd.read_csv(args.grn_feature_tp).to_numpy(dtype=np.float32)

    print("GRN feature t:", Gfeat_t.shape)
    print("GRN feature tp:", Gfeat_tp.shape)

    if Gfeat_t.shape[0] != P_t.shape[0]:
        raise ValueError(f"t shape mismatch: GRN {Gfeat_t.shape}, CCI {P_t.shape}")
    if Gfeat_tp.shape[0] != P_tp.shape[0]:
        raise ValueError(f"tp shape mismatch: GRN {Gfeat_tp.shape}, CCI {P_tp.shape}")

    print("Building GRN similarity networks...")
    Pgrn_t = build_grn_similarity_network(Gfeat_t, k=args.knn_k)
    Pgrn_tp = build_grn_similarity_network(Gfeat_tp, k=args.knn_k)

    print("GRN network t:", Pgrn_t.shape, "nnz:", Pgrn_t.nnz)
    print("GRN network tp:", Pgrn_tp.shape, "nnz:", Pgrn_tp.nnz)

    print("Integrating CCI + GRN...")
    Pint_t = integrate_network(P_t, Pgrn_t, args.grn_weight)
    Pint_tp = integrate_network(P_tp, Pgrn_tp, args.grn_weight)

    Path(args.out_t).parent.mkdir(parents=True, exist_ok=True)
    sp.save_npz(args.out_t, Pint_t)
    sp.save_npz(args.out_tp, Pint_tp)

    meta = {
        "cci_t": args.cci_t,
        "cci_tp": args.cci_tp,
        "grn_feature_t": args.grn_feature_t,
        "grn_feature_tp": args.grn_feature_tp,
        "grn_weight": args.grn_weight,
        "knn_k": args.knn_k,
        "out_t": args.out_t,
        "out_tp": args.out_tp,
        "shape_t": list(Pint_t.shape),
        "shape_tp": list(Pint_tp.shape),
        "nnz_t": int(Pint_t.nnz),
        "nnz_tp": int(Pint_tp.nnz),
        "note": "Integrated network = row-normalized weighted sum of CCI network and GRN-derived spot similarity network."
    }

    with open(args.meta_out, "w") as f:
        json.dump(meta, f, indent=2)

    print("Saved integrated t:", args.out_t, Pint_t.shape, "nnz:", Pint_t.nnz)
    print("Saved integrated tp:", args.out_tp, Pint_tp.shape, "nnz:", Pint_tp.nnz)
    print("Saved meta:", args.meta_out)


if __name__ == "__main__":
    main()
