#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Build network-derived node features only from two CCI/PIJ networks.

Input:
  P_t.npy/npz   : CCI network at time t
  P_tp.npy/npz  : CCI network at time t+1

Output:
  feature_t.csv
  feature_tp.csv

Feature type:
  1. network summary statistics
  2. outgoing row-profile SVD embedding
  3. incoming column-profile SVD embedding

No h5ad, no spatial coordinates, no domain labels.
"""

import argparse
import json
from pathlib import Path

import numpy as np
import scipy.sparse as sp
from sklearn.decomposition import TruncatedSVD


EPS = 1e-12


def load_matrix(path):
    path = Path(path)

    try:
        M = sp.load_npz(path)
        return M.toarray().astype(np.float32)
    except Exception:
        pass

    z = np.load(path, allow_pickle=True)

    if isinstance(z, np.lib.npyio.NpzFile):
        keys = z.files
        for k in ["P", "pij", "arr_0", "matrix", "data"]:
            if k in keys:
                arr = z[k]
                if sp.issparse(arr):
                    arr = arr.toarray()
                return np.asarray(arr, dtype=np.float32)

        if len(keys) == 1:
            arr = z[keys[0]]
            return np.asarray(arr, dtype=np.float32)

        raise ValueError(f"Cannot infer matrix key from {path}. keys={keys}")

    return np.asarray(z, dtype=np.float32)


def row_normalize(P):
    P = np.asarray(P, dtype=np.float32)
    P[~np.isfinite(P)] = 0.0
    P[P < 0] = 0.0
    s = P.sum(axis=1, keepdims=True)
    return P / (s + EPS)


def safe_entropy(prob):
    prob = np.asarray(prob, dtype=np.float32)
    n = prob.shape[1]
    ent = -np.sum(prob * np.log(prob + EPS), axis=1)
    return ent / (np.log(n + EPS) + EPS)


def topk_mass(prob, k):
    k = min(k, prob.shape[1])
    vals = np.partition(prob, -k, axis=1)[:, -k:]
    return vals.sum(axis=1)


def gini_like(x):
    x = np.asarray(x, dtype=np.float32)
    x_sorted = np.sort(x, axis=1)
    n = x.shape[1]
    idx = np.arange(1, n + 1, dtype=np.float32)
    denom = np.sum(x_sorted, axis=1) + EPS
    g = (2.0 * np.sum(idx[None, :] * x_sorted, axis=1)) / (n * denom) - (n + 1.0) / n
    return g


def summary_features(P):
    P = np.asarray(P, dtype=np.float32)
    n = P.shape[0]

    P_row = row_normalize(P)
    P_col = row_normalize(P.T)

    row_sum = P.sum(axis=1)
    col_sum = P.sum(axis=0)

    row_nnz = (P > 0).sum(axis=1) / max(1, P.shape[1])
    col_nnz = (P > 0).sum(axis=0) / max(1, P.shape[0])

    row_ent = safe_entropy(P_row)
    col_ent = safe_entropy(P_col)

    row_max = P_row.max(axis=1)
    col_max = P_col.max(axis=1)

    row_top5 = topk_mass(P_row, 5)
    row_top10 = topk_mass(P_row, 10)
    col_top5 = topk_mass(P_col, 5)
    col_top10 = topk_mass(P_col, 10)

    row_gini = gini_like(P_row)
    col_gini = gini_like(P_col)

    diag = np.diag(P) if P.shape[0] == P.shape[1] else np.zeros(P.shape[0], dtype=np.float32)

    if P.shape[0] == P.shape[1]:
        mutual = np.minimum(P, P.T).sum(axis=1) / (row_sum + EPS)
    else:
        mutual = np.zeros(P.shape[0], dtype=np.float32)

    F = np.vstack([
        np.log1p(row_sum),
        np.log1p(col_sum),
        row_nnz,
        col_nnz,
        row_ent,
        col_ent,
        row_max,
        col_max,
        row_top5,
        row_top10,
        col_top5,
        col_top10,
        row_gini,
        col_gini,
        diag,
        mutual,
    ]).T.astype(np.float32)

    names = [
        "log_out_strength",
        "log_in_strength",
        "out_density",
        "in_density",
        "out_entropy",
        "in_entropy",
        "out_max_prob",
        "in_max_prob",
        "out_top5_mass",
        "out_top10_mass",
        "in_top5_mass",
        "in_top10_mass",
        "out_gini",
        "in_gini",
        "self_loop",
        "reciprocal_mass",
    ]

    return F, names


def svd_features(P, n_components=32, random_state=0):
    n_components = min(n_components, min(P.shape) - 1)
    if n_components <= 0:
        return np.zeros((P.shape[0], 0), dtype=np.float32), []

    P_out = row_normalize(P)
    P_in = row_normalize(P.T)

    svd_out = TruncatedSVD(n_components=n_components, random_state=random_state)
    Z_out = svd_out.fit_transform(P_out)

    svd_in = TruncatedSVD(n_components=n_components, random_state=random_state)
    Z_in = svd_in.fit_transform(P_in)

    # canonicalize signs for reproducibility
    for Z in [Z_out, Z_in]:
        for j in range(Z.shape[1]):
            if Z[:, j].sum() < 0:
                Z[:, j] *= -1

    Z = np.hstack([Z_out, Z_in]).astype(np.float32)

    names = (
        [f"svd_out_{i}" for i in range(n_components)]
        +
        [f"svd_in_{i}" for i in range(n_components)]
    )

    return Z, names


def joint_zscore(X1, X2):
    X = np.vstack([X1, X2]).astype(np.float32)
    mu = np.nanmean(X, axis=0, keepdims=True)
    sd = np.nanstd(X, axis=0, keepdims=True) + 1e-6
    return (X1 - mu) / sd, (X2 - mu) / sd


def build_features(P, svd_dim):
    F_sum, names_sum = summary_features(P)
    F_svd, names_svd = svd_features(P, n_components=svd_dim)
    F = np.hstack([F_sum, F_svd]).astype(np.float32)
    names = names_sum + names_svd
    F[~np.isfinite(F)] = 0.0
    return F, names


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pij-t", required=True)
    ap.add_argument("--pij-tp", required=True)
    ap.add_argument("--svd-dim", type=int, default=32)
    ap.add_argument("--out-t", required=True)
    ap.add_argument("--out-tp", required=True)
    ap.add_argument("--meta-out", required=True)
    args = ap.parse_args()

    P_t = load_matrix(args.pij_t)
    P_tp = load_matrix(args.pij_tp)

    print("P_t:", P_t.shape)
    print("P_tp:", P_tp.shape)

    X_t, names_t = build_features(P_t, args.svd_dim)
    X_tp, names_tp = build_features(P_tp, args.svd_dim)

    if len(names_t) != len(names_tp):
        raise ValueError("feature name mismatch")

    X_t, X_tp = joint_zscore(X_t, X_tp)

    Path(args.out_t).parent.mkdir(parents=True, exist_ok=True)
    np.savetxt(args.out_t, X_t, delimiter=",", fmt="%.8g")
    np.savetxt(args.out_tp, X_tp, delimiter=",", fmt="%.8g")

    meta = {
        "pij_t": args.pij_t,
        "pij_tp": args.pij_tp,
        "feature_type": "network_only_summary_plus_svd",
        "svd_dim": args.svd_dim,
        "shape_t": list(X_t.shape),
        "shape_tp": list(X_tp.shape),
        "feature_names": names_t,
        "out_t": args.out_t,
        "out_tp": args.out_tp,
        "note": "Features are derived only from the input CCI/PIJ networks. No h5ad, no spatial domain, no external node feature."
    }

    with open(args.meta_out, "w") as f:
        json.dump(meta, f, indent=2)

    print("Saved feature_t:", args.out_t, X_t.shape)
    print("Saved feature_tp:", args.out_tp, X_tp.shape)
    print("Saved meta:", args.meta_out)


if __name__ == "__main__":
    main()
