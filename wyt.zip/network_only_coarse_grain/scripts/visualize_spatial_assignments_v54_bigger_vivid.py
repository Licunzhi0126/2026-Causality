import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap


VIVID_COLORS = [
    "#E41A1C",  # red
    "#377EB8",  # blue
    "#4DAF4A",  # green
    "#984EA3",  # purple
    "#FF7F00",  # orange
    "#A65628",  # brown
    "#F781BF",  # pink
    "#999999",  # grey
    "#17BECF",  # cyan
    "#BCBD22",  # olive
    "#1F77B4",
    "#D62728",
    "#2CA02C",
    "#9467BD",
    "#8C564B",
    "#E377C2",
    "#7F7F7F",
    "#AEC7E8",
    "#FFBB78",
    "#98DF8A",
]


def load_xy(path):
    df = pd.read_csv(path)
    if "x" in df.columns and "y" in df.columns:
        return df[["x", "y"]].to_numpy()
    return df.iloc[:, :2].to_numpy()


def entropy(S):
    return -np.sum(S * np.log(S + 1e-12), axis=1)


def label_to_colors(labels):
    active = sorted(np.unique(labels).tolist())
    color_map = {}
    for i, lab in enumerate(active):
        color_map[lab] = VIVID_COLORS[i % len(VIVID_COLORS)]
    colors = [color_map[x] for x in labels]
    return colors, active


def plot_hard_pair(xy_t, labels_t, xy_tp, labels_tp, title, out, point_size):
    colors_t, active_t = label_to_colors(labels_t)
    colors_tp, active_tp = label_to_colors(labels_tp)

    fig, axes = plt.subplots(1, 2, figsize=(16, 7), dpi=220)

    for ax, xy, labels, colors, active, subtitle in [
        (axes[0], xy_t, labels_t, colors_t, active_t, "11.5 hard assignment"),
        (axes[1], xy_tp, labels_tp, colors_tp, active_tp, "12.5 hard assignment"),
    ]:
        ax.scatter(
            xy[:, 0],
            xy[:, 1],
            c=colors,
            s=point_size,
            alpha=0.92,
            linewidths=0.0,
        )

        counts = np.bincount(labels)
        active_counts = counts[counts > 0]

        ax.set_title(f"{title} | {subtitle}", fontsize=15)
        ax.set_aspect("equal")
        ax.axis("off")
        ax.text(
            0.02,
            0.02,
            f"hardK={len(active)} | min={active_counts.min()} | max={active_counts.max()}",
            transform=ax.transAxes,
            fontsize=10,
            bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="black", alpha=0.85),
        )

    fig.tight_layout()
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)


def plot_size_bar(labels_t, labels_tp, out):
    active_t, counts_t = np.unique(labels_t, return_counts=True)
    active_tp, counts_tp = np.unique(labels_tp, return_counts=True)

    fig, axes = plt.subplots(1, 2, figsize=(15, 5), dpi=220)

    axes[0].bar([str(x) for x in active_t], counts_t)
    axes[0].set_title("11.5 cluster sizes", fontsize=15)
    axes[0].set_xlabel("cluster")
    axes[0].set_ylabel("spots")
    axes[0].tick_params(axis="x", rotation=90)

    axes[1].bar([str(x) for x in active_tp], counts_tp)
    axes[1].set_title("12.5 cluster sizes", fontsize=15)
    axes[1].set_xlabel("cluster")
    axes[1].set_ylabel("spots")
    axes[1].tick_params(axis="x", rotation=90)

    fig.tight_layout()
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)


def plot_entropy_pair(xy_t, ent_t, xy_tp, ent_tp, title, out, point_size):
    fig, axes = plt.subplots(1, 2, figsize=(16, 7), dpi=220)

    for ax, xy, ent, subtitle in [
        (axes[0], xy_t, ent_t, "11.5 assignment entropy"),
        (axes[1], xy_tp, ent_tp, "12.5 assignment entropy"),
    ]:
        sc = ax.scatter(
            xy[:, 0],
            xy[:, 1],
            c=ent,
            s=point_size,
            cmap="viridis",
            alpha=0.95,
            linewidths=0.0,
        )
        ax.set_title(f"{title} | {subtitle}", fontsize=15)
        ax.set_aspect("equal")
        ax.axis("off")
        cb = fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.04)
        cb.set_label("Entropy: low = confident, high = uncertain", fontsize=10)

    fig.tight_layout()
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--coord-t", required=True)
    parser.add_argument("--coord-tp", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--point-size", type=float, default=18)
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    S_t = np.load(run_dir / "S_t.npy")
    S_tp = np.load(run_dir / "S_tp.npy")

    labels_t = S_t.argmax(axis=1)
    labels_tp = S_tp.argmax(axis=1)

    xy_t = load_xy(args.coord_t)
    xy_tp = load_xy(args.coord_tp)

    ent_t = entropy(S_t)
    ent_tp = entropy(S_tp)

    plot_hard_pair(
        xy_t,
        labels_t,
        xy_tp,
        labels_tp,
        args.title,
        outdir / "hard_assignment_spatial_map.png",
        args.point_size,
    )

    plot_size_bar(
        labels_t,
        labels_tp,
        outdir / "cluster_size_bar.png",
    )

    plot_entropy_pair(
        xy_t,
        ent_t,
        xy_tp,
        ent_tp,
        args.title,
        outdir / "assignment_entropy_spatial_map.png",
        args.point_size,
    )

    with open(outdir / "summary.txt", "w") as f:
        for tag, S, labels in [
            ("11.5", S_t, labels_t),
            ("12.5", S_tp, labels_tp),
        ]:
            counts = np.bincount(labels, minlength=S.shape[1])
            active_counts = counts[counts > 0]
            f.write(f"{tag}\n")
            f.write(f"S shape: {S.shape}\n")
            f.write(f"hardK: {len(active_counts)}\n")
            f.write(f"min_size: {active_counts.min()}\n")
            f.write(f"max_size: {active_counts.max()}\n")
            f.write(f"mean_confidence: {S.max(axis=1).mean()}\n")
            f.write("\n")

    print("saved to:", outdir)


if __name__ == "__main__":
    main()
