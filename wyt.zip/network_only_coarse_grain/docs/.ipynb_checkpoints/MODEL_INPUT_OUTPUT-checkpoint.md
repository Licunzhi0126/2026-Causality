# Model Input and Output

## 1. Required input for CCI network-only mode

### P_t

Spot-level CCI network at time t.

Format:

- scipy sparse .npz
- shape: N_t x N_t
- rows and columns are spots
- values represent CCI / PIJ interaction strength

### P_tp

Spot-level CCI network at time t+1.

Format:

- scipy sparse .npz
- shape: N_tp x N_tp
- rows and columns are spots

The two time points can have different numbers of spots.

## 2. Optional input for CCI+GRN integrated mode

### GRN_t

Spot-level GRN feature matrix at time t.

Format:

- CSV
- rows are spots
- columns are GRN / regulon / module features
- row order must match the spot order in P_t

### GRN_tp

Spot-level GRN feature matrix at time t+1.

Format:

- CSV
- rows are spots
- columns are GRN / regulon / module features
- row order must match the spot order in P_tp

The GRN columns should be the same for the two time points.

## 3. Network-derived feature construction

build_network_only_features_v57.py derives node features from the input networks.

Feature dimension:

80 = 16 network summary features + 32 outgoing SVD features + 32 incoming SVD features

These features are derived from the input networks, not from external spatial-domain files.

## 4. Learned objects

### S_t

Spot-to-macro assignment matrix for time t.

Shape:

N_t x K

### S_tp

Spot-to-macro assignment matrix for time t+1.

Shape:

N_tp x K

### Z_micro_t / Z_micro_tp

Learned micro-level latent representations.

### Z_macro_t / Z_macro_tp

Learned macro-level latent representations.

### P_macro_t / P_macro_tp

Coarse-grained macro-level networks.

Computed as:

P_macro_t  = S_t^T  P_t  S_t
P_macro_tp = S_tp^T P_tp S_tp

## 5. Final metrics

The final metrics are printed in train.log:

- EI_micro
- EI_macro
- DeltaEI
- Lalign
- hardK
- Keff

## 6. Main output files

In each run directory, the important files are:

- train.log
- S_t.npy
- S_tp.npy
- Z_micro_t.npy
- Z_micro_tp.npy
- Z_macro_t.npy
- Z_macro_tp.npy
- P_macro_t.npy
- P_macro_tp.npy
