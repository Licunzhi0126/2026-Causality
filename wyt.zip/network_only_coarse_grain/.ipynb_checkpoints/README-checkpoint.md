# Network-only Coarse-graining for Causal Emergence

This folder contains the cleaned network-only coarse-graining pipeline.

## Main idea

The model takes two time-point spot-level networks as input and learns coarse-graining assignment matrices that produce macro-level networks with higher effective information.

Main output:

- `EI_micro`
- `EI_macro`
- `DeltaEI = EI_macro - EI_micro`
- `S_t`, `S_tp`: spot-to-macro assignment matrices
- `P_macro_t`, `P_macro_tp`: coarse-grained macro networks
- `Z_micro_t`, `Z_micro_tp`: learned micro latent representations
- `Z_macro_t`, `Z_macro_tp`: learned macro latent representations

## Pipeline A: CCI network-only

Input:

- 11.5 CCI network
- 12.5 CCI network

Steps:

```text
CCI networks
-> build_network_only_features_v57.py
-> network-derived node features
-> train_feature_align_deltaei_v40.py
-> coarse-graining outputs and DeltaEI
```

Run:

```bash
bash scripts/run_cci_network_only.sh
```

Clean reproduced result:

```text
EI_micro = 0.065031
EI_macro = 1.354171
DeltaEI = 1.289140
```

## Pipeline B: CCI + GRN integrated network-only

Input:

- 11.5 CCI network
- 12.5 CCI network
- 11.5 spot-level GRN feature CSV
- 12.5 spot-level GRN feature CSV

Steps:

```text
CCI networks + GRN spot-level features
-> build_integrated_cci_grn_network_v58.py
-> CCI+GRN integrated networks
-> build_network_only_features_v57.py
-> network-derived node features
-> train_feature_align_deltaei_v40.py
-> coarse-graining outputs and DeltaEI
```

Run:

```bash
bash scripts/run_cci_grn_integrated.sh
```

Clean reproduced result:

```text
EI_micro = 0.090879
EI_macro = 1.948429
DeltaEI = 1.857550
```

## Important notes

`S_t` and `S_tp` are not transition matrices. They are spot-to-macro assignment matrices.

The macro networks are computed as:

```text
P_macro_t  = S_t^T  P_t  S_t
P_macro_tp = S_tp^T P_tp S_tp
```

The network-only version does not use the previous spatial-domain external feature.

## Input examples

See `input_examples/`.

- `sample_11p5_CCI_total.npz`
- `sample_12p5_CCI_total.npz`
- `sample_11p5_GRN_features.csv`
- `sample_12p5_GRN_features.csv`

The sample files only show expected input format. They are too small for formal K=64 training.

## How to place this folder

Put this folder directly under the project root:

/home/jovyan/work/CE/2026-Causality/network_only_coarse_grain

Then run from the project root:

bash network_only_coarse_grain/scripts/run_cci_network_only.sh

or:

bash network_only_coarse_grain/scripts/run_cci_grn_integrated.sh

If the folder is renamed to coarse_grain, put it as:

/home/jovyan/work/CE/2026-Causality/coarse_grain

Then run:

bash coarse_grain/scripts/run_cci_network_only.sh

or:

bash coarse_grain/scripts/run_cci_grn_integrated.sh

## How to change inputs

Edit:

experiments/common/paths.sh

Main variables to change:

- P11_FULL: CCI network at time t
- P12_FULL: CCI network at time t+1
- GRN_F11: GRN spot-level feature CSV at time t
- GRN_F12: GRN spot-level feature CSV at time t+1
- OUT_ROOT: output root directory

For CCI network-only mode, only P11_FULL and P12_FULL are required.

For CCI+GRN integrated mode, P11_FULL, P12_FULL, GRN_F11, and GRN_F12 are required.
