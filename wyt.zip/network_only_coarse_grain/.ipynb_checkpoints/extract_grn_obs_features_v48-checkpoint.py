from pathlib import Path
import os
import numpy as np
import pandas as pd

try:
    import anndata as ad
except Exception as e:
    raise RuntimeError(
        "Cannot import anndata. Please install or check environment."
    ) from e


DATA_ROOT = Path(os.environ["DATA_ROOT"])
OUT_ROOT = Path(os.environ["OUT_ROOT"])

H5_11 = DATA_ROOT / "louvain_k150/heart/louvain150_heart_11.5_spots_with_domain.h5ad"
H5_12 = DATA_ROOT / "louvain_k150/heart/louvain150_heart_12.5_spots_with_domain.h5ad"

F11 = Path(os.environ["F11_SD"])
F12 = Path(os.environ["F12_SD"])

OUT_DIR = OUT_ROOT / "graph_nis_v40_feature_align/grn_aug_features_v48"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def read_grn_obs(h5_path, tag):
    print(f"reading {tag}: {h5_path}")
    adata = ad.read_h5ad(h5_path)

    obs = adata.obs.copy()
    obs.index = obs.index.astype(str)

    grn_cols = [
        c for c in obs.columns
        if str(c).startswith("Module_") or str(c).startswith("Regulon - ")
    ]

    print(tag, "n_obs:", obs.shape[0])
    print(tag, "n_grn_cols:", len(grn_cols))
    print(tag, "first obs names:", list(obs.index[:5]))
    print(tag, "first grn cols:", grn_cols[:10])

    X = obs[grn_cols].copy()

    for c in X.columns:
        X[c] = pd.to_numeric(X[c], errors="coerce")

    X = X.fillna(0.0)

    return X, list(obs.index)


X11, spot11 = read_grn_obs(H5_11, "11.5")
X12, spot12 = read_grn_obs(H5_12, "12.5")

common_cols = sorted(set(X11.columns).intersection(set(X12.columns)))
print("common GRN cols:", len(common_cols))

if len(common_cols) == 0:
    raise RuntimeError("No common Module_* or Regulon - * columns between 11.5 and 12.5")

X11 = X11[common_cols].to_numpy(dtype=np.float32)
X12 = X12[common_cols].to_numpy(dtype=np.float32)

# standardize using combined distribution
X_all = np.vstack([X11, X12])
mean = X_all.mean(axis=0, keepdims=True)
std = X_all.std(axis=0, keepdims=True)
std[std == 0] = 1.0

X11z = (X11 - mean) / std
X12z = (X12 - mean) / std

# original current features
F11_arr = pd.read_csv(F11, header=None).to_numpy(dtype=np.float32)
F12_arr = pd.read_csv(F12, header=None).to_numpy(dtype=np.float32)

print("F11 shape:", F11_arr.shape)
print("F12 shape:", F12_arr.shape)
print("GRN11 shape:", X11z.shape)
print("GRN12 shape:", X12z.shape)

if F11_arr.shape[0] != X11z.shape[0]:
    raise ValueError(f"F11 rows {F11_arr.shape[0]} != GRN11 rows {X11z.shape[0]}")
if F12_arr.shape[0] != X12z.shape[0]:
    raise ValueError(f"F12 rows {F12_arr.shape[0]} != GRN12 rows {X12z.shape[0]}")

F11_aug = np.hstack([F11_arr, X11z])
F12_aug = np.hstack([F12_arr, X12z])

out_grn11 = OUT_DIR / "heart_11p5_grn_obs_features.csv"
out_grn12 = OUT_DIR / "heart_12p5_grn_obs_features.csv"
out_aug11 = OUT_DIR / "heart_11p5_feature_plus_grn.csv"
out_aug12 = OUT_DIR / "heart_12p5_feature_plus_grn.csv"
out_cols = OUT_DIR / "common_grn_feature_columns.txt"
out_spot11 = OUT_DIR / "heart_11p5_h5ad_obs_names.txt"
out_spot12 = OUT_DIR / "heart_12p5_h5ad_obs_names.txt"

pd.DataFrame(X11z, columns=common_cols).to_csv(out_grn11, index=False)
pd.DataFrame(X12z, columns=common_cols).to_csv(out_grn12, index=False)

pd.DataFrame(F11_aug).to_csv(out_aug11, index=False, header=False)
pd.DataFrame(F12_aug).to_csv(out_aug12, index=False, header=False)

out_cols.write_text("\n".join(common_cols))
out_spot11.write_text("\n".join(spot11))
out_spot12.write_text("\n".join(spot12))

print("saved:")
print(out_grn11)
print(out_grn12)
print(out_aug11)
print(out_aug12)
print(out_cols)
print("augmented shapes:", F11_aug.shape, F12_aug.shape)
