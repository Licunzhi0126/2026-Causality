# Run Guide

## 1. Folder placement

Place this folder directly under the project root:

/home/jovyan/work/CE/2026-Causality/network_only_coarse_grain

Then enter the project root:

cd /home/jovyan/work/CE/2026-Causality

## 2. Configure input paths

Edit:

network_only_coarse_grain/experiments/common/paths.sh

Main variables:

P11_FULL: CCI network at time t
P12_FULL: CCI network at time t+1
GRN_F11: GRN spot-level feature CSV at time t
GRN_F12: GRN spot-level feature CSV at time t+1
OUT_ROOT: output directory

## 3. Run CCI network-only mode

bash network_only_coarse_grain/scripts/run_cci_network_only.sh

Required inputs:

P11_FULL
P12_FULL

## 4. Run CCI+GRN integrated mode

bash network_only_coarse_grain/scripts/run_cci_grn_integrated.sh

Required inputs:

P11_FULL
P12_FULL
GRN_F11
GRN_F12

This is the currently recommended mode.

## 5. Summarize a completed run

python network_only_coarse_grain/scripts/summarize_run_outputs.py \
  --run-dir <run_output_directory>

Example:

python network_only_coarse_grain/scripts/summarize_run_outputs.py \
  --run-dir output/coarse_grain/scheme_A_PIJ/graph_nis_v40_feature_align/routeA_k64_kl_networkonly_grnint_w02_ei20_svd32_clean
