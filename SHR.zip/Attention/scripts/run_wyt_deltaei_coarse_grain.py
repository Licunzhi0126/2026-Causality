#!/usr/bin/env python3
"""Single-run entry point for the two supported coarse-graining methods."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path: sys.path.insert(0, str(REPO_ROOT))
from mignet_ce.coarse_frontends import COARSE_METHOD_SPECS
METHOD_CHOICES = tuple(sorted(COARSE_METHOD_SPECS))

def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Run Method 8 or Method 10 maturity+CCI+GRN coarse graining.")
    p.add_argument("--method", choices=METHOD_CHOICES, required=True, help="选择方法8或方法10。")
    for name in ("h5ad-t", "h5ad-tp", "cci-t", "cci-tp"): p.add_argument(f"--{name}", type=Path, required=True)
    for name in ("cci-index-t", "cci-index-tp", "grn-t", "grn-tp", "maturity-t", "maturity-tp"): p.add_argument(f"--{name}", type=Path)
    p.add_argument("--k", type=int, required=True); p.add_argument("--out-dir", type=Path, required=True)
    p.add_argument("--maturity-id-column", default="spot_id"); p.add_argument("--maturity-column", default="maturity"); p.add_argument("--maturity-confidence-column"); p.add_argument("--maturity-normalization", choices=["none","minmax","rank"], default="minmax"); p.add_argument("--maturity-direction", choices=["higher_is_more_mature","higher_is_more_primitive"], default="higher_is_more_mature")
    p.add_argument("--cci-min", type=float, default=0.); p.add_argument("--regsim-knn-k", type=int, default=50); p.add_argument("--regsim-weight", type=float, default=.2); p.add_argument("--network-svd-dim", type=int, default=32); p.add_argument("--mid-dim", type=int, default=32); p.add_argument("--nmf-components", type=int, default=5); p.add_argument("--nmf-max-iter", type=int, default=300); p.add_argument("--pij-temperature", type=float, default=1.)
    p.add_argument("--grn-topk-targets", type=int, default=50); p.add_argument("--grn-state-dim", type=int, default=64); p.add_argument("--grn-projection-seed", type=int, default=20260713); p.add_argument("--grn-knn-k", type=int, default=50); p.add_argument("--grn-graph-weight", type=float, default=.2); p.add_argument("--grn-feature-method", choices=["legacy","legacy_nmf","legacy_lap_hks"], default="legacy"); p.add_argument("--grn-residual-lambda", type=float, default=.15); p.add_argument("--cci-feature-method", choices=["shared_nmf","laplacian_hks"], default="shared_nmf"); p.add_argument("--cci-laplacian-components", type=int, default=5); p.add_argument("--alpha-cci", type=float, default=.01)
    p.add_argument("--hidden-dim", type=int, default=64); p.add_argument("--gnn-layers", type=int, default=2); p.add_argument("--knn-k", type=int, default=30); p.add_argument("--local-dims", type=int, default=2); p.add_argument("--graph-projection-dim", type=int, default=32); p.add_argument("--attention-heads", type=int, default=4); p.add_argument("--attention-ffn-dim", type=int); p.add_argument("--attention-dropout", type=float, default=0.); p.add_argument("--attention-beta-init", type=float, default=.1); p.add_argument("--cross-time-beta-init", type=float, default=.1); p.add_argument("--cross-time-gate-bias-init", type=float, default=-2.); p.add_argument("--cosine-eta-min", type=float, default=1e-6)
    p.add_argument("--temperature", type=float, default=.07); p.add_argument("--epochs", type=int, default=1500); p.add_argument("--lr", type=float, default=5e-4); p.add_argument("--lambda-ei", type=float, default=1.); p.add_argument("--lambda-var", type=float, default=1.); p.add_argument("--lambda-local", type=float, default=.1); p.add_argument("--lambda-sharp", type=float, default=.02); p.add_argument("--lambda-proto", type=float, default=.2); p.add_argument("--lambda-closure", type=float, default=.1); p.add_argument("--lambda-within", type=float, default=.1); p.add_argument("--lambda-inter", type=float, default=.2); p.add_argument("--lambda-retain", type=float, default=.5); p.add_argument("--inter-margin", type=float, default=.05); p.add_argument("--active-usage-threshold", type=float, default=.005); p.add_argument("--keff-min", type=float); p.add_argument("--checkpoint-keff-min", type=float); p.add_argument("--lambda-keff", type=float, default=1.); p.add_argument("--lambda-dev", type=float, default=.05); p.add_argument("--development-min-state-mass", type=float, default=1e-8); p.add_argument("--embedding-target-std", type=float, default=.05); p.add_argument("--prototype-max-cosine", type=float, default=.2); p.add_argument("--seed", type=int, default=42); p.add_argument("--device", choices=["cpu","cuda","auto"], default="cpu"); p.add_argument("--log-every", type=int, default=50)
    return p

def main(argv: list[str] | None = None) -> None:
    a = build_argparser().parse_args(argv)
    from mignet_ce.coarse_frontends import CoarseFrontendRequest, prepare_coarse_input
    from wyt_deltaei_coarse_grain import WYTPCA32KNNLinearHeadSingleStageConfig, WYTBiDirectionalCrossTimeAttentionConfig, train_deltaei_pca32_knn_linear_head_single_stage, train_deltaei_bidirectional_cross_time_attention_single_stage
    if not all((a.grn_t, a.grn_tp, a.maturity_t, a.maturity_tp)): raise SystemExit("Both supported methods require --grn-t/--grn-tp and --maturity-t/--maturity-tp.")
    request = CoarseFrontendRequest(**{key.replace("-", "_"): getattr(a, key.replace("-", "_")) for key in ("h5ad_t","h5ad_tp","cci_t","cci_tp","cci_index_t","cci_index_tp","cci_min","regsim_knn_k","regsim_weight","network_svd_dim","mid_dim","nmf_components","nmf_max_iter","seed","pij_temperature","grn_t","grn_tp","grn_topk_targets","grn_state_dim","grn_projection_seed","grn_knn_k","grn_graph_weight","grn_feature_method","grn_residual_lambda","cci_feature_method","cci_laplacian_components","alpha_cci","maturity_t","maturity_tp","maturity_id_column","maturity_column","maturity_confidence_column","maturity_normalization","maturity_direction")})
    prepared = prepare_coarse_input(a.method, request)
    common = {key: getattr(a,key) for key in ("k","out_dir","hidden_dim","gnn_layers","knn_k","local_dims","temperature","epochs","lr","lambda_ei","lambda_var","lambda_local","lambda_sharp","lambda_proto","lambda_closure","lambda_within","lambda_inter","lambda_retain","inter_margin","active_usage_threshold","keff_min","checkpoint_keff_min","lambda_keff","lambda_dev","development_min_state_mass","embedding_target_std","prototype_max_cosine","seed","device","log_every")}
    if a.method.startswith("maturity_cci_grn_pca32"):
        train_deltaei_pca32_knn_linear_head_single_stage(prepared, WYTPCA32KNNLinearHeadSingleStageConfig(**common, graph_projection_dim=a.graph_projection_dim))
    else:
        train_deltaei_bidirectional_cross_time_attention_single_stage(prepared, WYTBiDirectionalCrossTimeAttentionConfig(**common, attention_heads=a.attention_heads, attention_ffn_dim=a.attention_ffn_dim, attention_dropout=a.attention_dropout, attention_beta_init=a.attention_beta_init, cross_time_beta_init=a.cross_time_beta_init, cross_time_gate_bias_init=a.cross_time_gate_bias_init, cosine_eta_min=a.cosine_eta_min))
if __name__ == "__main__": main()
