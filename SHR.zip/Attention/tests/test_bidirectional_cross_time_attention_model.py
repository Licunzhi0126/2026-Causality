import torch

from wyt_deltaei_coarse_grain.bidirectional_cross_time_attention_model import (
    BidirectionalCrossTimeAttentionModel,
    reverse_row_normalized_prior,
    stable_cross_time_bias,
)


def test_method10_model_supports_different_node_counts_and_gradients():
    torch.manual_seed(7)
    model = BidirectionalCrossTimeAttentionModel(5, 5, hidden_dim=8, k=3, heads=2)
    features_t, features_tp = torch.randn(4, 5), torch.randn(6, 5)
    relation_t, relation_tp = torch.rand(4, 4), torch.rand(6, 6)
    prior = torch.tensor([[.5, .5, 0, 0, 0, 0], [.2, .8, 0, 0, 0, 0], [.1, .2, .3, .4, 0, 0], [.4, .1, .1, .1, .1, .2]])
    result = model(features_t, relation_t, features_tp, relation_tp, prior, .07)
    assert result["assignment_t"].shape == (4, 3)
    assert result["assignment_tp"].shape == (6, 3)
    assert torch.allclose(result["assignment_t"].sum(1), torch.ones(4))
    assert torch.allclose(result["assignment_tp"].sum(1), torch.ones(6))
    assert all(torch.isfinite(value).all() for value in result.values())
    (result["assignment_t"].square().mean() + result["assignment_tp"].square().mean()).backward()
    for module in (model.encoder_t, model.encoder_tp, model.cross_t_from_tp, model.cross_tp_from_t, model.fusion_t, model.fusion_tp):
        assert any(parameter.grad is not None and torch.isfinite(parameter.grad).all() for parameter in module.parameters())


def test_reverse_prior_has_finite_uniform_zero_row_fallback():
    prior = torch.tensor([[1., 0., 0.], [0., 0., 1.]])
    reverse = reverse_row_normalized_prior(prior)
    assert torch.isfinite(reverse).all()
    assert torch.allclose(reverse.sum(1), torch.ones(3))
    assert torch.allclose(reverse[1], torch.full((2,), .5))
    assert torch.isfinite(stable_cross_time_bias(reverse)).all()
