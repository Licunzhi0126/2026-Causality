from pathlib import Path

METHOD8 = "maturity_cci_grn_pca32_knn_linear_head_single_stage"
METHOD10 = "maturity_cci_grn_bidirectional_cross_time_attention_single_stage"

def test_registry_contains_only_methods_8_and_10():
    from mignet_ce.coarse_frontends import COARSE_METHOD_SPECS
    assert set(COARSE_METHOD_SPECS) == {METHOD8, METHOD10}

def test_method8_has_no_legacy_trainer_or_monkey_patch_dependency():
    source = (Path(__file__).parents[1] / "wyt_deltaei_coarse_grain" / "pca32_knn_linear_head_single_stage_trainer.py").read_text(encoding="utf-8")
    for forbidden in ("linear_head_single_stage_trainer", "two_stage_trainer", "unified_single_simplified_trainer", "monkey patch"):
        assert forbidden not in source
    assert "relation_matrices=adjacencies" in source

def test_method10_has_no_two_stage_imports():
    source = (Path(__file__).parents[1] / "wyt_deltaei_coarse_grain" / "bidirectional_cross_time_attention_single_stage_trainer.py").read_text(encoding="utf-8")
    assert "two_stage_trainer" not in source
    assert "two_stage_objective" not in source


def test_final_evaluations_do_not_use_strict_posthoc_path():
    root = Path(__file__).parents[1] / "wyt_deltaei_coarse_grain"
    for name in ("method8_training_core.py", "bidirectional_cross_time_attention_single_stage_trainer.py"):
        source = (root / name).read_text(encoding="utf-8")
        assert "posthoc_evaluator(" not in source
        assert "strict_delta_EI" not in source
        assert "strict_posthoc" not in source
        assert '"delta_EI_best_checkpoint"' in source
    preparation = (Path(__file__).parents[1] / "mignet_ce" / "coarse_frontends" / "_maturity_cci_grn_common.py").read_text(encoding="utf-8")
    assert "posthoc_evaluator=" not in preparation
    assert "strict_posthoc_filename" not in preparation
