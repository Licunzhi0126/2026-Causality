from mignet_ce.coarse_frontends.method_specs import (
    BIDIRECTIONAL_CROSS_TIME_ATTENTION_SINGLE_STAGE,
    get_coarse_method_spec,
)


METHOD = "maturity_cci_grn_bidirectional_cross_time_attention_single_stage"


def test_method10_method_spec_is_consistent():
    spec = get_coarse_method_spec(METHOD)
    assert spec.training_mode == BIDIRECTIONAL_CROSS_TIME_ATTENTION_SINGLE_STAGE
    assert spec.frontend == METHOD
    assert spec.objective_version == "wyt_bidirectional_cross_time_attention_single_stage_v1"


def test_method10_model_and_trainer_do_not_depend_on_method9_modules():
    from pathlib import Path
    root = Path(__file__).parents[1] / "wyt_deltaei_coarse_grain"
    for name in ("bidirectional_cross_time_attention_model.py", "bidirectional_cross_time_attention_single_stage_trainer.py"):
        source = (root / name).read_text(encoding="utf-8")
        assert "CCIRelationGlobalAttentionEncoder" not in source
        assert "cci_relation_global_attention_single_stage_trainer" not in source
