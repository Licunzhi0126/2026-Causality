# 清理 Strict ΔEI：统一最终 ΔEI 与训练计算路径

## 1. 任务目标

本次任务只处理主流程中方法8和方法10的 ΔEI 计算与最终输出口径。

核心要求：

> **训练时如何根据当前分配矩阵构建宏观转移矩阵 \(P_{IJ}\) 并计算 train ΔEI，最佳 checkpoint 的最终 ΔEI 就沿用同一条计算路径。删除额外的 strict 重建评估路径，不再把它作为另一套 ΔEI 指标输出。**

适用方法：

- 方法8：`maturity_cci_grn_pca32_knn_linear_head_single_stage`
- 方法10：当前双向跨时间注意力单阶段方法（若代码中 method ID 已改为 SKIRK，请以仓库当前实际注册名为准）

开始修改前，先审计仓库当前实现，确认每个方法的真实训练 forward、宏观 \(P_{IJ}\) builder、最终 checkpoint 评估、post-hoc evaluator 和输出字段；不要只按函数名或本计划假设直接删除代码。

---

## 2. 本次修改范围

### 必须处理

- 方法8的 trainer 和最终评估；
- 方法10的 trainer 和最终评估；
- 方法8/10共用的结果写入逻辑（仅在确实承载 strict 指标时修改）；
- `scripts/run_wyt_deltaei_coarse_grain.py` 中与方法8/10结果协议有关的必要部分；
- `scripts/run_multiscale_maturity_cci_grn.py` 中汇总、验证或复制 strict 指标的必要部分；
- 与上述主流程直接相关的测试。

### 明确不处理

- 不修改方法8、方法10的模型结构；
- 不修改 loss 定义、loss 权重、优化器、学习率计划或训练 epoch；
- 不修改 checkpoint 资格、评分或选择规则；
- 不修改 CCI/GRN 特征提取、PCA/KNN 图构建、宏观 \(P_{IJ}\) 构建公式；
- 不修改 `mignet_ce/downstream/**`，downstream 后续由用户自行迁移；
- 不进行与本任务无关的旧方法清理或代码重构。

---

## 3. 先审计训练 ΔEI 的真实计算路径

分别追踪方法8与方法10每个 epoch 的完整调用链，记录实际使用的函数与数据对象。

目标流程应以仓库真实实现为准，概念上是：

1. 模型生成当前分配矩阵 \(S_t,S_{t+1}\)；
2. 使用当前方法既有的宏观特征池化与 GRN 特征重算流程；
3. 使用现有 `macro_pij_builder`（或当前等价函数）构建宏观转移矩阵 \(P_{IJ}^{\mathrm{train}}\)；
4. 使用固定的微观基准 EI 计算：
   \[
   \Delta EI_{\mathrm{train}}
   = EI(P_{IJ}^{\mathrm{train}})-EI(P_{IJ}^{\mathrm{micro}})
   \]
5. 将该 ΔEI 用于现有训练 loss、训练日志和 checkpoint 评分。

Codex 必须在代码审计报告中列出方法8、方法10各自真实的函数调用链，确认它们是否共用相同的公共 builder，以及各自是否存在额外的分支。**不要为了让两个方法看起来一致而改动它们原本的宏观 \(P_{IJ}\) 构建公式。**

---

## 4. 删除额外 Strict 重建路径

训练结束后，当前代码可能会通过 `prepared.posthoc_evaluator()` 或其他 strict evaluator 单独执行另一条宏观重建流程。请在方法8、方法10中定位这条调用链。

### 4.1 必须删除的行为

- 最佳 checkpoint 评估后额外执行的 strict/post-hoc ΔEI 重建调用；
- 只为这条 strict 评估路径服务、且确认不再被主流程其他必要功能使用的 strict 专用结果组装；
- `summary.json` 中独立的 `strict_delta_EI` 字段；
- 只用于存放 strict ΔEI 的专用 CSV、JSON、NPZ 或其他结果文件；
- `strict_delta_EI` 与 `delta_EI_best_checkpoint` 的双指标比较、差值计算或 strict 指标覆盖逻辑；
- 主流程中仅为 strict evaluator 设置的必需条件、报错分支或输出验证。

### 4.2 不可机械删除

- 不要删除 `PreparedCoarseInput` 中的 `posthoc_evaluator` 字段，除非全仓库（排除本次明确不处理的 downstream）静态检索证明它不再被任何保留主流程使用。
- 不要删除所有名称包含 `strict` 的代码。某些 strict 命名可能属于其他算法、历史产物、checkpoint 元数据或独立分析流程，必须按调用关系判断。
- 不要改动训练期间计算 ΔEI 的函数。
- 不要将严格重建逻辑偷偷改写成另一个名字后继续执行；本次目标是停止主流程额外运行这条路径。

---

## 5. 最终 ΔEI 的计算方式

训练完成后，必须按当前项目的 checkpoint 规则恢复最佳 checkpoint，再执行一次确定性的最终评估。

### 5.1 最终评估流程

1. 按现有规则恢复最佳 checkpoint，确保恢复的是完整模型状态；
2. 切换到 `eval()` 模式；
3. 在 `torch.no_grad()` 下调用该方法自己的正常 forward 路径；
4. 使用与训练 forward 相同的宏观特征池化、GRN 特征重算、宏观成本构建和 `macro_pij_builder`；
5. 使用同一个 `effective_information` 与固定微观 EI 基准计算最终 ΔEI；
6. 将最终结果写入现有的主结果字段。

**关键要求：最终评估复用同一条计算路径与同一套数学函数，不复用最后一个 epoch 的旧日志数值，也不调用 strict evaluator。**

如果当前训练器的 forward 同时计算 loss 和指标，可以增加一个轻量的 evaluation wrapper，但 wrapper 必须调用同一套底层宏观构建函数，不能另写一份近似实现。`eval()` 可能改变 dropout 等随机层行为，因此最终值应定义为最佳 checkpoint 在评估模式下通过同一路径重新计算的结果；不要要求它必须逐位等于训练模式下日志中的数值。

### 5.2 不得改变的内容

- 不改变训练时的 `train_delta_EI` 计算公式；
- 不改变固定微观 EI 的来源；
- 不改变宏观 \(P_{IJ}\) builder、特征池化或 GRN 重算流程；
- 不改变 loss；
- 不改变 checkpoint 选择规则；
- 不改变方法8的 PCA/KNN 图；
- 不改变方法10的全局自注意力、双向跨时间注意力、门控融合或独立分支结构。

---

## 6. 输出字段和文件

### 6.1 `summary.json`

保留项目当前主流程所需的指标字段，并确保：

- `delta_EI_best_checkpoint` 表示**最佳 checkpoint 经训练路径重新前向计算得到的最终 ΔEI**；
- 如现有 schema 中存在 `train_delta_EI_best_checkpoint`，则保留并明确其含义；不得与最终值混用；
- 删除 `strict_delta_EI`；
- 不再写入 strict 专用文件路径、strict 重建配置或 strict 指标比较结果；
- 保留 `EI_micro_fixed`、`EI_macro_best_checkpoint`、`best_epoch`、Keff、hard K、CQ、`I_retained` 等其他现有字段及其原有含义；
- 不要因为删除 strict 指标而删除 runner 验证 summary 所需的其他字段。

### 6.2 `training_history.csv`

- 保留现有训练日志列与数值语义；
- 训练期间的 `delta_EI` 仍然来自每个 epoch 的训练路径；
- 删除只用于记录 strict/post-hoc 评估的列（如果存在）；
- 不得将 strict 数值复制进 `delta_EI` 或覆盖训练日志。

### 6.3 其他输出

搜索方法8/10的输出写入逻辑，删除只用于 strict 评估的文件和 manifest 条目。保留最终分配矩阵、宏观转移矩阵、训练历史、配置、provenance、checkpoint 与 runner 汇总所需文件。

---

## 7. 多尺度 Runner 的兼容性

检查 `scripts/run_multiscale_maturity_cci_grn.py` 及其调用的 summary validation / aggregation：

- 不再要求 `strict_delta_EI` 存在；
- 不再从 strict 指标推导成功状态、排序或额外差值；
- 主要 ΔEI 汇总使用 `delta_EI_best_checkpoint`（按现有 runner 约定）；
- 保留 `EI_micro_fixed`、`EI_macro_best_checkpoint`、Keff、CQ 等现有汇总指标；
- `multiscale_summary.csv`、manifest、run context 和输出目录组织保持兼容；
- 不得因为 strict 字段消失而让 `_valid_summary()` 拒绝方法8/10的有效结果。

如果 runner 当前使用 `strict_delta_EI` 作为必要字段，必须将其验证条件改为验证新的主 ΔEI 字段；不要把新字段命名成 strict 来规避删除要求。

---

## 8. 数值与可复现性要求

- 最终评估的分配矩阵必须来自恢复后的最佳 checkpoint；
- 最终宏观 \(P_{IJ}\) 必须由与训练相同的 builder 生成；
- 所有最终指标都必须是有限值；
- 检查 \(S_t,S_{t+1}\) 每行归一化正常；
- 检查宏观 \(P_{IJ}\) 的形状、有限值与归一化；
- 若最终评估路径与训练 forward 共用同一底层函数，应增加测试防止未来产生分叉；
- 不为追求与训练模式日志逐位相等而关闭正常的 `eval()` 行为；
- 不增加新的 strict 或第二套 ΔEI 计算路径。

---

## 9. 必须完成的测试

### A. 代码调用链

- [ ] 方法8最终评估不再调用 strict/post-hoc evaluator。
- [ ] 方法10最终评估不再调用 strict/post-hoc evaluator。
- [ ] 方法8、10最终 ΔEI 使用各自训练时相同的宏观构建函数与 EI 函数。
- [ ] 不再有主流程代码读取 `strict_delta_EI` 作为必需字段。
- [ ] 不再生成 strict 专用输出文件。
- [ ] 不修改 `mignet_ce/downstream/**`。

### B. 单元测试

使用小型 synthetic 输入验证：

- [ ] 恢复最佳 checkpoint 后会重新运行普通 forward；
- [ ] 最终 ΔEI 来自这次 forward 重新构建的宏观 \(P_{IJ}\)，不是最后一行训练日志；
- [ ] 最终评估不会触发 post-hoc evaluator；
- [ ] summary 中存在 `delta_EI_best_checkpoint` 且不存在 `strict_delta_EI`；
- [ ] summary 仍包含 runner 要求的其他字段；
- [ ] NaN/Inf 会按现有错误处理机制被捕获；
- [ ] 方法8、方法10分别通过测试。

### C. Runner smoke test

对方法8和方法10分别执行小规模 smoke test：

- organ：`heart`
- time pair：`11.5 -> 13.5`
- scale：`spot`
- K：`40`
- seed：`42`
- epochs：`2–5`

验收：

- [ ] 子进程正常结束；
- [ ] 最终 summary 没有 `strict_delta_EI`；
- [ ] `delta_EI_best_checkpoint` 有限且来自最终 checkpoint 评估；
- [ ] `_valid_summary()` 通过；
- [ ] `multiscale_summary.csv` 与 manifest 正常生成；
- [ ] 方法8和方法10均不调用 strict evaluator。

---

## 10. Codex 推荐执行顺序

1. 搜索方法8、方法10的 `strict_delta_EI`、`posthoc_evaluator`、strict 文件写入和 runner validation 引用。
2. 分别绘制两种方法的训练 ΔEI 调用链与 strict evaluator 调用链，记录它们在哪一步分叉。
3. 为方法8和方法10确认可在最终评估阶段复用的正常 forward / macro builder。
4. 修改最终评估，让最佳 checkpoint 通过同一训练计算路径重新计算 ΔEI。
5. 删除 strict evaluator 调用与 strict 专属输出，不动无关的公共 evaluator 定义。
6. 更新 summary schema、history 和多尺度 runner 的验证/聚合逻辑。
7. 增加单元测试，证明最终评估使用正确 checkpoint、同一 macro builder，且不调用 strict evaluator。
8. 分别运行方法8、方法10的 synthetic 测试与真实数据 smoke test。
9. 最后做全局搜索，确认主流程不再把 `strict_delta_EI` 当作输出或必需输入。
10. 提交交付报告，列出修改文件、删除的 strict 调用与输出、测试命令、测试结果，以及仍保留但未使用的公共 evaluator（如有）。

---

## 11. 禁止事项

- 不修改方法8和方法10的模型架构。
- 不修改 train ΔEI 计算公式、宏观 \(P_{IJ}\) 构建方式或 EI 公式。
- 不修改 loss、优化器、学习率计划或 checkpoint 选择规则。
- 不将 strict ΔEI 改名后继续计算。
- 不把训练历史最后一行当作最佳 checkpoint 的最终指标。
- 不机械删除所有名称带 `strict` 的函数或文件；必须按主流程依赖判断。
- 不修改 downstream 文件。
- 不通过删除 summary 字段来掩盖 runner 仍依赖 strict 指标的问题。
