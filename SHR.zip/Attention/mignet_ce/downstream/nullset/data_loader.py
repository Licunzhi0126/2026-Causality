"""One-time preparation of the fixed micro transition matrix."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mignet_ce.coarse_frontends._common import CoarseFrontendRequest
from mignet_ce.coarse_frontends.maturity_cci_grn_two_stage import prepare
from mignet_ce.representations.coarse_input import PreparedCoarseInput

from .config import NullsetConfig


def _require_paths(config: NullsetConfig) -> None:
    for name, value in config.manifest().items():
        if name in {"h5ad_t", "h5ad_tp", "cci_t", "cci_tp", "grn_t", "grn_tp", "maturity_t", "maturity_tp", "cci_index_t", "cci_index_tp"} and value is not None:
            if not Path(value).is_file():
                raise FileNotFoundError(f"{name} does not exist or is not a file: {value}")


def input_file_fingerprints(config: NullsetConfig) -> dict[str, dict[str, Any]]:
    """Return lightweight, non-content fingerprints for metadata traceability."""
    names = ("h5ad_t", "h5ad_tp", "cci_t", "cci_tp", "grn_t", "grn_tp", "maturity_t", "maturity_tp", "cci_index_t", "cci_index_tp")
    result: dict[str, dict[str, Any]] = {}
    for name in names:
        path = getattr(config, name)
        if path is None:
            continue
        resolved = Path(path).resolve()
        if resolved.is_file():
            stat = resolved.stat()
            result[name] = {"path": str(resolved), "size_bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns}
        else:
            result[name] = {"path": str(resolved), "exists": False}
    return result


def prepare_input(config: NullsetConfig) -> PreparedCoarseInput:
    """Prepare once through the public frontend; this function never trains."""
    _require_paths(config)
    request = CoarseFrontendRequest(
        h5ad_t=config.h5ad_t, h5ad_tp=config.h5ad_tp, cci_t=config.cci_t, cci_tp=config.cci_tp,
        cci_index_t=config.cci_index_t, cci_index_tp=config.cci_index_tp, cci_min=config.cci_min,
        nmf_components=config.nmf_components, nmf_max_iter=config.nmf_max_iter, mid_dim=config.mid_dim,
        seed=config.seed, grn_t=config.grn_t, grn_tp=config.grn_tp,
        grn_topk_targets=config.grn_topk_targets, grn_state_dim=config.grn_state_dim,
        grn_projection_seed=config.grn_projection_seed, grn_feature_method=config.grn_feature_method,
        grn_residual_lambda=config.grn_residual_lambda, cci_feature_method=config.cci_feature_method,
        cci_laplacian_components=config.cci_laplacian_components,
        cci_laplacian_normalized=config.cci_laplacian_normalized, alpha_cci=config.alpha_cci,
        maturity_t=config.maturity_t, maturity_tp=config.maturity_tp,
        maturity_id_column=config.maturity_id_column, maturity_column=config.maturity_column,
        maturity_confidence_column=config.maturity_confidence_column,
        maturity_normalization=config.maturity_normalization, maturity_direction=config.maturity_direction,
    )
    prepared = prepare(request)
    prepared.validate()
    return prepared
