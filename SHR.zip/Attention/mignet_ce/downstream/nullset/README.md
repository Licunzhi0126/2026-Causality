# Random coarse-graining nullset

This module is **Random Assignment evaluated with Two-stage macro dynamics**.
It prepares the fixed micro inputs once through `maturity_cci_grn_two_stage`,
then independently randomizes source and target hard-balanced assignments for
every trial.  Macro PIJ is produced by the Two-stage `macro_pij_builder` from
pooled N/X feature blocks. It never starts a trainer, encoder, optimizer,
epoch loop, or checkpoint process.

```powershell
python -m mignet_ce.downstream.nullset `
  --h5ad-t T1.h5ad --h5ad-tp T2.h5ad `
  --cci-t T1_CCI_total.npz --cci-tp T2_CCI_total.npz `
  --cci-index-t T1_index.tsv --cci-index-tp T2_index.tsv `
  --grn-t T1_GRN.csv --grn-tp T2_GRN.csv `
  --maturity-t T1_maturity.csv --maturity-tp T2_maturity.csv `
  --k 40 --n-repeats 100 --seed 42 `
  --out-dir outputs/nullset/heart_spot_11.5_to_12.5/K40
```

`summary.csv` has one row per trial, including Macro EI, Delta EI,
`I_available`, `I_retained`, `closure_leakage`, `closure_quality`, and the two
closure diagnostics. `statistics.json` reports empirical nullset quantiles,
not theoretical confidence intervals. Assignment files
are two-column CSVs (`name,cluster_id`) using zero-based IDs.  `metadata.json`
records the supplied paths and frontend parameters, and explicitly labels the
result as `macro_pij_method=two_stage_feature_builder` and
`assignment_method=balanced_random`. `--save-macro-pij` additionally writes
one `.npy` macro PIJ per trial.

This aligns the metric evaluator with Two-stage macro dynamics, but not its
learning process: random hard assignments are not the soft assignments learned
by full Two-stage Optimal CG. Results must not be described as a trained or
optimized coarse-graining baseline.

Run the module tests explicitly (the repository-wide pytest configuration only
collects its root `tests/` directory):

```powershell
python -m pytest mignet_ce/downstream/nullset/tests
```
