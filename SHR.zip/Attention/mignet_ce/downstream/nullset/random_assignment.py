"""Balanced, independent random assignments for two time points."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class RandomAssignment:
    labels_t: np.ndarray
    labels_tp: np.ndarray


def balanced_labels(n_units: int, k: int, seed_sequence: np.random.SeedSequence) -> np.ndarray:
    if n_units < 1 or not 1 <= k <= n_units:
        raise ValueError(f"k must satisfy 1 <= k <= n_units; got k={k}, n_units={n_units}.")
    labels = np.arange(n_units, dtype=np.int64) % k
    rng = np.random.default_rng(seed_sequence)
    rng.shuffle(labels)
    return labels


def make_assignment(n_t: int, n_tp: int, k: int, base_seed: int, trial: int) -> RandomAssignment:
    if base_seed < 0 or trial < 0:
        raise ValueError("base_seed and trial must be non-negative integers.")
    if k > min(n_t, n_tp):
        raise ValueError(f"k={k} exceeds min(n_t, n_tp)={min(n_t, n_tp)}.")
    seed_t, seed_tp = np.random.SeedSequence([base_seed, trial]).spawn(2)
    return RandomAssignment(
        labels_t=balanced_labels(n_t, k, seed_t),
        labels_tp=balanced_labels(n_tp, k, seed_tp),
    )
