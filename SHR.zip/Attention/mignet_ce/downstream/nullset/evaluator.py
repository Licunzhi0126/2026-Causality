"""Zero-training evaluation using the Two-stage macro-dynamics definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import torch
import torch.nn.functional as functional

from mignet_ce.representations.coarse_input import MacroPijInputs
from wyt_deltaei_coarse_grain.macro_builder import pool_feature_blocks
from wyt_deltaei_coarse_grain.two_stage_objective import (
    dynamical_closure_loss, effective_information, future_dynamics_centers,
    information_closure_metrics, within_macro_dynamics_loss,
)


@dataclass(frozen=True)
class Evaluation:
    macro_pij: np.ndarray
    micro_ei: float
    macro_ei: float
    delta_ei: float
    i_available: float
    i_retained: float
    closure_leakage: float
    closure_quality: float
    l_closure: float
    l_within_dynamics: float
    information_signal_status: str


@dataclass(frozen=True)
class EvaluationContext:
    """Cached immutable Two-stage inputs, constructed once per experiment."""

    prepared: Any
    device: torch.device
    micro_pij: torch.Tensor
    blocks_t: dict[str, torch.Tensor]
    blocks_tp: dict[str, torch.Tensor]
    fixed_micro_ei: float


class UnsupportedFeatureBuilderError(ValueError):
    """Raised when the no-training baseline cannot safely call a frontend."""


FEATURE_BASED_METHODS = frozenset({"maturity_cci_grn_two_stage"})


def build_context(prepared: Any, *, device: str, mid_dim: int) -> EvaluationContext:
    if prepared.method not in FEATURE_BASED_METHODS:
        raise UnsupportedFeatureBuilderError(
            "The random nullset supports only feature-based macro PIJ builders "
            f"for {sorted(FEATURE_BASED_METHODS)}; got {prepared.method!r}."
        )
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("--device cuda was requested, but CUDA is not available.")
    resolved = torch.device(device)
    micro_pij = torch.as_tensor(prepared.micro_pij, dtype=torch.float32, device=resolved)
    torch_micro_ei = float(effective_information(micro_pij).item())
    if not np.isclose(torch_micro_ei, float(prepared.micro_ei), atol=1e-5, rtol=1e-5):
        raise ValueError("prepared.micro_ei disagrees with Two-stage effective_information.")
    return EvaluationContext(
        prepared=prepared, device=resolved, micro_pij=micro_pij,
        blocks_t={name: torch.as_tensor(value, dtype=torch.float32, device=resolved) for name, value in prepared.feature_blocks_t.items()},
        blocks_tp={name: torch.as_tensor(value, dtype=torch.float32, device=resolved) for name, value in prepared.feature_blocks_tp.items()},
        fixed_micro_ei=float(prepared.micro_ei),
    )


def _assignment(labels: np.ndarray, *, n_units: int, k: int, device: torch.device) -> torch.Tensor:
    values = np.asarray(labels, dtype=np.int64)
    if values.shape != (n_units,) or np.any(values < 0) or np.any(values >= k):
        raise ValueError("Assignment must have one cluster ID in [0, k) for every spot.")
    assignment = functional.one_hot(torch.as_tensor(values, dtype=torch.long, device=device), num_classes=k).to(torch.float32)
    if not bool(torch.all(assignment.sum(dim=0) > 0)):
        raise ValueError("Random assignment contains an empty cluster.")
    return assignment


def build_feature_based_macro_pij(
    context: EvaluationContext,
    assignment_t: torch.Tensor,
    assignment_tp: torch.Tensor,
) -> torch.Tensor:
    """Build macro dynamics through the approved N/X feature builder.

    The currently whitelisted builder reads only pooled ``N`` and ``X``.  Its
    generic ``MacroPijInputs`` interface still requires latent/network fields,
    so small shape-valid placeholders are supplied deliberately rather than
    calculating unused dense macro-network matrices.
    """
    k = int(assignment_t.shape[1])
    placeholder_t = torch.zeros((k, 1), dtype=torch.float32, device=context.device)
    placeholder_tp = torch.zeros((k, 1), dtype=torch.float32, device=context.device)
    return MacroPijInputs(
        z_macro_t=placeholder_t, z_macro_tp=placeholder_tp,
        network_macro_t=placeholder_t, network_macro_tp=placeholder_tp,
        feature_blocks_t=pool_feature_blocks(context.blocks_t, assignment_t),
        feature_blocks_tp=pool_feature_blocks(context.blocks_tp, assignment_tp),
    )


def _feature_based_macro_pij(
    context: EvaluationContext,
    assignment_t: torch.Tensor,
    assignment_tp: torch.Tensor,
) -> torch.Tensor:
    return context.prepared.macro_pij_builder(
        build_feature_based_macro_pij(context, assignment_t, assignment_tp)
    )


def _validate_macro_pij(macro_pij: torch.Tensor, k: int) -> None:
    if macro_pij.shape != (k, k) or not bool(torch.isfinite(macro_pij).all()):
        raise ValueError("Two-stage macro_pij must be finite with shape [K, K].")
    if bool(torch.any(macro_pij < -1e-6)) or not bool(torch.allclose(macro_pij.sum(dim=1), torch.ones(k, device=macro_pij.device), atol=1e-5, rtol=1e-5)):
        raise ValueError("Two-stage macro_pij must be non-negative and row-stochastic.")


def evaluate(context: EvaluationContext, labels_t: np.ndarray, labels_tp: np.ndarray, k: int) -> Evaluation:
    """Evaluate one random hard assignment without gradients, models, or optimization."""
    with torch.no_grad():
        assignment_t = _assignment(labels_t, n_units=context.micro_pij.shape[0], k=k, device=context.device)
        assignment_tp = _assignment(labels_tp, n_units=context.micro_pij.shape[1], k=k, device=context.device)
        macro_pij = _feature_based_macro_pij(context, assignment_t, assignment_tp)
        _validate_macro_pij(macro_pij, k)
        macro_ei = float(effective_information(macro_pij).item())
        future, centers, _ = future_dynamics_centers(context.micro_pij, assignment_t, assignment_tp)
        info = information_closure_metrics(context.micro_pij, assignment_t, assignment_tp, future=future)
        closure = dynamical_closure_loss(context.micro_pij, assignment_t, assignment_tp, macro_pij, future=future)
        within = within_macro_dynamics_loss(context.micro_pij, assignment_t, assignment_tp, future=future, future_centers=centers)
        available = float(info["I_available"].item())
        return Evaluation(
            macro_pij=macro_pij.detach().cpu().numpy(), micro_ei=context.fixed_micro_ei,
            macro_ei=macro_ei, delta_ei=macro_ei - context.fixed_micro_ei,
            i_available=available, i_retained=float(info["I_retained"].item()),
            closure_leakage=float(info["closure_leakage"].item()), closure_quality=float(info["closure_quality"].item()),
            l_closure=float(closure.item()), l_within_dynamics=float(within.item()),
            information_signal_status="near_zero_available_information" if abs(available) <= 1e-6 else "available_information_positive",
        )


def induce_macro_pij_diagnostic(micro_pij: np.ndarray, labels_t: np.ndarray, labels_tp: np.ndarray, k: int) -> np.ndarray:
    """Legacy assignment-induced PIJ, retained only for explicit diagnostics.

    It is intentionally not used by :func:`evaluate`, the runner, or reported
    Two-stage-aligned results.
    """
    pij = np.asarray(micro_pij, dtype=float)
    source = np.asarray(labels_t, dtype=np.int64)
    target = np.asarray(labels_tp, dtype=np.int64)
    if pij.ndim != 2 or source.shape != (pij.shape[0],) or target.shape != (pij.shape[1],):
        raise ValueError("PIJ and diagnostic assignments have incompatible shapes.")
    counts = np.bincount(source, minlength=k)
    if k < 1 or np.any(source < 0) or np.any(source >= k) or np.any(target < 0) or np.any(target >= k) or np.any(counts == 0):
        raise ValueError("Diagnostic assignments must be non-empty cluster IDs in [0, k).")
    target_one_hot = np.zeros((pij.shape[1], k), dtype=float)
    target_one_hot[np.arange(pij.shape[1]), target] = 1.0
    macro = np.zeros((k, k), dtype=float)
    np.add.at(macro, source, pij @ target_one_hot)
    return macro / counts[:, None]
