"""Output helpers for traceable nullset runs."""

from __future__ import annotations

import csv
import json
import os
from pathlib import Path
from typing import Any, Sequence

import numpy as np


SUMMARY_FIELDS = (
    "trial", "seed", "k", "n_t", "n_tp", "micro_ei", "macro_ei", "delta_ei",
    "I_available", "I_retained", "closure_leakage", "closure_quality", "L_closure",
    "L_within_dynamics", "information_signal_status", "assignment_method", "macro_pij_method",
)


def _json_default(value: object) -> object:
    if isinstance(value, Path): return str(value)
    if isinstance(value, np.generic): return value.item()
    raise TypeError(f"Cannot encode {type(value).__name__} as JSON.")


def write_json(path: Path, payload: Any) -> None:
    _atomic_write_text(path, json.dumps(payload, indent=2, ensure_ascii=False, default=_json_default) + "\n")


def read_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def _atomic_path(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    return path.with_name(f".{path.name}.tmp-{os.getpid()}")


def _atomic_write_text(path: Path, content: str) -> None:
    temporary = _atomic_path(path)
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


def write_summary(path: Path, rows: Sequence[dict[str, object]]) -> None:
    temporary = _atomic_path(path)
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=SUMMARY_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def write_assignment(path: Path, unit_ids: Sequence[str], labels: np.ndarray) -> None:
    if len(unit_ids) != len(labels) or len(set(map(str, unit_ids))) != len(unit_ids):
        raise ValueError("Assignment unit IDs must be unique and align one-to-one with labels.")
    temporary = _atomic_path(path)
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(("name", "cluster_id"))
        writer.writerows((str(name), int(cluster)) for name, cluster in zip(unit_ids, labels))
    os.replace(temporary, path)


def statistics(rows: Sequence[dict[str, object]]) -> dict[str, object]:
    delta_ei = np.asarray([float(row["delta_ei"]) for row in rows], dtype=float)
    if delta_ei.size == 0:
        raise ValueError("Cannot calculate statistics without completed trials.")
    def distribution(column: str) -> dict[str, object]:
        values = np.asarray([float(row[column]) for row in rows], dtype=float)
        return {
            "mean": float(values.mean()), "sample_std": None if values.size == 1 else float(values.std(ddof=1)),
            "median": float(np.median(values)), "q2_5": float(np.quantile(values, 0.025)),
            "q97_5": float(np.quantile(values, 0.975)), "min": float(values.min()), "max": float(values.max()),
        }
    return {
        "trial_count": int(delta_ei.size), "delta_ei": distribution("delta_ei"),
        "macro_ei": distribution("macro_ei"), "closure_quality": distribution("closure_quality"),
        "I_available": distribution("I_available"), "I_retained": distribution("I_retained"),
        "delta_ei_positive_count": int((delta_ei > 0).sum()),
        "delta_ei_positive_proportion": float((delta_ei > 0).mean()),
        "near_zero_available_information_count": sum(row["information_signal_status"] == "near_zero_available_information" for row in rows),
        "interval_interpretation": "empirical random-nullset quantiles; not a theoretical confidence interval",
    }
