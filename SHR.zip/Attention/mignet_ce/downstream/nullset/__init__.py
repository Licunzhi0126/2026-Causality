"""Random coarse-graining nullset baseline.

This package evaluates random assignments with the approved feature-based
Two-stage macro PIJ builder.  It does not train a coarse-graining model.
"""

from .config import NullsetConfig
from .runner import run_experiment

__all__ = ["NullsetConfig", "run_experiment"]
