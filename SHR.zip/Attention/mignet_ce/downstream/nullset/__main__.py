from .config import build_argparser, config_from_args
from .runner import run_experiment


def main() -> int:
    config = config_from_args(build_argparser().parse_args())
    rows = run_experiment(config)
    print(f"Completed {len(rows)} random-nullset trials: {config.out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
