"""Configuration and command-line parsing for the random nullset."""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class NullsetConfig:
    h5ad_t: Path
    h5ad_tp: Path
    cci_t: Path
    cci_tp: Path
    grn_t: Path
    grn_tp: Path
    maturity_t: Path
    maturity_tp: Path
    out_dir: Path
    k: int
    n_repeats: int
    seed: int
    cci_index_t: Path | None = None
    cci_index_tp: Path | None = None
    cci_min: float = 0.0
    nmf_components: int = 5
    nmf_max_iter: int = 300
    mid_dim: int = 32
    grn_topk_targets: int = 50
    grn_state_dim: int = 64
    grn_projection_seed: int = 20260713
    grn_feature_method: str = "legacy"
    grn_residual_lambda: float = 0.15
    cci_feature_method: str = "shared_nmf"
    cci_laplacian_components: int = 5
    cci_laplacian_normalized: bool = True
    alpha_cci: float = 0.01
    maturity_id_column: str = "spot_id"
    maturity_column: str = "maturity"
    maturity_confidence_column: str | None = None
    maturity_normalization: str = "minmax"
    maturity_direction: str = "higher_is_more_mature"
    save_macro_pij: bool = False
    device: str = "cpu"
    resume: bool = False
    overwrite: bool = False

    def validate_static(self) -> None:
        if self.k < 1:
            raise ValueError("k must be at least 1.")
        if self.n_repeats < 1:
            raise ValueError("n_repeats must be at least 1.")
        if self.seed < 0:
            raise ValueError("seed must be a non-negative integer.")
        if self.device not in {"cpu", "cuda"}:
            raise ValueError("device must be either 'cpu' or 'cuda'.")
        if self.resume and self.overwrite:
            raise ValueError("--resume and --overwrite are mutually exclusive.")
        if self.nmf_components < 1 or self.nmf_max_iter < 0 or self.mid_dim < 1:
            raise ValueError("NMF components, mid_dim, and NMF max_iter are invalid.")

    def manifest(self) -> dict[str, Any]:
        result = asdict(self)
        return {key: str(value) if isinstance(value, Path) else value for key, value in result.items()}


def build_argparser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Random balanced-assignment nullset; performs no coarse-graining training."
    )
    for name in ("h5ad-t", "h5ad-tp", "cci-t", "cci-tp", "grn-t", "grn-tp", "maturity-t", "maturity-tp"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--cci-index-t", type=Path)
    parser.add_argument("--cci-index-tp", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--n-repeats", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--cci-min", type=float, default=0.0)
    parser.add_argument("--nmf-components", type=int, default=5)
    parser.add_argument("--nmf-max-iter", type=int, default=300)
    parser.add_argument("--mid-dim", type=int, default=32)
    parser.add_argument("--grn-topk-targets", type=int, default=50)
    parser.add_argument("--grn-state-dim", type=int, default=64)
    parser.add_argument("--grn-projection-seed", type=int, default=20260713)
    parser.add_argument("--grn-feature-method", default="legacy")
    parser.add_argument("--grn-residual-lambda", type=float, default=0.15)
    parser.add_argument("--cci-feature-method", choices=("shared_nmf", "laplacian_hks"), default="shared_nmf")
    parser.add_argument("--cci-laplacian-components", type=int, default=5)
    parser.add_argument("--cci-laplacian-unnormalized", action="store_true")
    parser.add_argument("--alpha-cci", type=float, default=0.01)
    parser.add_argument("--maturity-id-column", default="spot_id")
    parser.add_argument("--maturity-column", default="maturity")
    parser.add_argument("--maturity-confidence-column")
    parser.add_argument("--maturity-normalization", choices=("none", "minmax", "rank"), default="minmax")
    parser.add_argument("--maturity-direction", choices=("higher_is_more_mature", "higher_is_more_primitive"), default="higher_is_more_mature")
    parser.add_argument("--save-macro-pij", action="store_true")
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    output_mode = parser.add_mutually_exclusive_group()
    output_mode.add_argument("--resume", action="store_true", help="Skip only a matching completed run.")
    output_mode.add_argument("--overwrite", action="store_true", help="Remove and rerun this exact output directory.")
    return parser


def config_from_args(args: argparse.Namespace) -> NullsetConfig:
    values = vars(args).copy()
    values["cci_laplacian_normalized"] = not values.pop("cci_laplacian_unnormalized")
    config = NullsetConfig(**values)
    config.validate_static()
    return config
