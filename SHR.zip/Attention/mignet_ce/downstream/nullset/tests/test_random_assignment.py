import numpy as np
import pytest

from mignet_ce.downstream.nullset.random_assignment import make_assignment


def test_balanced_assignments_are_reproducible_nonempty_and_independent():
    first = make_assignment(11, 8, 3, 42, 0)
    second = make_assignment(11, 8, 3, 42, 0)
    assert np.array_equal(first.labels_t, second.labels_t)
    assert np.array_equal(first.labels_tp, second.labels_tp)
    for labels in (first.labels_t, first.labels_tp):
        counts = np.bincount(labels, minlength=3)
        assert (counts > 0).all()
        assert counts.max() - counts.min() <= 1
    changed = make_assignment(11, 8, 3, 43, 0)
    assert not np.array_equal(first.labels_t, changed.labels_t)
    assert not np.array_equal(first.labels_t[:8], first.labels_tp)


@pytest.mark.parametrize("k", [0, 9])
def test_invalid_k_is_rejected(k):
    with pytest.raises(ValueError):
        make_assignment(8, 8, k, 1, 0)
