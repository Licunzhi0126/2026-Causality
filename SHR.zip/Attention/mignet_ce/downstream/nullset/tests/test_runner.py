import ast
import csv
from pathlib import Path

import numpy as np
import pytest
import scipy.sparse as sp
import torch

from mignet_ce.representations.coarse_input import MacroPijInputs
from mignet_ce.downstream.nullset.config import NullsetConfig
from mignet_ce.downstream.nullset.reporting import write_assignment
from mignet_ce.downstream.nullset.runner import run_experiment


class FakePrepared:
    method = "maturity_cci_grn_two_stage"
    unit_ids_t = ["a", "b", "c"]
    unit_ids_tp = ["x", "y", "z", "w"]
    micro_pij = np.array([[0.4, 0.3, 0.2, 0.1], [0.1, 0.2, 0.3, 0.4], [0.25, 0.25, 0.25, 0.25]])
    network_t = sp.eye(3, format="csr", dtype=np.float32)
    network_tp = sp.eye(4, format="csr", dtype=np.float32)
    feature_blocks_t = {"N": np.array([[0.0], [1.0], [2.0]], dtype=np.float32), "X": np.ones((3, 2), dtype=np.float32)}
    feature_blocks_tp = {"N": np.array([[0.0], [1.0], [2.0], [3.0]], dtype=np.float32), "X": np.ones((4, 2), dtype=np.float32)}
    micro_ei = None

    def __init__(self):
        from wyt_deltaei_coarse_grain.two_stage_objective import effective_information
        self.micro_ei = float(effective_information(torch.tensor(self.micro_pij, dtype=torch.float32)).item())

    @staticmethod
    def macro_pij_builder(inputs: MacroPijInputs):
        return torch.softmax(-torch.abs(inputs.feature_blocks_t["N"] - inputs.feature_blocks_tp["N"].transpose(0, 1)), dim=1)

    def validate(self):
        return None

    def manifest(self):
        return {"micro_pij_shape": [3, 4], "provenance": {"coarse_method": self.method}}


def _config(tmp_path: Path, **overrides) -> NullsetConfig:
    config = NullsetConfig(**{
        "h5ad_t": Path("t.h5ad"), "h5ad_tp": Path("tp.h5ad"), "cci_t": Path("t.npz"), "cci_tp": Path("tp.npz"),
        "grn_t": Path("t.csv"), "grn_tp": Path("tp.csv"), "maturity_t": Path("t_m.csv"), "maturity_tp": Path("tp_m.csv"),
        "out_dir": tmp_path / "out", "k": 2, "n_repeats": 3, "seed": 7, **overrides,
    })
    return config


def test_runner_prepares_once_and_writes_contract_files(tmp_path):
    calls = []
    def prepare_once(config):
        calls.append(config)
        return FakePrepared()
    rows = run_experiment(_config(tmp_path), prepare_once)
    assert len(calls) == 1
    assert len(rows) == 3
    with (tmp_path / "out" / "summary.csv").open(encoding="utf-8") as handle:
        summary = list(csv.DictReader(handle))
    assert len(summary) == 3
    assert "closure_quality" in summary[0]
    assert summary[0]["macro_pij_method"] == "two_stage_feature_builder"
    with (tmp_path / "out" / "assignments" / "trial_0000_t.csv").open(encoding="utf-8") as handle:
        assignment = list(csv.reader(handle))
    assert assignment[0] == ["name", "cluster_id"]
    assert len(assignment) == 4


def test_duplicate_assignment_names_and_output_collision_fail(tmp_path):
    with pytest.raises(ValueError):
        write_assignment(tmp_path / "bad.csv", ["same", "same"], np.array([0, 1]))
    path = tmp_path / "exists"
    path.mkdir()
    (path / "old.txt").write_text("x", encoding="utf-8")
    with pytest.raises(FileExistsError):
        run_experiment(_config(tmp_path, out_dir=path), lambda _: FakePrepared())


def test_nullset_has_no_import_of_another_downstream_module():
    package = Path(__file__).parents[1]
    for source in package.glob("*.py"):
        tree = ast.parse(source.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            module = getattr(node, "module", "") or ""
            assert not (module.startswith("mignet_ce.downstream.") and ".nullset" not in module)


def test_two_stage_frontend_and_no_training_components_are_used():
    package = Path(__file__).parents[1]
    loader = (package / "data_loader.py").read_text(encoding="utf-8")
    assert "maturity_cci_grn_two_stage import prepare" in loader
    assert "unified_single_stage" not in loader
    source = "\n".join(path.read_text(encoding="utf-8") for path in package.glob("*.py"))
    for forbidden in ("train_deltaei_two_stage", "PrototypeEncoder", "MacroFeatureNet", ".backward(", "torch.optim"):
        assert forbidden not in source
