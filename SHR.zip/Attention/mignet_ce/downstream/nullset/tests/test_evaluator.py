import numpy as np
import pytest
import scipy.sparse as sp
import torch

from mignet_ce.representations.coarse_input import MacroPijInputs
from mignet_ce.downstream.nullset.evaluator import build_context, evaluate
from wyt_deltaei_coarse_grain.macro_builder import pool_feature_blocks
from wyt_deltaei_coarse_grain.two_stage_objective import effective_information, information_closure_metrics


def _builder(inputs: MacroPijInputs) -> torch.Tensor:
    """Small N/X-style builder deliberately independent of macro placeholders."""
    source = inputs.feature_blocks_t["N"]
    target = inputs.feature_blocks_tp["N"]
    return torch.softmax(-torch.abs(source - target.transpose(0, 1)), dim=1)


class FakePrepared:
    method = "maturity_cci_grn_two_stage"
    micro_pij = np.array([[0.7, 0.2, 0.1], [0.1, 0.3, 0.6], [0.4, 0.2, 0.4]], dtype=np.float32)
    network_t = sp.eye(3, format="csr", dtype=np.float32)
    network_tp = sp.eye(3, format="csr", dtype=np.float32)
    feature_blocks_t = {"N": np.array([[0.0], [1.0], [3.0]], dtype=np.float32), "X": np.ones((3, 2), dtype=np.float32)}
    feature_blocks_tp = {"N": np.array([[0.5], [2.0], [4.0]], dtype=np.float32), "X": np.ones((3, 2), dtype=np.float32)}
    macro_pij_builder = staticmethod(_builder)

    def __init__(self):
        self.micro_ei = float(effective_information(torch.tensor(self.micro_pij)).item())


def test_macro_pij_uses_builder_and_not_micro_assignment_induction():
    prepared = FakePrepared()
    context = build_context(prepared, device="cpu", mid_dim=4)
    labels_t, labels_tp = np.array([0, 0, 1]), np.array([1, 0, 1])
    result = evaluate(context, labels_t, labels_tp, 2)
    assignment_t = torch.nn.functional.one_hot(torch.tensor(labels_t, dtype=torch.long), 2).float()
    assignment_tp = torch.nn.functional.one_hot(torch.tensor(labels_tp, dtype=torch.long), 2).float()
    expected = _builder(MacroPijInputs(
        z_macro_t=torch.zeros((2, 4)), z_macro_tp=torch.zeros((2, 4)),
        network_macro_t=torch.eye(2), network_macro_tp=torch.eye(2),
        feature_blocks_t=pool_feature_blocks({key: torch.tensor(value) for key, value in prepared.feature_blocks_t.items()}, assignment_t),
        feature_blocks_tp=pool_feature_blocks({key: torch.tensor(value) for key, value in prepared.feature_blocks_tp.items()}, assignment_tp),
    ))
    assert np.allclose(result.macro_pij, expected.numpy())
    assert result.delta_ei == pytest.approx(result.macro_ei - prepared.micro_ei)


def test_information_metrics_match_two_stage_objective_and_not_one_minus_closure():
    prepared = FakePrepared()
    context = build_context(prepared, device="cpu", mid_dim=4)
    labels_t, labels_tp = np.array([0, 0, 1]), np.array([1, 0, 1])
    result = evaluate(context, labels_t, labels_tp, 2)
    assignment_t = torch.nn.functional.one_hot(torch.tensor(labels_t, dtype=torch.long), 2).float()
    assignment_tp = torch.nn.functional.one_hot(torch.tensor(labels_tp, dtype=torch.long), 2).float()
    reference = information_closure_metrics(torch.tensor(prepared.micro_pij), assignment_t, assignment_tp)
    assert result.i_available == pytest.approx(float(reference["I_available"]))
    assert result.i_retained == pytest.approx(float(reference["I_retained"]))
    assert result.closure_quality == pytest.approx(float(reference["closure_quality"]))
    assert result.closure_quality != pytest.approx(1.0 - result.l_closure)


