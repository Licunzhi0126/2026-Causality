"""Orchestration for a no-training random-assignment nullset experiment."""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import csv
from pathlib import Path
from typing import Callable
import platform
import shutil

import numpy as np

from .config import NullsetConfig
from .data_loader import input_file_fingerprints, prepare_input
from .evaluator import build_context, evaluate
from .random_assignment import make_assignment
from .reporting import read_json, statistics, write_assignment, write_json, write_summary


def _run_fingerprint(config: NullsetConfig, input_fingerprints: dict[str, object]) -> str:
    parameters = config.manifest()
    parameters.pop("resume", None)
    parameters.pop("overwrite", None)
    encoded = json.dumps(
        {"parameters": parameters, "input_file_fingerprints": input_fingerprints},
        sort_keys=True, ensure_ascii=False, separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _is_matching_completed_run(config: NullsetConfig, fingerprint: str) -> bool:
    try:
        status = read_json(config.out_dir / "status.json")
        metadata = read_json(config.out_dir / "metadata.json")
    except (OSError, ValueError, json.JSONDecodeError):
        return False
    if status.get("state") != "completed" or metadata.get("run_fingerprint") != fingerprint:
        return False
    if not (config.out_dir / "summary.csv").is_file() or not (config.out_dir / "statistics.json").is_file():
        return False
    try:
        with (config.out_dir / "summary.csv").open(newline="", encoding="utf-8") as handle:
            if len(list(csv.DictReader(handle))) != config.n_repeats:
                return False
    except OSError:
        return False
    for trial in range(config.n_repeats):
        required = (
            config.out_dir / "assignments" / f"trial_{trial:04d}_t.csv",
            config.out_dir / "assignments" / f"trial_{trial:04d}_tp.csv",
        )
        if not all(path.is_file() for path in required):
            return False
        if config.save_macro_pij and not (config.out_dir / "macro_pij" / f"trial_{trial:04d}.npy").is_file():
            return False
    return True


def _initialize_output(config: NullsetConfig, fingerprint: str) -> bool:
    if config.out_dir.exists() and any(config.out_dir.iterdir()):
        if config.resume and _is_matching_completed_run(config, fingerprint):
            return False
        if config.overwrite:
            shutil.rmtree(config.out_dir)
        elif config.resume:
            raise RuntimeError(
                f"Cannot resume {config.out_dir}: it is incomplete or belongs to different inputs/parameters. "
                "Use --overwrite to rerun this seed directory."
            )
        else:
            raise FileExistsError(
                f"Output directory is non-empty: {config.out_dir}. Use --resume for a matching completed run "
                "or --overwrite to rerun this seed directory."
            )
    config.out_dir.mkdir(parents=True, exist_ok=True)
    (config.out_dir / "assignments").mkdir(exist_ok=True)
    if config.save_macro_pij:
        (config.out_dir / "macro_pij").mkdir(exist_ok=True)
    return True


def run_experiment(config: NullsetConfig, prepare_func: Callable[[NullsetConfig], object] = prepare_input) -> list[dict[str, object]]:
    config.validate_static()
    prepared = prepare_func(config)  # Exactly one public preparation call for all trials.
    prepared.validate()
    n_t, n_tp = len(prepared.unit_ids_t), len(prepared.unit_ids_tp)
    if config.k > min(n_t, n_tp):
        raise ValueError(f"k={config.k} exceeds min(n_t, n_tp)={min(n_t, n_tp)}.")
    fingerprints = input_file_fingerprints(config)
    fingerprint = _run_fingerprint(config, fingerprints)
    if not _initialize_output(config, fingerprint):
        return []
    context = build_context(prepared, device=config.device, mid_dim=config.mid_dim)
    write_json(config.out_dir / "metadata.json", {
        "schema_version": 2, "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "parameters": config.manifest(), "input_file_fingerprints": fingerprints,
        "run_fingerprint": fingerprint,
        "prepared_manifest": prepared.manifest(), "python_version": platform.python_version(),
        "prepare_method": prepared.method, "frontend_method": prepared.method,
        "macro_pij_builder_contract": {
            "method": "two_stage_feature_builder",
            "supported_frontend": prepared.method,
            "coarse_core": prepared.provenance.get("coarse_core", "unknown"),
        },
        "assignment_method": "balanced_random", "macro_pij_method": "two_stage_feature_builder",
        "baseline_definition": "random_hard_balanced_assignment_evaluated_with_two_stage_macro_dynamics",
        "cq_definition": "closure_quality=I_retained/I_available from two_stage_objective.information_closure_metrics",
        "training_enabled": False, "uses_pretrained_macro_model": False,
        "eval_dtype": "float32", "eval_device": config.device,
        "evaluation_note": "Macro PIJ is built by the Two-stage feature builder; no encoder, macro network, optimizer, or checkpoint is used.",
        "cluster_id_base": 0,
    })
    write_json(config.out_dir / "status.json", {"state": "running", "run_fingerprint": fingerprint})
    rows: list[dict[str, object]] = []
    try:
        for trial in range(config.n_repeats):
            assignment = make_assignment(n_t, n_tp, config.k, config.seed, trial)
            result = evaluate(context, assignment.labels_t, assignment.labels_tp, config.k)
            row = {"trial": trial, "seed": config.seed, "k": config.k, "n_t": n_t, "n_tp": n_tp,
                   "micro_ei": result.micro_ei, "macro_ei": result.macro_ei, "delta_ei": result.delta_ei,
                   "I_available": result.i_available, "I_retained": result.i_retained,
                   "closure_leakage": result.closure_leakage, "closure_quality": result.closure_quality,
                   "L_closure": result.l_closure, "L_within_dynamics": result.l_within_dynamics,
                   "information_signal_status": result.information_signal_status,
                   "assignment_method": "balanced_random", "macro_pij_method": "two_stage_feature_builder"}
            rows.append(row)
            write_assignment(config.out_dir / "assignments" / f"trial_{trial:04d}_t.csv", prepared.unit_ids_t, assignment.labels_t)
            write_assignment(config.out_dir / "assignments" / f"trial_{trial:04d}_tp.csv", prepared.unit_ids_tp, assignment.labels_tp)
            if config.save_macro_pij:
                macro_path = config.out_dir / "macro_pij" / f"trial_{trial:04d}.npy"
                temporary = macro_path.with_name(f".{macro_path.name}.tmp")
                with temporary.open("wb") as handle:
                    np.save(handle, result.macro_pij)
                temporary.replace(macro_path)
            write_summary(config.out_dir / "summary.csv", rows)
            write_json(config.out_dir / "statistics.json", statistics(rows))
    except Exception as error:
        write_json(config.out_dir / "status.json", {
            "state": "failed", "run_fingerprint": fingerprint,
            "error_type": type(error).__name__, "error": str(error),
        })
        raise
    write_json(config.out_dir / "status.json", {
        "state": "completed", "run_fingerprint": fingerprint, "trial_count": len(rows),
    })
    return rows
