from __future__ import annotations

import numpy as np
import pytest

from mignet_ce.downstream.perturbation.config import PerturbationConfig
from mignet_ce.downstream.perturbation.grn_io import GRNGraph
from mignet_ce.downstream.perturbation.mirror_perturbation import apply_mirrored_weight_perturbation
from mignet_ce.downstream.perturbation.motif_index import HIGHER_ORDER_TEMPLATES, build_motif_index, motif_edge_participation
from mignet_ce.downstream.perturbation.selection import discover_region, selection_from_region
from mignet_ce.downstream.perturbation.topology_metrics import _HIGHER_METRIC_NAMES, baseline_communities, compute_motif_metrics


def _graph(pair_id: str, *, extra_edge: bool = False, missing_edge: bool = False) -> GRNGraph:
    edges = HIGHER_ORDER_TEMPLATES[pair_id]
    n = 1 + max(max(source, target) for source, target in edges)
    adjacency = np.zeros((n, n), dtype=float)
    for source, target in edges:
        adjacency[source, target] = 1.0
    if missing_edge:
        source, target = edges[0]
        adjacency[source, target] = 0.0
    if extra_edge:
        absent = next((source, target) for source in range(n) for target in range(n) if source != target and adjacency[source, target] == 0.0)
        adjacency[absent] = 1.0
    return GRNGraph(tuple(chr(ord("a") + index) for index in range(n)), adjacency)


@pytest.mark.parametrize("pair_id", tuple(HIGHER_ORDER_TEMPLATES))
def test_each_higher_order_template_has_one_exact_match_and_required_edge_scores(pair_id: str) -> None:
    graph = _graph(pair_id)
    index = build_motif_index(graph, requested_pairs=(pair_id,))
    assert len(index.occurrences(pair_id)) == 1
    assert motif_edge_participation(index, pair_id) == {edge: 1.0 for edge in HIGHER_ORDER_TEMPLATES[pair_id]}
    assert len(set(index.occurrences(pair_id)[0])) == len(index.occurrences(pair_id)[0])
    missing = build_motif_index(_graph(pair_id, missing_edge=True), requested_pairs=(pair_id,))
    assert missing.occurrences(pair_id) == ()


@pytest.mark.parametrize("pair_id", tuple(HIGHER_ORDER_TEMPLATES))
def test_non_induced_extra_edges_do_not_become_required_scored_edges(pair_id: str) -> None:
    graph = _graph(pair_id, extra_edge=True)
    index = build_motif_index(graph, requested_pairs=(pair_id,))
    assert len(index.occurrences(pair_id)) == 1
    assert set(motif_edge_participation(index, pair_id)) == set(HIGHER_ORDER_TEMPLATES[pair_id])


@pytest.mark.parametrize("pair_id", tuple(HIGHER_ORDER_TEMPLATES))
def test_weighted_higher_order_metric_uses_frozen_required_edges(pair_id: str) -> None:
    graph = _graph(pair_id)
    index = build_motif_index(graph, requested_pairs=(pair_id,))
    metric = _HIGHER_METRIC_NAMES[pair_id]
    assert compute_motif_metrics(graph, baseline_scale=1.0, index=index)[metric] == 1.0
    scaled = GRNGraph(graph.nodes, graph.adjacency * 3.0)
    assert compute_motif_metrics(scaled, baseline_scale=1.0, index=index)[metric] == 3.0
    zeroed = graph.copy()
    source, target = HIGHER_ORDER_TEMPLATES[pair_id][0]
    zeroed.adjacency[source, target] = 0.0
    assert compute_motif_metrics(zeroed, baseline_scale=1.0, index=index)[metric] == 0.0


@pytest.mark.parametrize("pair_id", tuple(HIGHER_ORDER_TEMPLATES))
def test_higher_order_selection_and_mirrors_share_edges(pair_id: str) -> None:
    graph = _graph(pair_id)
    region = discover_region(graph, pair_id=pair_id, communities=baseline_communities(graph), seed=17, config=PerturbationConfig(region_node_fraction=1.0, region_edge_fraction=1.0), motif_index=build_motif_index(graph, requested_pairs=(pair_id,)))
    selection = selection_from_region(region, strength=0.2)
    positive, negative, operation = apply_mirrored_weight_perturbation(graph, selected_edges=selection.selected_edges, mirror_fraction=1.0)
    assert selection.selected_edges
    assert operation.selected_edges == selection.selected_edges
    metric = _HIGHER_METRIC_NAMES[pair_id]
    index = build_motif_index(graph, requested_pairs=(pair_id,))
    baseline = compute_motif_metrics(graph, baseline_scale=1.0, index=index)[metric]
    assert compute_motif_metrics(positive, baseline_scale=1.0, index=index)[metric] > baseline
    assert compute_motif_metrics(negative, baseline_scale=1.0, index=index)[metric] < baseline


def test_p9_ignores_a_shortcut_but_p12_requires_it() -> None:
    # A->C is extra for P9, but is a required shortcut for P12.
    p9 = _graph("P9_four_node_feedback_cycle", extra_edge=True)
    p9_index = build_motif_index(p9, requested_pairs=("P9_four_node_feedback_cycle",))
    assert (0, 2) not in motif_edge_participation(p9_index, "P9_four_node_feedback_cycle")
    p12 = _graph("P12_feedback_with_shortcut")
    p12_index = build_motif_index(p12, requested_pairs=("P12_feedback_with_shortcut",))
    assert (0, 2) in motif_edge_participation(p12_index, "P12_feedback_with_shortcut")
