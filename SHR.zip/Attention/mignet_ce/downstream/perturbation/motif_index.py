"""Sparse three-node motif enumeration shared by metrics and perturbation search."""
from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Iterable

import numpy as np

from .grn_io import GRNGraph

Edge = tuple[int, int]

# Role-order is public within this module: every occurrence is a tuple whose
# positions correspond to the letters A, B, ... in the plan's templates.
HIGHER_ORDER_TEMPLATES: dict[str, tuple[Edge, ...]] = {
    "P9_four_node_feedback_cycle": ((0, 1), (1, 2), (2, 3), (3, 0)),
    "P10_multi_path_feedforward": ((0, 1), (1, 3), (0, 2), (2, 3), (0, 3)),
    "P11_bifan_motif": ((0, 2), (0, 3), (1, 2), (1, 3)),
    "P12_feedback_with_shortcut": ((0, 1), (1, 2), (2, 3), (3, 0), (0, 2)),
    "P13_five_node_feedback_cycle": ((0, 1), (1, 2), (2, 3), (3, 4), (4, 0)),
    "P14_five_node_multi_path_feedforward": ((0, 1), (1, 3), (3, 4), (0, 2), (2, 3), (0, 4)),
    "P15_interconnected_feedback_loops": ((0, 1), (1, 2), (2, 0), (2, 3), (3, 4), (4, 2)),
}

# Each permutation maps canonical role positions to equivalent role positions.
# Keeping this explicit makes the intended non-induced matching semantics auditable.
_AUTOMORPHISMS: dict[str, tuple[tuple[int, ...], ...]] = {
    "P9_four_node_feedback_cycle": ((0, 1, 2, 3), (1, 2, 3, 0), (2, 3, 0, 1), (3, 0, 1, 2)),
    "P10_multi_path_feedforward": ((0, 1, 2, 3), (0, 2, 1, 3)),
    "P11_bifan_motif": ((0, 1, 2, 3), (1, 0, 2, 3), (0, 1, 3, 2), (1, 0, 3, 2)),
    "P12_feedback_with_shortcut": ((0, 1, 2, 3),),
    "P13_five_node_feedback_cycle": ((0, 1, 2, 3, 4), (1, 2, 3, 4, 0), (2, 3, 4, 0, 1), (3, 4, 0, 1, 2), (4, 0, 1, 2, 3)),
    "P14_five_node_multi_path_feedforward": ((0, 1, 2, 3, 4), (0, 2, 1, 3, 4)),
    "P15_interconnected_feedback_loops": ((0, 1, 2, 3, 4), (3, 4, 2, 0, 1)),
}


@dataclass(frozen=True)
class MotifIndex:
    """Fixed baseline-support motifs; entries contain node IDs, never weights."""
    triangles: tuple[tuple[int, int, int], ...]
    feedforward_loops: tuple[tuple[int, int, int], ...]
    feedback_cycles: tuple[tuple[int, int, int], ...]
    p9_four_node_feedback_cycles: tuple[tuple[int, ...], ...] = ()
    p10_multi_path_feedforwards: tuple[tuple[int, ...], ...] = ()
    p11_bifan_motifs: tuple[tuple[int, ...], ...] = ()
    p12_feedback_with_shortcuts: tuple[tuple[int, ...], ...] = ()
    p13_five_node_feedback_cycles: tuple[tuple[int, ...], ...] = ()
    p14_five_node_multi_path_feedforwards: tuple[tuple[int, ...], ...] = ()
    p15_interconnected_feedback_loops: tuple[tuple[int, ...], ...] = ()

    def occurrences(self, pair_id: str) -> tuple[tuple[int, ...], ...]:
        """Return role-ordered baseline occurrences for one higher-order template."""
        names = {
            "P9_four_node_feedback_cycle": "p9_four_node_feedback_cycles",
            "P10_multi_path_feedforward": "p10_multi_path_feedforwards",
            "P11_bifan_motif": "p11_bifan_motifs",
            "P12_feedback_with_shortcut": "p12_feedback_with_shortcuts",
            "P13_five_node_feedback_cycle": "p13_five_node_feedback_cycles",
            "P14_five_node_multi_path_feedforward": "p14_five_node_multi_path_feedforwards",
            "P15_interconnected_feedback_loops": "p15_interconnected_feedback_loops",
        }
        try:
            return getattr(self, names[pair_id])
        except KeyError as error:
            raise ValueError(f"Not a higher-order motif pair: {pair_id}") from error

    @property
    def motif_edges(self) -> tuple[Edge, ...]:
        edges: set[Edge] = set()
        for i, j, k in self.triangles:
            edges.update(((i, j), (j, i), (j, k), (k, j), (i, k), (k, i)))
        for a, b, c in self.feedforward_loops:
            edges.update(((a, b), (a, c), (b, c)))
        for a, b, c in self.feedback_cycles:
            edges.update(((a, b), (b, c), (c, a)))
        for pair_id, template_edges in HIGHER_ORDER_TEMPLATES.items():
            for occurrence in self.occurrences(pair_id):
                edges.update((occurrence[source], occurrence[target]) for source, target in template_edges)
        return tuple(sorted(edges))


def _canonical_occurrence(occurrence: tuple[int, ...], automorphisms: tuple[tuple[int, ...], ...]) -> tuple[int, ...]:
    return min(tuple(occurrence[role] for role in permutation) for permutation in automorphisms)


def _enumerate_template(outgoing: tuple[set[int], ...], incoming: tuple[set[int], ...], *, edges: tuple[Edge, ...], automorphisms: tuple[tuple[int, ...], ...]) -> tuple[tuple[int, ...], ...]:
    """Sparse backtracking enumeration; no all-node k-combinations are built."""
    role_count = 1 + max(max(source, target) for source, target in edges)
    incident = [{role: [] for role in range(role_count)} for _ in range(role_count)]
    for source, target in edges:
        incident[source][target].append(("out", target))
        incident[target][source].append(("in", source))
    # Start from the most constrained role and require every subsequent role to
    # connect to an assigned role whenever the template permits it.
    role_order = sorted(range(role_count), key=lambda role: (-sum(len(v) for v in incident[role].values()), role))
    found: set[tuple[int, ...]] = set()

    def visit(position: int, assigned: dict[int, int], used: set[int]) -> None:
        if position == role_count:
            occurrence = tuple(assigned[role] for role in range(role_count))
            found.add(_canonical_occurrence(occurrence, automorphisms))
            return
        role = role_order[position]
        candidate_sets: list[set[int]] = []
        for other, constraints in incident[role].items():
            if other not in assigned:
                continue
            other_node = assigned[other]
            for direction, _ in constraints:
                candidate_sets.append(outgoing[other_node] if direction == "in" else incoming[other_node])
        candidates = set.intersection(*candidate_sets) if candidate_sets else set(range(len(outgoing)))
        for node in sorted(candidates - used):
            assigned[role] = node
            used.add(node)
            visit(position + 1, assigned, used)
            used.remove(node)
            del assigned[role]

    visit(0, {}, set())
    return tuple(sorted(found))


def build_motif_index(graph: GRNGraph, *, requested_pairs: Iterable[str] | None = None) -> MotifIndex:
    """Enumerate only motifs present in the fixed directed edge support."""
    adjacency = graph.adjacency
    if np.any(adjacency < 0.0):
        raise ValueError("Weighted motif interventions require non-negative GRN weights.")
    n = len(graph.nodes)
    outgoing = tuple(set(np.flatnonzero(adjacency[i] > 0.0).tolist()) - {i} for i in range(n))
    incoming = tuple(set(np.flatnonzero(adjacency[:, i] > 0.0).tolist()) - {i} for i in range(n))
    undirected = tuple(outgoing[i] | set(np.flatnonzero(adjacency[:, i] > 0.0).tolist()) - {i} for i in range(n))
    triangles: list[tuple[int, int, int]] = []
    for i in range(n):
        for j, k in combinations(sorted(node for node in undirected[i] if node > i), 2):
            if k in undirected[j]:
                triangles.append((i, j, k))
    ffl: list[tuple[int, int, int]] = []
    for a in range(n):
        for b in outgoing[a]:
            for c in outgoing[a] & outgoing[b]:
                if c != b:
                    ffl.append((a, b, c))
    cycles: list[tuple[int, int, int]] = []
    for a in range(n):
        for b in outgoing[a]:
            for c in outgoing[b]:
                if c != a and a in outgoing[c] and a < b and a < c:
                    cycles.append((a, b, c))
    requested = set(requested_pairs or ())
    unknown = requested - set(HIGHER_ORDER_TEMPLATES) - {"P6_triangle_intensity", "P7_feedforward_loop", "P8_feedback_cycle"}
    if unknown:
        raise ValueError(f"Unknown motif pairs requested: {sorted(unknown)}")
    higher = {
        pair_id: _enumerate_template(outgoing, incoming, edges=edges, automorphisms=_AUTOMORPHISMS[pair_id])
        for pair_id, edges in HIGHER_ORDER_TEMPLATES.items() if pair_id in requested
    }
    return MotifIndex(tuple(triangles), tuple(ffl), tuple(cycles),
        higher.get("P9_four_node_feedback_cycle", ()), higher.get("P10_multi_path_feedforward", ()),
        higher.get("P11_bifan_motif", ()), higher.get("P12_feedback_with_shortcut", ()),
        higher.get("P13_five_node_feedback_cycle", ()), higher.get("P14_five_node_multi_path_feedforward", ()),
        higher.get("P15_interconnected_feedback_loops", ()))


def motif_edge_participation(index: MotifIndex, pair_id: str) -> dict[Edge, float]:
    """Unweighted participation counts used only to freeze a candidate edge region."""
    counts: dict[Edge, float] = {}
    if pair_id == "P6_triangle_intensity":
        for i, j, k in index.triangles:
            for edge in ((i, j), (j, i), (j, k), (k, j), (i, k), (k, i)):
                counts[edge] = counts.get(edge, 0.0) + 1.0
    elif pair_id == "P7_feedforward_loop":
        for a, b, c in index.feedforward_loops:
            for edge in ((a, b), (a, c), (b, c)):
                counts[edge] = counts.get(edge, 0.0) + 1.0
    elif pair_id == "P8_feedback_cycle":
        for a, b, c in index.feedback_cycles:
            for edge in ((a, b), (b, c), (c, a)):
                counts[edge] = counts.get(edge, 0.0) + 1.0
    elif pair_id in HIGHER_ORDER_TEMPLATES:
        for occurrence in index.occurrences(pair_id):
            for source_role, target_role in HIGHER_ORDER_TEMPLATES[pair_id]:
                edge = (occurrence[source_role], occurrence[target_role])
                counts[edge] = counts.get(edge, 0.0) + 1.0
    else:
        raise ValueError(f"Not a motif pair: {pair_id}")
    return counts
