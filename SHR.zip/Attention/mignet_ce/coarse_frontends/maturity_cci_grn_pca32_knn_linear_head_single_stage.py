from __future__ import annotations

"""Method 8 frontend: method-7 inputs with PCA KNN graph provenance."""

from mignet_ce.coarse_frontends._common import CoarseFrontendRequest
from mignet_ce.coarse_frontends._maturity_cci_grn_common import prepare_maturity_cci_grn
from mignet_ce.representations.coarse_input import PreparedCoarseInput


METHOD = "maturity_cci_grn_pca32_knn_linear_head_single_stage"


def prepare(request: CoarseFrontendRequest) -> PreparedCoarseInput:
    return prepare_maturity_cci_grn(request, method=METHOD)
