from __future__ import annotations
from dataclasses import dataclass

PCA32_KNN_LINEAR_HEAD_SINGLE_STAGE = "pca32_knn_linear_head_single_stage"
BIDIRECTIONAL_CROSS_TIME_ATTENTION_SINGLE_STAGE = "bidirectional_cross_time_attention_single_stage"

@dataclass(frozen=True)
class CoarseMethodSpec:
    name: str
    training_mode: str
    frontend: str
    requires_maturity: bool = True
    requires_cci: bool = True
    requires_grn: bool = True
    default_lambda_dev: float = .05
    objective_version: str = ""

COARSE_METHOD_SPECS = {
    "maturity_cci_grn_pca32_knn_linear_head_single_stage": CoarseMethodSpec("maturity_cci_grn_pca32_knn_linear_head_single_stage", PCA32_KNN_LINEAR_HEAD_SINGLE_STAGE, "maturity_cci_grn_pca32_knn_linear_head_single_stage", objective_version="wyt_pca32_knn_linear_head_single_stage_v1"),
    "maturity_cci_grn_bidirectional_cross_time_attention_single_stage": CoarseMethodSpec("maturity_cci_grn_bidirectional_cross_time_attention_single_stage", BIDIRECTIONAL_CROSS_TIME_ATTENTION_SINGLE_STAGE, "maturity_cci_grn_bidirectional_cross_time_attention_single_stage", objective_version="wyt_bidirectional_cross_time_attention_single_stage_v1"),
}

def get_coarse_method_spec(method: str) -> CoarseMethodSpec:
    try: return COARSE_METHOD_SPECS[method]
    except KeyError as exc: raise ValueError(f"Unknown coarse method {method!r}; expected one of {sorted(COARSE_METHOD_SPECS)}.") from exc

def training_mode_for_method(method: str) -> str:
    return get_coarse_method_spec(method).training_mode
