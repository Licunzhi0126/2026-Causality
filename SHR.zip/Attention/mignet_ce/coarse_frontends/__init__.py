"""The two supported coarse-graining frontend APIs."""
from mignet_ce.coarse_frontends.method_specs import BIDIRECTIONAL_CROSS_TIME_ATTENTION_SINGLE_STAGE, PCA32_KNN_LINEAR_HEAD_SINGLE_STAGE, COARSE_METHOD_SPECS, CoarseMethodSpec, get_coarse_method_spec, training_mode_for_method
__all__ = ["COARSE_FRONTEND_REGISTRY", "COARSE_METHOD_SPECS", "CoarseMethodSpec", "CoarseFrontendRequest", "PCA32_KNN_LINEAR_HEAD_SINGLE_STAGE", "BIDIRECTIONAL_CROSS_TIME_ATTENTION_SINGLE_STAGE", "get_coarse_method_spec", "prepare_coarse_input", "training_mode_for_method"]
def __getattr__(name: str):
    if name == "CoarseFrontendRequest":
        from mignet_ce.coarse_frontends._common import CoarseFrontendRequest
        return CoarseFrontendRequest
    if name in {"COARSE_FRONTEND_REGISTRY", "prepare_coarse_input"}:
        from mignet_ce.coarse_frontends.registry import COARSE_FRONTEND_REGISTRY, prepare_coarse_input
        return {"COARSE_FRONTEND_REGISTRY": COARSE_FRONTEND_REGISTRY, "prepare_coarse_input": prepare_coarse_input}[name]
    raise AttributeError(name)
