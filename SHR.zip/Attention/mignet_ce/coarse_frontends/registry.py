from __future__ import annotations
from typing import Callable
from mignet_ce.coarse_frontends._common import CoarseFrontendRequest
from mignet_ce.coarse_frontends.maturity_cci_grn_pca32_knn_linear_head_single_stage import prepare as prepare_method8
from mignet_ce.coarse_frontends.maturity_cci_grn_bidirectional_cross_time_attention_single_stage import prepare as prepare_method10
from mignet_ce.representations.coarse_input import PreparedCoarseInput

COARSE_FRONTEND_REGISTRY: dict[str, Callable[[CoarseFrontendRequest], PreparedCoarseInput]] = {
    "maturity_cci_grn_pca32_knn_linear_head_single_stage": prepare_method8,
    "maturity_cci_grn_bidirectional_cross_time_attention_single_stage": prepare_method10,
}

def prepare_coarse_input(method: str, request: CoarseFrontendRequest) -> PreparedCoarseInput:
    try: frontend = COARSE_FRONTEND_REGISTRY[method]
    except KeyError as exc: raise ValueError(f"Unknown coarse frontend {method!r}; expected one of {sorted(COARSE_FRONTEND_REGISTRY)}.") from exc
    return frontend(request)
