from __future__ import annotations

"""Method 10 frontend: stable maturity+CCI+GRN preparation with a new identity."""

from mignet_ce.coarse_frontends._common import CoarseFrontendRequest
from mignet_ce.coarse_frontends._maturity_cci_grn_common import prepare_maturity_cci_grn
from mignet_ce.representations.coarse_input import PreparedCoarseInput


METHOD = "maturity_cci_grn_bidirectional_cross_time_attention_single_stage"


def prepare(request: CoarseFrontendRequest) -> PreparedCoarseInput:
    return prepare_maturity_cci_grn(request, method=METHOD)
