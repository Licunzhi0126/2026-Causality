#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from mignet_ce.coarse_frontends import COARSE_METHOD_SPECS
from mignet_ce.coarse_frontends.method_specs import LOCAL_GRAPH_MODES

METHOD_CHOICES = tuple(sorted(COARSE_METHOD_SPECS))


def build_argparser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        allow_abbrev=False,
        description="Run WYT FeatureAlign-DeltaEI coarse graining from spot H5AD and CCI inputs."
    )
    parser.add_argument("--method", choices=METHOD_CHOICES, required=True)
    parser.add_argument("--h5ad-t", type=Path, required=True)
    parser.add_argument("--h5ad-tp", type=Path, required=True)
    parser.add_argument("--cci-t", type=Path, required=True)
    parser.add_argument("--cci-tp", type=Path, required=True)
    parser.add_argument("--cci-index-t", type=Path, default=None)
    parser.add_argument("--cci-index-tp", type=Path, default=None)
    parser.add_argument("--grn-t", type=Path, default=None)
    parser.add_argument("--grn-tp", type=Path, default=None)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--maturity-t", type=Path, default=None)
    parser.add_argument("--maturity-tp", type=Path, default=None)
    parser.add_argument("--maturity-id-column", default="spot_id")
    parser.add_argument("--maturity-column", default="maturity")
    parser.add_argument("--maturity-confidence-column", default=None)
    parser.add_argument(
        "--maturity-normalization",
        choices=["none", "minmax", "rank"],
        default="minmax",
    )
    parser.add_argument(
        "--maturity-direction",
        choices=["higher_is_more_mature", "higher_is_more_primitive"],
        default="higher_is_more_mature",
    )

    parser.add_argument("--cci-min", type=float, default=0.0)
    parser.add_argument("--regsim-knn-k", type=int, default=50)
    parser.add_argument("--regsim-weight", type=float, default=0.2)
    parser.add_argument("--network-svd-dim", type=int, default=32)
    parser.add_argument("--nmf-components", type=int, default=5)
    parser.add_argument("--nmf-max-iter", type=int, default=300)
    parser.add_argument("--pij-temperature", type=float, default=1.0)
    parser.add_argument("--grn-topk-targets", type=int, default=50)
    parser.add_argument("--grn-state-dim", type=int, default=64)
    parser.add_argument("--grn-projection-seed", type=int, default=20260713)
    parser.add_argument("--grn-knn-k", type=int, default=50)
    parser.add_argument("--grn-graph-weight", type=float, default=0.2)
    parser.add_argument("--grn-feature-method", choices=["legacy", "legacy_nmf", "legacy_lap_hks"], default="legacy")
    parser.add_argument("--grn-residual-lambda", type=float, default=0.15)
    parser.add_argument("--cci-feature-method", choices=["shared_nmf", "laplacian_hks"], default="shared_nmf")
    parser.add_argument("--cci-laplacian-components", type=int, default=5)
    parser.add_argument("--alpha-cci", type=float, default=0.01)

    parser.add_argument("--hidden-dim", type=int, default=64)
    parser.add_argument("--mid-dim", type=int, default=32)
    parser.add_argument("--gnn-layers", type=int, default=2)
    parser.add_argument("--macro-layers", type=int, default=2)
    parser.add_argument("--knn-k", type=int, default=30)
    parser.add_argument("--local-dims", type=int, default=2)
    parser.add_argument(
        "--local-graph-mode",
        choices=LOCAL_GRAPH_MODES,
        default=None,
        help="Defaults to all_features for formal_two_stage and legacy_features for other methods.",
    )
    parser.add_argument("--temperature", type=float, default=0.07)
    parser.add_argument("--align-temperature", type=float, default=1.0)
    parser.add_argument("--epochs", type=int, default=1500)
    parser.add_argument("--lr", type=float, default=5e-4)

    parser.add_argument("--lambda-align", type=float, default=None,
                        help="Defaults to 0 for formal_two_stage and 1 for the original methods.")
    parser.add_argument("--lambda-ei", type=float, default=1.0)
    parser.add_argument("--lambda-var", type=float, default=1.0)
    parser.add_argument("--lambda-local", type=float, default=0.1)
    parser.add_argument("--lambda-sharp", type=float, default=0.02)
    parser.add_argument("--lambda-proto", type=float, default=0.2)
    parser.add_argument("--lambda-min-usage", type=float, default=10.0)
    parser.add_argument("--lambda-max-usage", type=float, default=10.0)
    parser.add_argument("--lambda-cq", type=float, default=None)
    parser.add_argument("--lambda-available-floor", type=float, default=None)
    parser.add_argument("--lambda-retained-floor-abs", type=float, default=None)
    parser.add_argument("--retained-floor-abs", type=float, default=None)
    parser.add_argument("--stage1-ratio", type=float, default=None)
    parser.add_argument("--lambda-stage1-closure", type=float, default=None)
    parser.add_argument("--lambda-stage2-cq", type=float, default=None)
    parser.add_argument("--report-hard-occupancy", action="store_true")
    parser.add_argument("--ei-loss-retain-ratio", type=float, default=None)
    parser.add_argument("--lambda-gap", type=float, default=None)
    parser.add_argument("--gap-temperature", type=float, default=None)
    parser.add_argument("--gap-count-temperature", type=float, default=None)
    parser.add_argument("--stage1-only", action="store_true")
    parser.add_argument("--stage1-source", type=Path)
    parser.add_argument("--prepared-cache", type=Path)
    parser.add_argument("--ei-retain-ratio", type=float, default=None)
    parser.add_argument("--lambda-ei-constraint", type=float, default=None)
    parser.add_argument("--lambda-closure", type=float, default=None)
    parser.add_argument("--lambda-within", type=float, default=None)
    parser.add_argument("--lambda-inter", type=float, default=None)
    parser.add_argument("--lambda-retain-norm", type=float, default=None)
    parser.add_argument("--retain-floor-ratio", type=float, default=None)
    parser.add_argument("--lambda-retain-floor", type=float, default=None)
    parser.add_argument("--inter-margin", type=float, default=None)
    parser.add_argument("--active-usage-threshold", type=float, default=None)
    parser.add_argument("--keff-min", type=float, default=None)
    parser.add_argument("--checkpoint-keff-min", type=float, default=None)
    parser.add_argument("--lambda-keff", type=float, default=None)
    parser.add_argument("--lambda-dead-usage", type=float, default=None)
    parser.add_argument("--min-usage", type=float, default=None)
    parser.add_argument("--low-signal-pair-weight", type=float, default=None)
    parser.add_argument("--low-signal-threshold-bits", type=float, default=None)
    parser.add_argument("--checkpoint-retain-ratio", type=float, default=None)
    parser.add_argument(
        "--lambda-dev",
        type=float,
        default=None,
        help=(
            "Maturity-loss weight. Defaults to 2 for formal_two_stage, 0.05 for "
            "the original maturity methods, and 0 for non-maturity methods."
        ),
    )
    parser.add_argument("--development-min-state-mass", type=float, default=1e-8)
    parser.add_argument("--embedding-target-std", type=float, default=0.05)
    parser.add_argument("--prototype-max-cosine", type=float, default=0.2)
    parser.add_argument("--min-usage-frac", type=float, default=0.01)
    parser.add_argument("--max-usage-frac", type=float, default=8.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", choices=["cpu", "cuda", "auto"], default="cpu")
    parser.add_argument("--log-every", type=int, default=50)
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_argparser().parse_args(argv)
    from mignet_ce.coarse_frontends import (
        CoarseFrontendRequest,
        CQ_ONLY, DYNAMIC_CLOSURE_TWO_STAGE,
        get_coarse_method_spec,
        prepare_coarse_input,
    )
    from wyt_deltaei_coarse_grain import (
        WYTDeltaEIConfig,
        WYTTwoStageDeltaEIConfig,
        train_deltaei,
    )

    method_spec = get_coarse_method_spec(args.method)
    loss_ablation = (
        args.lambda_stage1_closure is not None
        or args.lambda_stage2_cq is not None
        or args.report_hard_occupancy
    )
    if loss_ablation and args.method not in {"maturity_cci_grn_two_stage", "formal_two_stage"}:
        raise SystemExit("Loss ablation options require maturity_cci_grn_two_stage.")
    if args.method != "formal_two_stage" and any((
        args.ei_loss_retain_ratio is not None, args.lambda_gap is not None,
        args.gap_temperature is not None, args.gap_count_temperature is not None,
        args.stage1_only, args.stage1_source is not None, args.prepared_cache is not None,
    )):
        raise SystemExit("Formal training controls require formal_two_stage.")
    lambda_dev = (
        float(args.lambda_dev)
        if args.lambda_dev is not None
        else method_spec.default_lambda_dev
    )
    if method_spec.requires_maturity:
        if args.maturity_t is None or args.maturity_tp is None:
            raise SystemExit(
                f"{args.method} requires --maturity-t and --maturity-tp."
            )
        if lambda_dev <= 0.0:
            raise SystemExit(f"{args.method} requires --lambda-dev > 0.")
    if method_spec.requires_grn and (
        args.grn_t is None or args.grn_tp is None
    ):
        raise SystemExit(
            f"{args.method} requires --grn-t and --grn-tp."
        )
    frontend_request = CoarseFrontendRequest(
        h5ad_t=args.h5ad_t,
        h5ad_tp=args.h5ad_tp,
        cci_t=args.cci_t,
        cci_tp=args.cci_tp,
        cci_index_t=args.cci_index_t,
        cci_index_tp=args.cci_index_tp,
        cci_min=args.cci_min,
        regsim_knn_k=args.regsim_knn_k,
        regsim_weight=args.regsim_weight,
        network_svd_dim=args.network_svd_dim,
        mid_dim=args.mid_dim,
        nmf_components=args.nmf_components,
        nmf_max_iter=args.nmf_max_iter,
        seed=args.seed,
        pij_temperature=args.pij_temperature,
        grn_t=args.grn_t,
        grn_tp=args.grn_tp,
        grn_topk_targets=args.grn_topk_targets,
        grn_state_dim=args.grn_state_dim,
        grn_projection_seed=args.grn_projection_seed,
        grn_knn_k=args.grn_knn_k,
        grn_graph_weight=args.grn_graph_weight,
        grn_feature_method=args.grn_feature_method,
        grn_residual_lambda=args.grn_residual_lambda,
        cci_feature_method=args.cci_feature_method,
        cci_laplacian_components=args.cci_laplacian_components,
        alpha_cci=args.alpha_cci,
        maturity_t=args.maturity_t,
        maturity_tp=args.maturity_tp,
        maturity_id_column=args.maturity_id_column,
        maturity_column=args.maturity_column,
        maturity_confidence_column=args.maturity_confidence_column,
        maturity_normalization=args.maturity_normalization,
        maturity_direction=args.maturity_direction,
    )
    if args.prepared_cache is not None:
        from joblib.externals import cloudpickle

        with args.prepared_cache.open("rb") as stream:
            prepared = cloudpickle.load(stream)
        if prepared.method != args.method:
            raise ValueError("Prepared cache method does not match the requested method.")
        for key in ("h5ad_t", "h5ad_tp", "cci_t", "cci_tp", "grn_t", "grn_tp"):
            recorded = prepared.provenance.get(key)
            if recorded is None and key in {"grn_t", "grn_tp"}:
                stage_key = "stage_t" if key == "grn_t" else "stage_tp"
                recorded = prepared.provenance.get(stage_key, {}).get("grn_path")
            requested = getattr(args, key).resolve()
            if recorded is None or requested != Path(recorded).resolve():
                raise ValueError(
                    f"Prepared cache input does not match --{key.replace('_', '-')}: "
                    f"requested={requested}, cached={recorded}"
                )
        prepared.validate()
    else:
        prepared = prepare_coarse_input(args.method, frontend_request)
    from wyt_deltaei_coarse_grain.training_config import build_training_config
    if method_spec.training_mode in {DYNAMIC_CLOSURE_TWO_STAGE, CQ_ONLY}:
        if args.out_dir.exists() and any(args.out_dir.iterdir()):
            raise SystemExit(f"Output directory is not empty and will not be overwritten: {args.out_dir}")
    config = build_training_config(args)
    if loss_ablation and args.method != "formal_two_stage":
        from dataclasses import asdict
        from wyt_deltaei_coarse_grain.two_stage_trainer import WYTTwoStageLossAblationConfig

        config = WYTTwoStageLossAblationConfig(
            **asdict(config),
            lambda_stage1_closure=args.lambda_stage1_closure or 0.0,
            lambda_stage2_cq=args.lambda_stage2_cq or 0.0,
            report_hard_occupancy=args.report_hard_occupancy,
        )
    result = train_deltaei(prepared, config)
    print(
        f"completed method={args.method} K={args.k} "
        f"best_epoch={result.best_epoch} delta_EI={result.final_delta_ei:.6f} "
        f"out={result.out_dir}"
    )


if __name__ == "__main__":
    main()
