from __future__ import annotations

from typing import Dict, Type

from mignet_ce.networks.base import NetworkBuilder
from mignet_ce.networks.clean_expression_cci_mix import CleanExpressionCCIMixBuilder
from mignet_ce.networks.clean_grn_cci_mix import CleanGRNCCIMixBuilder
from mignet_ce.networks.clean_grn_cci_expr_mix import CleanGRNCCIExpressionMixBuilder
from mignet_ce.networks.cross_cell_multilayer import CrossCellMultilayerBuilder
from mignet_ce.networks.expression_only import ExpressionOnlyBuilder
from mignet_ce.networks.legacy_inter_additive_grn_cci import LegacyInterAdditiveGRNCCIBuilder
from mignet_ce.networks.legacy_inter_cci_only import LegacyInterCCIOnlyBuilder
from mignet_ce.networks.legacy_mixed_grn_cci import LegacyMixedGRNCCIBuilder
from mignet_ce.networks.joint_cci_grn import JointCCIGRNNetworkBuilder
from mignet_ce.networks.light_cci import LightCCINetworkBuilder
from mignet_ce.networks.light_cci_grn import LightCCIGRNNetworkBuilder
from mignet_ce.networks.light_cci_grn_pgr import LightCCIGRNPGRNetworkBuilder
from mignet_ce.networks.unit_specific_clean_grn_cci_mix import UnitSpecificCleanGRNCCIMixBuilder


NETWORK_BUILDERS: Dict[str, Type[NetworkBuilder]] = {
    "legacy_mixed_grn_cci": LegacyMixedGRNCCIBuilder,
    "legacy_inter_cci_only": LegacyInterCCIOnlyBuilder,
    "legacy_inter_additive_grn_cci": LegacyInterAdditiveGRNCCIBuilder,
    "clean_grn_cci_mix": CleanGRNCCIMixBuilder,
    "clean_grn_cci_expr_mix": CleanGRNCCIExpressionMixBuilder,
    "clean_expression_cci_mix": CleanExpressionCCIMixBuilder,
    "unit_specific_clean_grn_cci_mix": UnitSpecificCleanGRNCCIMixBuilder,
    "cross_cell_multilayer": CrossCellMultilayerBuilder,
    "expression_only": ExpressionOnlyBuilder,
    "light_cci": LightCCINetworkBuilder,
    "light_cci_grn": LightCCIGRNNetworkBuilder,
    "light_cci_grn_pgr": LightCCIGRNPGRNetworkBuilder,
    "joint_cci_grn": JointCCIGRNNetworkBuilder,
}


def get_network_builder(network_method: str) -> NetworkBuilder:
    try:
        builder_cls = NETWORK_BUILDERS[network_method]
    except KeyError as exc:
        raise ValueError(f"Unsupported network_method {network_method!r}. Expected one of {sorted(NETWORK_BUILDERS)}.") from exc
    return builder_cls()
