from __future__ import annotations

"""Full-scale cache preparation for the formal unified downstream workflow."""

from dataclasses import asdict
from pathlib import Path
from typing import Any
import json

import numpy as np
import pandas as pd
import scipy.sparse as sp

from .config import (
    FORMAL_CACHE_PROTOCOL,
    FORMAL_TRANSITION_PROTOCOL,
    MAPPING_COMPLETE,
    MAPPING_MATURITY,
    MAPPING_TWO_STAGE,
    UnifiedDownstreamConfig,
)
from mignet_ce.pij.compare._shared.ng_kl_ot import canonical_transition_contract
from .dynamic_closure.optimal import prepare_ngklot_pair
from .io import cci_index_path, cci_path, grn_path, layer_h5ad, read_index
from .mappings import (
    OPTIMIZED_METHOD_BY_MAPPING,
    natural_cache_manifest_path,
    natural_cache_path,
    optimized_pair_dir,
)
from .metrics import row_normalize


NATURAL_LAYERS = ("spot", "seurat_k150", "seurat_k40")
COMMON_OPTIMIZED_OUTPUTS = (
    "config.json",
    "input_manifest.json",
    "feature_manifest.json",
    "summary.json",
    "S_t.npy",
    "S_tp.npy",
    "PIJ_micro_train.npy",
    "PIJ_macro_train.npy",
    "assignments_t.csv",
    "assignments_tp.csv",
)


def required_optimized_outputs(method: str) -> tuple[str, ...]:
    from mignet_ce.coarse_frontends.method_specs import (
        DYNAMIC_CLOSURE_TWO_STAGE,
        get_coarse_method_spec,
    )

    mode = get_coarse_method_spec(method).training_mode
    checkpoints = (
        ("best_ei.pt", "best_joint.pt")
        if mode == DYNAMIC_CLOSURE_TWO_STAGE
        else ("best_model.pt",)
    )
    return COMMON_OPTIMIZED_OUTPUTS + checkpoints


def _write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _input_descriptor(path: Path) -> dict[str, object]:
    source = Path(path).resolve()
    stat = source.stat()
    return {
        "path": str(source),
        "size": int(stat.st_size),
        "mtime_ns": int(stat.st_mtime_ns),
    }


def stage_input_paths(
    cfg: UnifiedDownstreamConfig,
    layer: str,
    time: str,
) -> dict[str, Path]:
    return {
        "h5ad": layer_h5ad(cfg.data_root, layer, time, cfg.organ),
        "cci": cci_path(cfg.data_root, layer, time, cfg.organ),
        "index": cci_index_path(cfg.data_root, layer, time, cfg.organ),
        "grn": grn_path(cfg.data_root, layer, time, cfg.organ),
    }


def _maturity_source(cfg: UnifiedDownstreamConfig, time: str) -> tuple[str, Path]:
    root = (
        Path(cfg.developmental_feature_root)
        if cfg.developmental_feature_root is not None
        else Path(cfg.data_root) / "developmental_features"
    )
    direct = root / "maturity" / f"{cfg.organ}_{time}_maturity.csv"
    if direct.exists():
        return "maturity", direct
    features = root / "spot" / f"{cfg.organ}_{time}_features.csv"
    if features.exists():
        return "developmental_features", features
    raise FileNotFoundError(
        f"Maturity input for {cfg.organ} {time} is missing; expected {direct} or {features}"
    )


def _validated_maturity_source(
    cfg: UnifiedDownstreamConfig,
    time: str,
) -> tuple[str, Path, str, str]:
    """Validate maturity schema and spot coverage before any DeltaEI training."""

    kind, source = _maturity_source(cfg, time)
    expected_columns = {"spot_id", "unit_id", "maturity", "pseudotime"}
    frame = pd.read_csv(source, usecols=lambda column: column in expected_columns)
    id_column = (
        "spot_id"
        if kind == "maturity" and "spot_id" in frame
        else (
            "spot_id"
            if "spot_id" in frame
            else "unit_id" if kind == "developmental_features" and "unit_id" in frame else ""
        )
    )
    value_column = "maturity" if kind == "maturity" else "pseudotime"
    if not id_column or value_column not in frame:
        expected = (
            "spot_id + maturity"
            if kind == "maturity"
            else "unit_id/spot_id + pseudotime"
        )
        raise ValueError(f"{source} must contain {expected}")
    ids = frame[id_column].astype(str)
    if ids.duplicated().any():
        duplicates = ids[ids.duplicated()].head(10).tolist()
        raise ValueError(f"Maturity input {source} contains duplicate IDs: {duplicates}")
    values = pd.to_numeric(frame[value_column], errors="coerce").to_numpy(dtype=float)
    if not np.isfinite(values).all():
        raise ValueError(f"Maturity input {source} contains non-finite {value_column} values")
    spot_ids = read_index(cci_index_path(cfg.data_root, "spot", time, cfg.organ))
    missing = sorted(set(map(str, spot_ids)) - set(ids))
    if missing:
        raise ValueError(f"Maturity input {source} misses spot IDs: {missing[:10]}")
    return kind, source, id_column, value_column


def preflight_full_inputs(cfg: UnifiedDownstreamConfig) -> pd.DataFrame:
    """Resolve every required input before any expensive DeltaEI job starts."""

    cfg.validate()
    rows: list[dict[str, object]] = []
    for layer in NATURAL_LAYERS:
        for time in cfg.times:
            for kind, path in stage_input_paths(cfg, layer, time).items():
                rows.append(
                    {
                        "layer": layer,
                        "time": time,
                        "kind": kind,
                        "id_column": "not_applicable",
                        "value_column": "not_applicable",
                        "schema_validated": False,
                        **_input_descriptor(path),
                    }
                )
    for time in cfg.times:
        kind, path, id_column, value_column = _validated_maturity_source(cfg, time)
        rows.append(
            {
                "layer": "spot",
                "time": time,
                "kind": kind,
                "id_column": id_column,
                "value_column": value_column,
                "schema_validated": True,
                **_input_descriptor(path),
            }
        )
    return pd.DataFrame(rows)


def _materialize_maturity_csv(cfg: UnifiedDownstreamConfig, time: str) -> Path:
    kind, source, id_column, _value_column = _validated_maturity_source(cfg, time)
    if kind == "maturity":
        return source
    output = cfg.full_cache_root / "derived_maturity" / f"{cfg.organ}_{time}_maturity.csv"
    manifest = output.with_suffix(".full_manifest.json")
    expected = {
        "profile_id": cfg.profile.profile_id,
        "source": _input_descriptor(source),
        "time": time,
        "organ": cfg.organ,
    }
    if output.exists() or manifest.exists():
        if output.exists() and manifest.exists() and _read_json(manifest) == expected:
            return output
        raise RuntimeError(
            f"Existing derived maturity cache is not a validated full cache: {output}. "
            "Use a new cache root; existing files will not be overwritten."
        )
    frame = pd.read_csv(source)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame[[id_column, "pseudotime"]].rename(
        columns={id_column: "spot_id", "pseudotime": "maturity"}
    ).to_csv(output, index=False)
    _write_json(manifest, expected)
    return output


def _load_complete_stage(cfg: UnifiedDownstreamConfig, layer: str, time: str):
    from wyt_deltaei_coarse_grain.complete_combined import prepare_complete_stage

    paths = stage_input_paths(cfg, layer, time)
    units = read_index(paths["index"])
    cci = sp.load_npz(paths["cci"]).tocsr().astype(np.float32)
    if cci.shape != (len(units), len(units)):
        raise ValueError(f"CCI {paths['cci']} shape {cci.shape} does not match {len(units)} units")
    return prepare_complete_stage(
        h5ad_path=paths["h5ad"],
        grn_path=paths["grn"],
        units=units,
        cci=cci,
        top_k_targets=50,
        state_dim=64,
        projection_seed=20260713,
    )


def load_complete_stage(cfg: UnifiedDownstreamConfig, layer: str, time: str):
    """Public read-only stage loader shared with downstream sensitivity tools."""

    return _load_complete_stage(cfg, layer, time)


def _natural_expected_manifest(
    cfg: UnifiedDownstreamConfig,
    layer: str,
    pair: str,
    nmf_iterations: int,
) -> dict[str, object]:
    source, target = pair.split("->")
    return {
        "cache_kind": "formal_full_natural_ngklot",
        "cache_protocol": FORMAL_CACHE_PROTOCOL,
        "transition_protocol": FORMAL_TRANSITION_PROTOCOL,
        "transition_contract": canonical_transition_contract(),
        "profile_id": cfg.profile.profile_id,
        "layer": layer,
        "time_pair": pair,
        "nmf_components": cfg.profile.nmf_components,
        "nmf_max_iter_used": nmf_iterations,
        "random_seed": cfg.profile.random_seed,
        "inputs": {
            "source": {key: _input_descriptor(path) for key, path in stage_input_paths(cfg, layer, source).items()},
            "target": {key: _input_descriptor(path) for key, path in stage_input_paths(cfg, layer, target).items()},
        },
    }


def ensure_full_natural_caches(cfg: UnifiedDownstreamConfig) -> list[Path]:
    outputs: list[Path] = []
    for layer in NATURAL_LAYERS:
        for pair in cfg.adjacent_pairs:
            source, target = pair.split("->")
            nmf_iterations = cfg.profile.nmf_max_iter
            output = natural_cache_path(cfg, layer, pair)
            manifest = natural_cache_manifest_path(cfg, layer, pair)
            expected = _natural_expected_manifest(cfg, layer, pair, nmf_iterations)
            if output.exists() or manifest.exists():
                if output.exists() and manifest.exists() and _read_json(manifest) == expected:
                    outputs.append(output)
                    continue
                raise RuntimeError(
                    f"Natural cache exists but is not a validated full cache: {output}. "
                    "Use a new cache root; existing files will not be overwritten."
                )
            stage_t = _load_complete_stage(cfg, layer, source)
            stage_tp = _load_complete_stage(cfg, layer, target)
            pair_data = prepare_ngklot_pair(
                stage_t,
                stage_tp,
                nmf_components=cfg.profile.nmf_components,
                nmf_max_iter=nmf_iterations,
                seed=cfg.profile.random_seed,
            )
            pij = row_normalize(pair_data.micro_pij).astype(np.float32)
            output.parent.mkdir(parents=True, exist_ok=True)
            if layer == "spot":
                sp.save_npz(output, sp.csr_matrix(pij))
            else:
                np.save(output, pij)
            _write_json(manifest, expected)
            outputs.append(output)
    return outputs


def _optimized_expected_manifest(
    cfg: UnifiedDownstreamConfig,
    mapping: str,
    pair: str,
    nmf_iterations: int,
    maturity_t: Path | None,
    maturity_tp: Path | None,
    trainer_config,
) -> dict[str, object]:
    from mignet_ce.coarse_frontends.method_specs import get_coarse_method_spec

    source, target = pair.split("->")
    method = OPTIMIZED_METHOD_BY_MAPPING[mapping]
    spec = get_coarse_method_spec(method)
    inputs: dict[str, object] = {
        "source": {key: _input_descriptor(path) for key, path in stage_input_paths(cfg, "spot", source).items()},
        "target": {key: _input_descriptor(path) for key, path in stage_input_paths(cfg, "spot", target).items()},
    }
    if maturity_t is not None and maturity_tp is not None:
        inputs["maturity_t"] = _input_descriptor(maturity_t)
        inputs["maturity_tp"] = _input_descriptor(maturity_tp)
    return {
        "cache_kind": "formal_full_deltaei",
        "cache_protocol": FORMAL_CACHE_PROTOCOL,
        "transition_protocol": FORMAL_TRANSITION_PROTOCOL,
        "transition_contract": canonical_transition_contract(),
        "model_state_contract": "full_soft_k",
        "profile_id": cfg.profile.profile_id,
        "mapping": mapping,
        "method": method,
        "frontend": spec.frontend or method,
        "training_mode": spec.training_mode,
        "objective_version": spec.objective_version,
        "time_pair": pair,
        "optimized_k": cfg.profile.optimized_k,
        "optimized_epochs": cfg.profile.optimized_epochs,
        "nmf_components": cfg.profile.nmf_components,
        "nmf_max_iter_used": nmf_iterations,
        "random_seed": cfg.profile.random_seed,
        "lambda_dev": float(trainer_config.lambda_dev),
        "device_request": cfg.device,
        "training_hyperparameters": {
            key: (str(value) if isinstance(value, Path) else value)
            for key, value in asdict(trainer_config).items()
            if key != "out_dir"
        },
        "inputs": inputs,
    }


def _is_valid_optimized_cache(root: Path, expected: dict[str, object]) -> bool:
    full_manifest = root / "downstream_full_manifest.json"
    method = str(expected["method"])
    if not full_manifest.exists() or any(
        not (root / name).exists() for name in required_optimized_outputs(method)
    ):
        return False
    if _read_json(full_manifest) != expected:
        return False
    trainer = _read_json(root / "config.json")
    required = expected["training_hyperparameters"]
    if not all(trainer.get(key) == value for key, value in required.items()):
        return False
    if expected.get("cache_protocol") == FORMAL_CACHE_PROTOCOL:
        if expected.get("nmf_max_iter_used") != 300:
            return False
        summary = _read_json(root / "summary.json")
        feature_manifest = _read_json(root / "feature_manifest.json")
        k = int(expected["optimized_k"])
        if int(summary.get("K", -1)) != k:
            return False
        provenance = feature_manifest.get("provenance", {})
        if provenance.get("nmf_max_iter_used") != expected["nmf_max_iter_used"]:
            return False
        try:
            source_soft = np.load(root / "S_t.npy", mmap_mode="r")
            target_soft = np.load(root / "S_tp.npy", mmap_mode="r")
            macro = np.load(root / "PIJ_macro_train.npy", mmap_mode="r")
        except (OSError, ValueError):
            return False
        if source_soft.ndim != 2 or target_soft.ndim != 2 or macro.shape != (k, k):
            return False
        if source_soft.shape[1] != k or target_soft.shape[1] != k:
            return False
    return True


def ensure_full_deltaei_caches(cfg: UnifiedDownstreamConfig) -> list[Path]:
    """Run or validate all 3 methods x 3 adjacent-pair full DeltaEI jobs."""

    from mignet_ce.coarse_frontends import CoarseFrontendRequest, prepare_coarse_input
    from mignet_ce.coarse_frontends.method_specs import (
        DYNAMIC_CLOSURE_TWO_STAGE,
        get_coarse_method_spec,
    )
    from wyt_deltaei_coarse_grain import (
        WYTDeltaEIConfig,
        WYTTwoStageDeltaEIConfig,
        train_deltaei,
    )

    outputs: list[Path] = []
    for mapping in (MAPPING_COMPLETE, MAPPING_MATURITY, MAPPING_TWO_STAGE):
        method = OPTIMIZED_METHOD_BY_MAPPING[mapping]
        spec = get_coarse_method_spec(method)
        for pair in cfg.adjacent_pairs:
            source, target = pair.split("->")
            source_paths = stage_input_paths(cfg, "spot", source)
            target_paths = stage_input_paths(cfg, "spot", target)
            nmf_iterations = cfg.profile.nmf_max_iter
            maturity_t = _materialize_maturity_csv(cfg, source) if spec.requires_maturity else None
            maturity_tp = _materialize_maturity_csv(cfg, target) if spec.requires_maturity else None
            config_type = (
                WYTTwoStageDeltaEIConfig
                if spec.training_mode == DYNAMIC_CLOSURE_TWO_STAGE
                else WYTDeltaEIConfig
            )
            trainer_config = config_type(
                k=cfg.profile.optimized_k,
                out_dir=optimized_pair_dir(cfg, mapping, pair),
                epochs=cfg.profile.optimized_epochs,
                seed=cfg.profile.random_seed,
                device=cfg.device,
                log_every=50,
                lambda_dev=spec.default_lambda_dev,
            )
            expected = _optimized_expected_manifest(
                cfg,
                mapping,
                pair,
                nmf_iterations,
                maturity_t,
                maturity_tp,
                trainer_config,
            )
            output = optimized_pair_dir(cfg, mapping, pair)
            if output.exists() and any(output.iterdir()):
                if _is_valid_optimized_cache(output, expected):
                    outputs.append(output)
                    continue
                raise RuntimeError(
                    f"DeltaEI cache exists but is not the validated full profile: {output}. "
                    "Preview, partial, or mismatched results are never reused and will not be overwritten."
                )
            request_kwargs: dict[str, object] = {
                "h5ad_t": source_paths["h5ad"],
                "h5ad_tp": target_paths["h5ad"],
                "cci_t": source_paths["cci"],
                "cci_tp": target_paths["cci"],
                "cci_index_t": source_paths["index"],
                "cci_index_tp": target_paths["index"],
                "grn_t": source_paths["grn"],
                "grn_tp": target_paths["grn"],
                "nmf_components": cfg.profile.nmf_components,
                "nmf_max_iter": nmf_iterations,
                "seed": cfg.profile.random_seed,
            }
            if spec.requires_maturity:
                request_kwargs.update(
                    maturity_t=maturity_t,
                    maturity_tp=maturity_tp,
                    maturity_id_column="spot_id",
                    maturity_column="maturity",
                )
            prepared = prepare_coarse_input(method, CoarseFrontendRequest(**request_kwargs))
            output.mkdir(parents=True, exist_ok=True)
            train_deltaei(prepared, trainer_config)
            missing = [
                name for name in required_optimized_outputs(method) if not (output / name).exists()
            ]
            if missing:
                raise RuntimeError(f"Full DeltaEI job did not produce required outputs in {output}: {missing}")
            _write_json(output / "downstream_full_manifest.json", expected)
            if not _is_valid_optimized_cache(output, expected):
                raise RuntimeError(f"Full DeltaEI cache failed post-write validation: {output}")
            outputs.append(output)
    expected_count = len(OPTIMIZED_METHOD_BY_MAPPING) * len(cfg.adjacent_pairs)
    if len(outputs) != expected_count:
        raise AssertionError(f"Expected {expected_count} full DeltaEI jobs, got {len(outputs)}")
    return outputs


def ensure_full_unified_inputs(cfg: UnifiedDownstreamConfig) -> dict[str, object]:
    cfg = cfg.normalized()
    preflight = preflight_full_inputs(cfg)
    cfg.full_cache_root.mkdir(parents=True, exist_ok=True)
    preflight_path = cfg.full_cache_root / "input_preflight.csv"
    if preflight_path.exists():
        existing = pd.read_csv(
            preflight_path,
            dtype={
                "layer": str,
                "time": str,
                "kind": str,
                "id_column": str,
                "value_column": str,
                "path": str,
            },
        )
        if existing.to_dict(orient="records") != preflight.to_dict(orient="records"):
            raise RuntimeError(
                f"Full-cache input preflight changed at {preflight_path}; use a new cache root."
            )
    else:
        preflight.to_csv(preflight_path, index=False)
    derived_maturity = [_materialize_maturity_csv(cfg, time) for time in cfg.times]
    natural = ensure_full_natural_caches(cfg)
    deltaei = ensure_full_deltaei_caches(cfg)
    payload = {
        "cache_protocol": FORMAL_CACHE_PROTOCOL,
        "transition_protocol": FORMAL_TRANSITION_PROTOCOL,
        "transition_contract": canonical_transition_contract(),
        "model_state_contract": "full_soft_k",
        "profile_id": cfg.profile.profile_id,
        "full_profile": cfg.profile.__dict__,
        "natural_cache_count": len(natural),
        "deltaei_job_count": len(deltaei),
        "derived_maturity": [str(path) for path in derived_maturity],
        "natural_caches": [str(path) for path in natural],
        "deltaei_caches": [str(path) for path in deltaei],
    }
    benchmark_manifest = cfg.full_cache_root / "full_benchmark_manifest.json"
    if benchmark_manifest.exists():
        if _read_json(benchmark_manifest) != payload:
            raise RuntimeError(
                f"Full benchmark manifest differs at {benchmark_manifest}; use a new cache root."
            )
    else:
        _write_json(benchmark_manifest, payload)
    return payload
