"""Matched-null figures."""
