"""GRN/CCI figures."""
