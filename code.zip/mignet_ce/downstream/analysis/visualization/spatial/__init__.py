"""Spatial figures."""
