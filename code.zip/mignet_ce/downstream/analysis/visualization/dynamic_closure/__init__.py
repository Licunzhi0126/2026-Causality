"""Dynamic-closure figures."""
