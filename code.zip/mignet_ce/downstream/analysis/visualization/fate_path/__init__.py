"""Fate-path figures."""
