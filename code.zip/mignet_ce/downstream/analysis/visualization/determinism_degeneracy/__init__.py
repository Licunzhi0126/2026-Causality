"""Determinism and degeneracy figures."""
