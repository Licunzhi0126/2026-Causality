"""Macro fate-path analysis."""

