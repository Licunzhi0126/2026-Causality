"""Soft-native spatial analysis."""

