# sensitive_analysis

This directory intentionally lives at:

```text
mignet_ce/downstream/sensitive_analysis/
```

It consumes shared production helpers from `mignet_ce.downstream.analysis` but is
kept as a separate downstream analysis package by design.

## Purpose

This module performs GRN–CCI mixing-weight sensitivity analysis for the natural hierarchy:

- `spot:seuratK150`
- `spot:seuratK40`
- `seuratK150:seuratK40`

It is a **sensitivity / robustness analysis**, not a hyperparameter optimizer. It must never select alpha by maximizing DeltaEI.

## Current compatibility status

This folder is integrated with the canonical production N/G transition contract.

`kernel.py` exposes a thin adapter that calls the single shared canonical implementation in:

```text
mignet_ce/pij/compare/_shared/ng_kl_ot.py
```

Production methods and this sensitivity analysis use that one authoritative N/G KL-OT equation.

## Canonical equation

1. Compute raw `D_G = KL(G_t, G_t+1)` and `D_N = KL(N_t, N_t+1)`.
2. Mix them directly with `C = (1-alpha) * D_G + alpha * D_N`.
3. Do not normalize or clip either component and do not rescale the mixed cost.
4. Build `P = balanced Sinkhorn(exp(-C/tau))`.

Thus:

- `alpha` controls the relative GRN/CCI role;
- `tau` controls transition sharpness;
- the reported GRN mean-cost share is descriptive and is not a biological information percentage.

The production reference configuration is:

```text
alpha = 0.01
tau   = 0.8
```

The sensitivity analysis sweeps alpha while keeping the same transition constructor and a fixed tau.

## Default time pairs

```text
11.5->12.5
12.5->13.5
11.5->13.5
```

## Default table

Rows: `hierarchy_pair + alpha`

Columns:

- `11.5->12.5`
- `12.5->13.5`
- `11.5->13.5`

Values:

```text
DeltaEI = EI(upper hierarchy) - EI(lower hierarchy)
```

## Default figure

For `12.5->13.5`, draw three alpha-sensitivity curves:

- `spot:seuratK150`
- `spot:seuratK40`
- `seuratK150:seuratK40`

The plot marks the production reference `alpha=0.01` with a vertical dashed line.

## Run

From the repository root:

```bash
cd "/home/jovyan/work/2026 Causality"

python -m mignet_ce.downstream.sensitive_analysis \
  --data-root "/home/jovyan/public/datasets/Mouse-embryo/E1S1_domain_factory" \
  --output-dir "/home/jovyan/work/2026 Causality/output/sensitive_analysis920" \
  --organ heart \
  --time-pairs "11.5->12.5" "12.5->13.5" "11.5->13.5" \
  --tau 0.8 \
  --canonical-alpha 0.01 \
  --nmf-components 5 \
  --nmf-max-iter 300 \
  --random-seed 20260809
```

By default alpha is sampled densely over `[0, 0.02]` and more sparsely through
`1.0`, including the production reference `0.01`. NMF
components/max-iter/seed inherit the locked downstream production profile
(currently 5 / 300 / 20260809) unless explicitly overridden.

## Output files

- `alpha_layer_ei_long.csv`
- `alpha_hierarchy_sensitivity_long.csv`
- `alpha_hierarchy_sensitivity_table.csv`
- `alpha_sensitivity_12.5_13.5.png`
- `sensitivity_metadata.json`
