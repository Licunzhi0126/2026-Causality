"""Biological cluster-map normalization and alignment checks."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


STANDARD_COLUMNS = ("spot_id", "cluster", "cell_type", "x", "y")


def load_and_validate_cluster_map(path: Path, adata: Any) -> pd.DataFrame:
    """Read a supplied mapping CSV and align it exactly to H5AD spot order."""
    table = pd.read_csv(path)
    if "barcode" in table.columns:
        table = table.rename(columns={"barcode": "spot_id"})
    missing_columns = [column for column in STANDARD_COLUMNS if column not in table.columns]
    if missing_columns:
        raise ValueError(f"Cluster map {path} is missing columns: {missing_columns}")
    result = table.loc[:, STANDARD_COLUMNS].copy()
    result["spot_id"] = result["spot_id"].astype(str)
    if result["spot_id"].duplicated().any():
        raise ValueError("Cluster map spot_id values must be unique.")
    if result[["cluster", "cell_type"]].isna().any().any():
        raise ValueError("Cluster map cluster and cell_type values must not be missing.")
    if result[["x", "y"]].isna().any().any() or not np.isfinite(result[["x", "y"]].to_numpy(dtype=float)).all():
        raise ValueError("Cluster map coordinates must be finite.")
    h5ad_ids = adata.obs_names.astype(str).tolist()
    map_ids = set(result["spot_id"])
    missing = sorted(set(h5ad_ids) - map_ids)
    extra = sorted(map_ids - set(h5ad_ids))
    if missing or extra:
        raise ValueError(f"Cluster map spots do not match H5AD (missing={missing[:5]}, extra={extra[:5]}).")
    result = result.set_index("spot_id").loc[h5ad_ids].reset_index()
    spatial = np.asarray(adata.obsm["spatial"])
    if not np.allclose(result[["x", "y"]].to_numpy(dtype=float), spatial, rtol=0.0, atol=1e-6):
        raise ValueError("Cluster-map x/y coordinates do not match H5AD obsm['spatial'].")
    return result

