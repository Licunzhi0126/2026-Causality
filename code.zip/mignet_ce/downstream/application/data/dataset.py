"""H5AD loading and count-layer compatibility normalization."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from anndata import AnnData, read_h5ad

from .validation import validate_adata


def prepare_adata(path: Path) -> tuple[AnnData, dict[str, object]]:
    """Load, validate, and guarantee a ``layers['count']`` raw-count layer."""
    adata = read_h5ad(path)
    if "count" in adata.layers:
        source = "count"
        source_label = "layers['count']"
    elif "counts" in adata.layers:
        source = "counts"
        source_label = "layers['counts']"
    else:
        source = "__x__"
        source_label = "X"
    report = validate_adata(adata, count_source=source)
    if source != "count":
        source_matrix: Any = adata.X if source == "__x__" else adata.layers[source]
        adata.layers["count"] = source_matrix.copy() if hasattr(source_matrix, "copy") else source_matrix
    report["count_source"] = source_label
    report["count_layer_written"] = source != "count"
    return adata, report

