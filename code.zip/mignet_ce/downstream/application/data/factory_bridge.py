"""Thin subprocess bridge to the repository's existing CCI and GRN scripts."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
import subprocess
import sys
from typing import Callable, Iterable

from ..config import FactoryOptions


PROJECT_ROOT = Path(__file__).resolve().parents[4]
CCI_SCRIPT = PROJECT_ROOT / "data_factory" / "scripts" / "04_run_cci_spot_commot.py"
GRN_SCRIPT = PROJECT_ROOT / "data_factory" / "scripts" / "07_run_grn_spot.py"
Runner = Callable[..., subprocess.CompletedProcess[str]]


def _run(command: list[str], runner: Runner) -> dict[str, object]:
    print(f"[application] Running: {' '.join(command)}", flush=True)
    if runner is subprocess.run:
        # In production inherit the terminal so long-running Factory progress is visible.
        completed = runner(command, cwd=PROJECT_ROOT, check=False)
    else:
        # Unit-test runners retain captured fields for assertions without affecting production.
        completed = runner(command, cwd=PROJECT_ROOT, text=True, capture_output=True, check=False)
    stdout = getattr(completed, "stdout", "") or ""
    stderr = getattr(completed, "stderr", "") or ""
    record = {"command": command, "returncode": completed.returncode, "stdout": stdout, "stderr": stderr}
    if completed.returncode != 0:
        raise RuntimeError(f"Data Factory command failed ({completed.returncode}): {' '.join(command)}\n{stderr}")
    return record


def _verify_all(paths: Iterable[Path], *, label: str) -> list[str]:
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"{label} outputs are missing: {missing}")
    return [str(path) for path in paths]


def run_cci(prepared_root: Path, output_root: Path, sample_names: list[str], options: FactoryOptions, *, runner: Runner = subprocess.run) -> dict[str, object]:
    command = [sys.executable, str(CCI_SCRIPT), "--input-root", str(prepared_root), "--output-root", str(output_root), "--sample-names", *sample_names, "--dis-thr", str(options.commot_distance_threshold), "--workers", str(options.commot_workers), "--lr-chunk-size", str(options.commot_lr_chunk_size), "--heartbeat-seconds", str(options.commot_heartbeat_seconds)]
    if options.commot_reference_dir is not None:
        command.extend(["--commot-reference-dir", str(options.commot_reference_dir)])
    record = _run(command, runner)
    expected = [output_root / f"{sample}_COMMOT.h5ad" for sample in sample_names]
    expected += [output_root / f"{sample}_CCI_total.npz" for sample in sample_names]
    expected += [output_root / f"{sample}_index.tsv" for sample in sample_names]
    record["outputs"] = _verify_all(expected, label="CCI")
    return record


def run_grn(prepared_root: Path, output_root: Path, sample_names: list[str], options: FactoryOptions, *, runner: Runner = subprocess.run) -> dict[str, object]:
    command = [sys.executable, str(GRN_SCRIPT), "--input-root", str(prepared_root), "--output-root", str(output_root), "--sample-names", *sample_names, "--threads", str(options.grn_threads), "--n-trees", str(options.grn_n_trees), "--top-hvg", str(options.grn_top_hvg), "--top-edge-count", str(options.grn_top_edge_count)]
    if options.grn_tf_list is not None:
        command.extend(["--tf-list", str(options.grn_tf_list)])
    record = _run(command, runner)
    expected = [output_root / sample / name for sample in sample_names for name in ("grn_vim.npy", "grn_edges.csv", "grn_summary.tsv")]
    record["outputs"] = _verify_all(expected, label="GRN")
    return record


def options_manifest(options: FactoryOptions) -> dict[str, object]:
    """Return a JSON-ready options snapshot, converting paths to strings."""
    return {key: str(value) if isinstance(value, Path) else value for key, value in asdict(options).items()}
