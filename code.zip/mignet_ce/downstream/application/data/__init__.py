"""Dataset-specific validation and normalization adapters."""

