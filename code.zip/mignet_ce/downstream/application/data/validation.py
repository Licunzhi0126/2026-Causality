"""Validation of raw-count and spatial contracts without biological inference."""

from __future__ import annotations

from typing import Any

import numpy as np
from scipy import sparse


def _stored_values(matrix: Any) -> np.ndarray:
    return np.asarray(matrix.data if sparse.issparse(matrix) else matrix).ravel()


def validate_count_matrix(matrix: Any, *, source: str) -> dict[str, object]:
    """Require finite, non-negative, integer-like count values."""
    values = _stored_values(matrix)
    if not np.isfinite(values).all():
        raise ValueError(f"{source} contains non-finite values.")
    if values.size and float(values.min()) < 0:
        raise ValueError(f"{source} contains negative values.")
    if values.size and not np.allclose(values, np.rint(values), rtol=0.0, atol=1e-6):
        raise ValueError(f"{source} is not integer-like raw counts.")
    return {"source": source, "n_stored_values": int(values.size)}


def validate_identifiers(adata: Any) -> None:
    if not adata.obs_names.is_unique:
        raise ValueError("Spot IDs (obs_names) must be unique.")
    if not adata.var_names.is_unique:
        raise ValueError("Gene IDs (var_names) must be unique.")
    if adata.n_obs == 0 or adata.n_vars == 0:
        raise ValueError("H5AD must contain at least one spot and one gene.")


def validate_spatial(adata: Any) -> dict[str, object]:
    if "spatial" not in adata.obsm:
        raise KeyError("H5AD is missing obsm['spatial'].")
    spatial = np.asarray(adata.obsm["spatial"])
    if spatial.shape != (adata.n_obs, 2):
        raise ValueError(f"obsm['spatial'] must have shape ({adata.n_obs}, 2), got {spatial.shape}.")
    if not np.isfinite(spatial).all():
        raise ValueError("obsm['spatial'] contains non-finite values.")
    return {"shape": [int(spatial.shape[0]), int(spatial.shape[1])]}


def validate_adata(adata: Any, *, count_source: str) -> dict[str, object]:
    """Validate generic contracts and return JSON-ready report fields."""
    validate_identifiers(adata)
    matrix = adata.layers[count_source] if count_source in adata.layers else adata.X
    return {
        "n_obs": int(adata.n_obs),
        "n_vars": int(adata.n_vars),
        "count_matrix": validate_count_matrix(matrix, source=f"layers[{count_source!r}]" if count_source in adata.layers else "X"),
        "spatial": validate_spatial(adata),
    }

