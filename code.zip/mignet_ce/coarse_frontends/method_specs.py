from __future__ import annotations

"""Method-level coarse-graining metadata shared by CLIs and trainers."""

from dataclasses import dataclass


LEGACY_SINGLE_STAGE = "legacy_single_stage"
DYNAMIC_CLOSURE_TWO_STAGE = "dynamic_closure_two_stage"
CQ_ONLY = "cq_only"
FORMAL_TWO_STAGE_PROTOCOL = "formal_two_stage_1b_v2"
NO_KEFF_EI_RETAIN_RATIOS = {
    "two_stage_noKeff": 0.85,
    "two_stage_noKeff_HardEI": 1.0,
}
RETIRED_COARSE_METHODS = frozenset({"shr_method_8", "shr_method_10"})


@dataclass(frozen=True)
class CoarseMethodSpec:
    name: str
    training_mode: str = LEGACY_SINGLE_STAGE
    frontend: str | None = None
    requires_maturity: bool = False
    requires_cci: bool = True
    requires_grn: bool = False
    default_lambda_dev: float = 0.0
    objective_version: str = "legacy_feature_align_deltaei_v40"


_LEGACY_METHODS = (
    "complete_combined_coarse",
    "complete_combined_coarse_maturity_cci_grn",
)


COARSE_METHOD_SPECS: dict[str, CoarseMethodSpec] = {
    name: CoarseMethodSpec(name=name)
    for name in _LEGACY_METHODS
}
COARSE_METHOD_SPECS.update(
    {
        "formal_two_stage": CoarseMethodSpec(
            name="formal_two_stage",
            training_mode=DYNAMIC_CLOSURE_TWO_STAGE,
            frontend="complete_combined_coarse_maturity_cci_grn",
            requires_maturity=True,
            requires_grn=True,
            default_lambda_dev=0.05,
            objective_version=FORMAL_TWO_STAGE_PROTOCOL,
        ),
        "complete_combined_coarse": CoarseMethodSpec(
            name="complete_combined_coarse",
            requires_grn=True,
        ),
        "complete_combined_coarse_maturity_cci_grn": CoarseMethodSpec(
            name="complete_combined_coarse_maturity_cci_grn",
            requires_maturity=True,
            requires_grn=True,
            default_lambda_dev=0.05,
        ),
        "maturity_cci_grn_two_stage": CoarseMethodSpec(
            name="maturity_cci_grn_two_stage",
            training_mode=DYNAMIC_CLOSURE_TWO_STAGE,
            frontend="complete_combined_coarse_maturity_cci_grn",
            requires_maturity=True,
            requires_grn=True,
            default_lambda_dev=0.05,
            objective_version="wyt_dynamic_closure_two_stage_v2",
        ),
    }
)

for _name in NO_KEFF_EI_RETAIN_RATIOS:
    COARSE_METHOD_SPECS[_name] = CoarseMethodSpec(
        name=_name, training_mode=DYNAMIC_CLOSURE_TWO_STAGE,
        frontend="complete_combined_coarse_maturity_cci_grn",
        requires_maturity=True, requires_grn=True, default_lambda_dev=0.05,
        objective_version="wyt_dynamic_closure_two_stage_v2",
    )
COARSE_METHOD_SPECS["single_stage_cq_only"] = CoarseMethodSpec(
    name="single_stage_cq_only", training_mode=CQ_ONLY,
    frontend="complete_combined_coarse_maturity_cci_grn",
    requires_maturity=True, requires_grn=True, default_lambda_dev=0.05,
    objective_version="wyt_cq_only_v1",
)


def get_coarse_method_spec(method: str) -> CoarseMethodSpec:
    """Return a known method spec, defaulting unknown programmatic fixtures to legacy."""

    if method in RETIRED_COARSE_METHODS:
        raise ValueError(
            f"Coarse method {method!r} has been retired; use 'maturity_cci_grn_two_stage'."
        )
    return COARSE_METHOD_SPECS.get(method, CoarseMethodSpec(name=method))


def training_mode_for_method(method: str) -> str:
    return get_coarse_method_spec(method).training_mode

