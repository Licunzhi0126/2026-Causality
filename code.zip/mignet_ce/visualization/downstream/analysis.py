from __future__ import annotations

from typing import Sequence

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy.sparse.csgraph import connected_components
from scipy.stats import pearsonr, spearmanr
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from .config import DownstreamConfig
from .io import (
    cci_path,
    grn_path,
    layer_h5ad,
    load_domain_map,
    load_pij,
    load_units,
    read_h5ad_expression,
)
from .metrics import (
    aggregate_transition_by_overlap,
    compose_transitions,
    effective_state_number,
    ei_decomposition,
    entropy,
    hierarchy_counts,
    mean_row_js,
    purity_entropy_from_counts,
    relative_frobenius,
    row_normalize,
    state_ei,
)


def _safe_corr(x: pd.Series, y: pd.Series) -> tuple[float, float, float, float, int]:
    x_values = pd.to_numeric(x, errors="coerce").to_numpy(dtype=float)
    y_values = pd.to_numeric(y, errors="coerce").to_numpy(dtype=float)
    mask = np.isfinite(x_values) & np.isfinite(y_values)
    count = int(mask.sum())
    if count < 4 or np.isclose(np.std(x_values[mask]), 0) or np.isclose(np.std(y_values[mask]), 0):
        return np.nan, np.nan, np.nan, np.nan, count
    pearson = pearsonr(x_values[mask], y_values[mask])
    spearman = spearmanr(x_values[mask], y_values[mask])
    return (
        float(pearson.statistic),
        float(pearson.pvalue),
        float(spearman.statistic),
        float(spearman.pvalue),
        count,
    )


def _benjamini_hochberg(values: pd.Series) -> np.ndarray:
    p_values = pd.to_numeric(values, errors="coerce").to_numpy(dtype=float)
    adjusted = np.full_like(p_values, np.nan)
    finite = np.flatnonzero(np.isfinite(p_values))
    if len(finite) == 0:
        return adjusted
    order = finite[np.argsort(p_values[finite])]
    ranked = p_values[order] * len(order) / np.arange(1, len(order) + 1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    adjusted[order] = np.minimum(ranked, 1.0)
    return adjusted


def build_ei_tables(
    cfg: DownstreamConfig,
    metrics: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    decompositions: list[dict[str, object]] = []
    states: list[dict[str, object]] = []
    for time_pair in metrics["time_pair"].astype(str):
        source_time, target_time = time_pair.split("->")
        for space, layer in (("lower", cfg.lower_layer), ("upper", cfg.upper_layer)):
            transition = load_pij(cfg.pair_archive, time_pair, space)
            values: dict[str, object] = ei_decomposition(transition)
            values.update(
                {
                    "time_pair": time_pair,
                    "source_time": source_time,
                    "target_time": target_time,
                    "space": space,
                    "layer": layer,
                }
            )
            decompositions.append(values)
            units = load_units(cfg.pair_archive, space, source_time)
            normalized = row_normalize(transition)
            row_entropy = entropy(normalized, axis=1)
            contribution = state_ei(normalized)
            states.extend(
                {
                    "time_pair": time_pair,
                    "source_time": source_time,
                    "target_time": target_time,
                    "space": space,
                    "layer": layer,
                    "state": unit,
                    "state_ei": float(ei_value),
                    "transition_entropy": float(entropy_value),
                }
                for unit, ei_value, entropy_value in zip(units, contribution, row_entropy)
            )
    return pd.DataFrame(decompositions), pd.DataFrame(states)


def build_spatial_state_maps(cfg: DownstreamConfig, state_table: pd.DataFrame) -> list[pd.DataFrame]:
    frames: list[pd.DataFrame] = []
    for time_pair in cfg.adjacent_pairs:
        source, target = time_pair.split("->")
        for layer in (cfg.lower_layer, cfg.upper_layer):
            domain_map = load_domain_map(cfg.data_root, layer, source, cfg.organ)
            scores = state_table[
                (state_table["time_pair"] == time_pair) & (state_table["layer"] == layer)
            ][["state", "state_ei"]]
            frame = domain_map.merge(scores, left_on="domain_id", right_on="state", how="left")
            frame["state_ei"] = frame["state_ei"].fillna(0.0)
            frame["layer"] = layer
            frame["source_time"] = source
            frame["target_time"] = target
            frames.append(frame)
    return frames


def build_multistep_closure(cfg: DownstreamConfig) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for source_index in range(len(cfg.times)):
        for target_index in range(source_index + 2, len(cfg.times)):
            source = cfg.times[source_index]
            target = cfg.times[target_index]
            steps = [
                f"{cfg.times[index]}->{cfg.times[index + 1]}"
                for index in range(source_index, target_index)
            ]
            direct_pair = f"{source}->{target}"
            for space, layer in (("lower", "K150"), ("upper", "K40")):
                composed = compose_transitions([load_pij(cfg.pair_archive, pair, space) for pair in steps])
                direct = row_normalize(load_pij(cfg.pair_archive, direct_pair, space))
                composed_ei = ei_decomposition(composed)["EI"]
                direct_ei = ei_decomposition(direct)["EI"]
                rows.append(
                    {
                        "comparison": f"{source}->{target}",
                        "direct_pair": direct_pair,
                        "space": space,
                        "layer": layer,
                        "relative_frobenius": relative_frobenius(composed, direct),
                        "mean_row_js": mean_row_js(composed, direct),
                        "EI_composed": composed_ei,
                        "EI_direct": direct_ei,
                        "EI_difference": composed_ei - direct_ei,
                    }
                )
    return pd.DataFrame(rows)


def build_single_step_closure(
    cfg: DownstreamConfig,
    counts_by_time: dict[str, np.ndarray],
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for pair in cfg.adjacent_pairs:
        source, target = pair.split("->")
        p_lower = row_normalize(load_pij(cfg.pair_archive, pair, "lower"))
        q_direct = row_normalize(load_pij(cfg.pair_archive, pair, "upper"))
        counts_source = counts_by_time[source]
        counts_target = counts_by_time[target]
        source_membership = counts_source / np.maximum(counts_source.sum(axis=1, keepdims=True), 1e-12)
        target_membership = counts_target / np.maximum(counts_target.sum(axis=1, keepdims=True), 1e-12)
        observed = p_lower @ target_membership
        q_aggregated = aggregate_transition_by_overlap(p_lower, counts_source, counts_target)
        q_best = np.linalg.lstsq(source_membership, observed, rcond=None)[0]
        q_best = row_normalize(np.maximum(q_best, 0.0))
        for method, q_matrix in (
            ("direct_K40_Pij", q_direct),
            ("overlap_aggregated", q_aggregated),
            ("clipped_least_squares", q_best),
        ):
            predicted = source_membership @ q_matrix
            rows.append(
                {
                    "time_pair": pair,
                    "macro_Q": method,
                    "relative_frobenius": relative_frobenius(predicted, observed),
                    "mean_row_js": mean_row_js(predicted, observed),
                    "EI_Q": ei_decomposition(q_matrix)["EI"],
                }
            )
    return pd.DataFrame(rows)


def build_hierarchy_tables(
    cfg: DownstreamConfig,
) -> tuple[dict[str, np.ndarray], pd.DataFrame, pd.DataFrame]:
    counts_by_time: dict[str, np.ndarray] = {}
    purity_rows: list[pd.DataFrame] = []
    effective_rows: list[dict[str, object]] = []
    for time in cfg.times:
        lower_units = load_units(cfg.pair_archive, "lower", time)
        upper_units = load_units(cfg.pair_archive, "upper", time)
        lower_map = load_domain_map(cfg.data_root, cfg.lower_layer, time, cfg.organ)
        upper_map = load_domain_map(cfg.data_root, cfg.upper_layer, time, cfg.organ)
        counts, _ = hierarchy_counts(lower_map, upper_map, lower_units, upper_units)
        counts_by_time[time] = counts
        purity = purity_entropy_from_counts(counts)
        purity.insert(0, "k150_state", lower_units)
        purity.insert(0, "time", time)
        purity_rows.append(purity)
        for layer, mapping, units in (
            (cfg.lower_layer, lower_map, lower_units),
            (cfg.upper_layer, upper_map, upper_units),
        ):
            usage = mapping["domain_id"].value_counts().reindex(units, fill_value=0).to_numpy(dtype=float)
            total = max(float(usage.sum()), 1.0)
            effective_rows.append(
                {
                    "time": time,
                    "layer": layer,
                    "hardK": int(np.count_nonzero(usage)),
                    "Keff": effective_state_number(usage),
                    "max_usage": float(usage.max() / total),
                    "min_nonzero_usage": float(usage[usage > 0].min() / total) if np.any(usage > 0) else 0.0,
                    "usage_entropy_bits": float(entropy(usage / total)),
                    "spot_count": int(usage.sum()),
                }
            )
    return counts_by_time, pd.concat(purity_rows, ignore_index=True), pd.DataFrame(effective_rows)


def build_multiscale_consistency(
    cfg: DownstreamConfig,
    counts_by_time: dict[str, np.ndarray],
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for pair in cfg.all_pairs:
        source, target = pair.split("->")
        lower = load_pij(cfg.pair_archive, pair, "lower")
        via_lower = aggregate_transition_by_overlap(lower, counts_by_time[source], counts_by_time[target])
        direct = row_normalize(load_pij(cfg.pair_archive, pair, "upper"))
        via_ei = ei_decomposition(via_lower)["EI"]
        direct_ei = ei_decomposition(direct)["EI"]
        rows.append(
            {
                "time_pair": pair,
                "relative_frobenius": relative_frobenius(via_lower, direct),
                "mean_row_js": mean_row_js(via_lower, direct),
                "EI_via_K150": via_ei,
                "EI_direct_K40": direct_ei,
                "EI_path_difference": via_ei - direct_ei,
            }
        )
    return pd.DataFrame(rows)


def build_random_null(
    cfg: DownstreamConfig,
    counts_by_time: dict[str, np.ndarray],
) -> pd.DataFrame:
    rng = np.random.default_rng(cfg.random_seed)
    rows: list[dict[str, object]] = []
    map_cache: dict[str, pd.DataFrame] = {}
    units_cache: dict[str, tuple[list[str], list[str]]] = {}
    for time in cfg.times:
        lower_units = load_units(cfg.pair_archive, "lower", time)
        upper_units = load_units(cfg.pair_archive, "upper", time)
        lower_map = load_domain_map(cfg.data_root, cfg.lower_layer, time, cfg.organ)
        upper_map = load_domain_map(cfg.data_root, cfg.upper_layer, time, cfg.organ)
        map_cache[time] = lower_map[["spot_id", "domain_id"]].rename(columns={"domain_id": "lower"}).merge(
            upper_map[["spot_id", "domain_id"]].rename(columns={"domain_id": "upper"}),
            on="spot_id",
            how="inner",
        )
        units_cache[time] = (lower_units, upper_units)
    for pair in cfg.adjacent_pairs:
        source, target = pair.split("->")
        p_lower = load_pij(cfg.pair_archive, pair, "lower")
        observed = aggregate_transition_by_overlap(p_lower, counts_by_time[source], counts_by_time[target])
        rows.append(
            {
                "time_pair": pair,
                "kind": "observed",
                "repeat": -1,
                "EI": ei_decomposition(observed)["EI"],
            }
        )
        for repeat in range(cfg.random_repeats):
            random_counts: list[np.ndarray] = []
            for time in (source, target):
                merged = map_cache[time]
                lower_units, upper_units = units_cache[time]
                labels = merged["upper"].to_numpy(copy=True)
                rng.shuffle(labels)
                random_frame = pd.DataFrame({"lower": merged["lower"].to_numpy(), "upper": labels})
                table = pd.crosstab(random_frame["lower"], random_frame["upper"]).reindex(
                    index=lower_units,
                    columns=upper_units,
                    fill_value=0,
                )
                random_counts.append(table.to_numpy(dtype=float))
            q_matrix = aggregate_transition_by_overlap(p_lower, random_counts[0], random_counts[1])
            rows.append(
                {
                    "time_pair": pair,
                    "kind": "matched_random",
                    "repeat": repeat,
                    "EI": ei_decomposition(q_matrix)["EI"],
                }
            )
    return pd.DataFrame(rows)


def _spatial_graph(frame: pd.DataFrame, k: int) -> sp.csr_matrix:
    coordinates = frame[["x", "y"]].to_numpy(dtype=float)
    count = len(frame)
    if count < 2:
        return sp.csr_matrix((count, count), dtype=float)
    k_used = min(max(2, k + 1), count)
    indices = NearestNeighbors(n_neighbors=k_used).fit(coordinates).kneighbors(coordinates)[1]
    rows = np.repeat(np.arange(count), k_used - 1)
    columns = indices[:, 1:].reshape(-1)
    graph = sp.coo_matrix((np.ones(len(rows)), (rows, columns)), shape=(count, count)).tocsr()
    graph = ((graph + graph.T) > 0).astype(float).tocsr()
    graph.setdiag(0)
    graph.eliminate_zeros()
    return graph


def build_spatial_metrics(cfg: DownstreamConfig, state_table: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for pair in cfg.adjacent_pairs:
        time, _ = pair.split("->")
        for layer in (cfg.lower_layer, cfg.upper_layer):
            frame = load_domain_map(cfg.data_root, layer, time, cfg.organ).reset_index(drop=True)
            graph = _spatial_graph(frame, cfg.spatial_knn)
            degree_sum = float(graph.sum())
            coordinates = frame[["x", "y"]].to_numpy(dtype=float)
            global_span = max(float(np.ptp(coordinates[:, 0])), float(np.ptp(coordinates[:, 1])), 1.0)
            scores = state_table[
                (state_table["time_pair"] == pair) & (state_table["layer"] == layer)
            ].set_index("state")
            labels = frame["domain_id"].astype(str).to_numpy()
            for state in dict.fromkeys(labels.tolist()):
                mask = labels == state
                indices = np.flatnonzero(mask)
                subgraph = graph[indices][:, indices]
                components = int(connected_components(subgraph, directed=False, return_labels=False))
                cross = float(graph[indices][:, np.flatnonzero(~mask)].sum())
                total = float(graph[indices].sum())
                center = coordinates[indices].mean(axis=0)
                radius = float(np.linalg.norm(coordinates[indices] - center, axis=1).mean() / global_span)
                indicator = mask.astype(float)
                centered = indicator - indicator.mean()
                denominator = float(np.sum(centered**2))
                moran = float(
                    len(frame)
                    / max(degree_sum, 1.0)
                    * (centered @ (graph @ centered))
                    / max(denominator, 1e-12)
                )
                score = scores.loc[state] if state in scores.index else None
                rows.append(
                    {
                        "time": time,
                        "time_pair": pair,
                        "layer": layer,
                        "state": state,
                        "spot_count": int(mask.sum()),
                        "connected_components": components,
                        "fragmentation": components / max(int(mask.sum()), 1),
                        "boundary_ratio": cross / max(total, 1.0),
                        "radius_norm": radius,
                        "moran_i": moran,
                        "state_ei": float(score["state_ei"]) if score is not None else np.nan,
                        "transition_entropy": float(score["transition_entropy"]) if score is not None else np.nan,
                    }
                )
    return pd.DataFrame(rows)


def _reorder_rows(matrix: sp.csr_matrix, observed_units: Sequence[str], expected_units: Sequence[str]) -> sp.csr_matrix:
    observed = list(map(str, observed_units))
    expected = list(map(str, expected_units))
    if observed == expected:
        return matrix
    lookup = {unit: index for index, unit in enumerate(observed)}
    missing = [unit for unit in expected if unit not in lookup]
    if missing:
        raise ValueError(f"H5AD is missing archive units: {missing[:5]}")
    return matrix[[lookup[unit] for unit in expected]]


def build_grn_metrics(cfg: DownstreamConfig) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for time in cfg.times[:-1]:
        matrix, h5_units, genes = read_h5ad_expression(layer_h5ad(cfg.data_root, cfg.upper_layer, time, cfg.organ))
        units = load_units(cfg.pair_archive, "upper", time)
        matrix = _reorder_rows(matrix.tocsr().astype(float), h5_units, units)
        totals = np.asarray(matrix.sum(axis=1)).ravel()
        matrix = sp.diags(1.0 / np.maximum(totals, 1.0)) @ matrix * 1.0e4
        matrix.data = np.log1p(matrix.data)
        grn = pd.read_csv(grn_path(cfg.data_root, cfg.upper_layer, time, cfg.organ))
        required = {"regulator", "target", "weight"}
        missing = required - set(grn.columns)
        if missing:
            raise ValueError(f"GRN is missing columns {sorted(missing)}")
        grn["regulator"] = grn["regulator"].astype(str)
        grn["target"] = grn["target"].astype(str)
        grn["weight"] = pd.to_numeric(grn["weight"], errors="coerce").abs()
        grn = (
            grn.dropna(subset=["weight"])
            .sort_values(["regulator", "weight"], ascending=[True, False])
            .groupby("regulator", group_keys=False)
            .head(50)
        )
        gene_index = pd.Series(np.arange(len(genes)), index=genes.astype(str))
        grn = grn[grn["target"].isin(gene_index.index)].copy()
        regulators = sorted(grn["regulator"].unique().tolist())
        if not regulators:
            raise ValueError(f"No GRN targets overlap H5AD genes for {time}")
        regulator_index = {regulator: index for index, regulator in enumerate(regulators)}
        target_indices = grn["target"].map(gene_index).to_numpy(dtype=int)
        regulator_indices = grn["regulator"].map(regulator_index).to_numpy(dtype=int)
        weights = grn["weight"].to_numpy(dtype=float)
        sums = np.bincount(regulator_indices, weights=weights, minlength=len(regulators))
        weights = weights / np.maximum(sums[regulator_indices], 1e-12)
        projection = sp.coo_matrix(
            (weights, (target_indices, regulator_indices)),
            shape=(len(genes), len(regulators)),
        ).tocsr()
        activity = (matrix @ projection).toarray().astype(float, copy=False)
        for index, state in enumerate(units):
            values = np.maximum(activity[index], 0.0)
            total = values.sum()
            probabilities = values / max(total, 1e-12)
            h_value = float(entropy(probabilities))
            h_normalized = h_value / np.log2(max(len(probabilities), 2))
            top_indices = np.argsort(values)[-5:][::-1]
            rows.append(
                {
                    "time": time,
                    "state": state,
                    "grn_total_activity": float(total),
                    "grn_concentration": float(1.0 - h_normalized),
                    "grn_entropy_norm": float(h_normalized),
                    "grn_effective_regulators": float(2.0**h_value),
                    "grn_top10_share": float(np.sort(probabilities)[-10:].sum()),
                    "top_regulators": ";".join(regulators[item] for item in top_indices),
                }
            )
    return pd.DataFrame(rows)


def build_cci_metrics(cfg: DownstreamConfig) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for time in cfg.times[:-1]:
        archive_units = load_units(cfg.pair_archive, "upper", time)
        _, h5_units, _ = read_h5ad_expression(
            layer_h5ad(cfg.data_root, cfg.upper_layer, time, cfg.organ),
            prefer_counts=False,
        )
        matrix = sp.load_npz(cci_path(cfg.data_root, cfg.upper_layer, time, cfg.organ)).toarray().astype(float)
        matrix = np.maximum(matrix, 0.0)
        observed_units = list(map(str, h5_units))
        if observed_units != archive_units:
            lookup = {unit: index for index, unit in enumerate(observed_units)}
            missing = [unit for unit in archive_units if unit not in lookup]
            if missing:
                raise ValueError(f"CCI/H5AD is missing archive units for {time}: {missing[:5]}")
            indices = [lookup[unit] for unit in archive_units]
            matrix = matrix[np.ix_(indices, indices)]
        if matrix.shape != (len(archive_units), len(archive_units)):
            raise ValueError(f"CCI shape mismatch for {time}: {matrix.shape}")
        out_strength = matrix.sum(axis=1)
        in_strength = matrix.sum(axis=0)
        out_probabilities = row_normalize(matrix)
        in_probabilities = row_normalize(matrix.T)
        log_capacity = np.log2(max(len(archive_units), 2))
        for index, state in enumerate(archive_units):
            rows.append(
                {
                    "time": time,
                    "state": state,
                    "cci_out_strength": float(out_strength[index]),
                    "cci_in_strength": float(in_strength[index]),
                    "cci_out_log": float(np.log1p(out_strength[index])),
                    "cci_in_log": float(np.log1p(in_strength[index])),
                    "cci_out_entropy_norm": float(entropy(out_probabilities[index]) / log_capacity),
                    "cci_in_entropy_norm": float(entropy(in_probabilities[index]) / log_capacity),
                }
            )
    return pd.DataFrame(rows)


def build_mechanism_table(
    cfg: DownstreamConfig,
    state_table: pd.DataFrame,
    spatial: pd.DataFrame,
    grn: pd.DataFrame,
    cci: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    states = state_table[state_table["layer"] == cfg.upper_layer].copy()
    states = states[states["source_time"].isin(grn["time"].unique())]
    merged = states.merge(
        grn,
        left_on=["source_time", "state"],
        right_on=["time", "state"],
        how="left",
        suffixes=("", "_grn"),
    )
    merged = merged.merge(
        cci,
        left_on=["source_time", "state"],
        right_on=["time", "state"],
        how="left",
        suffixes=("", "_cci"),
    )
    spatial_keep = spatial[spatial["layer"] == cfg.upper_layer][
        ["time", "state", "spot_count", "boundary_ratio", "moran_i", "fragmentation"]
    ]
    merged = merged.merge(
        spatial_keep,
        left_on=["source_time", "state"],
        right_on=["time", "state"],
        how="left",
        suffixes=("", "_spatial"),
    )
    variables = [
        "grn_concentration",
        "grn_top10_share",
        "cci_out_log",
        "cci_in_log",
        "cci_out_entropy_norm",
        "boundary_ratio",
        "moran_i",
        "spot_count",
    ]
    correlation_rows: list[dict[str, object]] = []
    for outcome in ("state_ei", "transition_entropy"):
        for variable in variables:
            pearson_r, pearson_p, spearman_r, spearman_p, count = _safe_corr(merged[variable], merged[outcome])
            correlation_rows.append(
                {
                    "outcome": outcome,
                    "predictor": variable,
                    "pearson_r": pearson_r,
                    "pearson_p": pearson_p,
                    "spearman_r": spearman_r,
                    "spearman_p": spearman_p,
                    "n": count,
                }
            )
    correlations = pd.DataFrame(correlation_rows)
    correlations["pearson_q"] = _benjamini_hochberg(correlations["pearson_p"])
    correlations["spearman_q"] = _benjamini_hochberg(correlations["spearman_p"])

    predictors = [
        "grn_concentration",
        "cci_out_log",
        "cci_in_log",
        "cci_out_entropy_norm",
        "boundary_ratio",
        "moran_i",
        "spot_count",
    ]
    model = merged.dropna(subset=["state_ei", *predictors]).copy()
    if len(model) <= len(predictors) + 1:
        coefficients = pd.DataFrame(
            {"predictor": predictors, "coefficient": np.nan, "model_r2": np.nan, "n": len(model)}
        )
    else:
        numerical = StandardScaler().fit_transform(model[predictors])
        time_dummies = pd.get_dummies(model["source_time"], prefix="time", drop_first=True, dtype=float)
        design = np.column_stack([np.ones(len(model)), numerical, time_dummies.to_numpy(dtype=float)])
        response = StandardScaler().fit_transform(model[["state_ei"]]).ravel()
        beta = np.linalg.lstsq(design, response, rcond=None)[0]
        prediction = design @ beta
        r_squared = 1.0 - np.sum((response - prediction) ** 2) / max(
            np.sum((response - response.mean()) ** 2),
            1e-12,
        )
        coefficients = pd.DataFrame(
            {"predictor": predictors, "coefficient": beta[1 : 1 + len(predictors)]}
        )
        coefficients["model_r2"] = float(r_squared)
        coefficients["n"] = int(len(model))
    return merged, correlations, coefficients


def _viterbi_path(transitions: list[np.ndarray], source_index: int) -> tuple[list[int], float]:
    first_size = transitions[0].shape[0]
    scores = np.full(first_size, -np.inf, dtype=float)
    scores[source_index] = 0.0
    backpointers: list[np.ndarray] = []
    for transition in transitions:
        probabilities = row_normalize(transition)
        candidate = scores[:, None] + np.log(np.maximum(probabilities, 1e-300))
        backpointer = np.argmax(candidate, axis=0)
        scores = candidate[backpointer, np.arange(candidate.shape[1])]
        backpointers.append(backpointer)
    endpoint = int(np.argmax(scores))
    indices = [endpoint]
    current = endpoint
    for backpointer in reversed(backpointers):
        current = int(backpointer[current])
        indices.append(current)
    indices.reverse()
    return indices, float(np.exp(scores[endpoint]))


def build_fate_paths(cfg: DownstreamConfig, state_table: pd.DataFrame) -> pd.DataFrame:
    transitions = [row_normalize(load_pij(cfg.pair_archive, pair, "upper")) for pair in cfg.adjacent_pairs]
    composed = compose_transitions(transitions)
    units = {time: load_units(cfg.pair_archive, "upper", time) for time in cfg.times}
    first_pair = cfg.adjacent_pairs[0]
    source_ei = state_table[
        (state_table["time_pair"] == first_pair) & (state_table["layer"] == cfg.upper_layer)
    ].set_index("state")["state_ei"]
    rows: list[dict[str, object]] = []
    for source_index, source in enumerate(units[cfg.times[0]]):
        indices, probability = _viterbi_path(transitions, source_index)
        row: dict[str, object] = {
            f"state_{time}": units[time][index]
            for time, index in zip(cfg.times, indices)
        }
        row.update(
            {
                "path_probability": probability,
                "endpoint_entropy": float(entropy(composed[source_index])),
                "source_ei": float(source_ei.get(source, np.nan)),
                "first_branch_entropy": float(entropy(transitions[0][source_index])),
                "path_method": "global_viterbi_max_product",
            }
        )
        rows.append(row)
    return pd.DataFrame(rows)


def _blend_rows(matrix: np.ndarray, indices: np.ndarray, dose: float) -> np.ndarray:
    output = row_normalize(matrix).copy()
    mean_row = output.mean(axis=0)
    output[indices] = (1.0 - dose) * output[indices] + dose * mean_row[None, :]
    return row_normalize(output)


def build_perturbation_curves(
    cfg: DownstreamConfig,
    state_table: pd.DataFrame,
    grn: pd.DataFrame,
    cci: pd.DataFrame,
) -> pd.DataFrame:
    rng = np.random.default_rng(cfg.random_seed + 17)
    rows: list[dict[str, object]] = []
    doses = np.linspace(0.0, 1.0, 6)
    for pair in cfg.adjacent_pairs:
        source, _ = pair.split("->")
        transition = row_normalize(load_pij(cfg.pair_archive, pair, "upper"))
        units = load_units(cfg.pair_archive, "upper", source)
        target_count = max(1, int(round(0.2 * len(units))))
        state_scores = state_table[
            (state_table["time_pair"] == pair) & (state_table["layer"] == cfg.upper_layer)
        ].set_index("state")["state_ei"].reindex(units)
        cci_scores = cci[cci["time"] == source].set_index("state")["cci_out_log"].reindex(units)
        grn_scores = grn[grn["time"] == source].set_index("state")["grn_concentration"].reindex(units)
        if state_scores.isna().any() or cci_scores.isna().any() or grn_scores.isna().any():
            raise ValueError(f"Perturbation score alignment failed for {pair}")
        selections = {
            "high_state_ei": np.argsort(state_scores.to_numpy())[-target_count:],
            "high_cci_out": np.argsort(cci_scores.to_numpy())[-target_count:],
            "high_grn_concentration": np.argsort(grn_scores.to_numpy())[-target_count:],
        }
        baseline_ei = ei_decomposition(transition)["EI"]
        for target, indices in selections.items():
            for dose in doses:
                drop = baseline_ei - ei_decomposition(_blend_rows(transition, indices, float(dose)))["EI"]
                rows.append(
                    {
                        "time_pair": pair,
                        "target": target,
                        "dose": float(dose),
                        "ei_drop_mean": float(drop),
                        "ei_drop_low": float(drop),
                        "ei_drop_high": float(drop),
                        "perturbation": "Pij_row_homogenization",
                    }
                )
        for dose in doses:
            drops = []
            for _ in range(cfg.perturb_random_repeats):
                indices = rng.choice(len(units), size=target_count, replace=False)
                drops.append(
                    baseline_ei - ei_decomposition(_blend_rows(transition, indices, float(dose)))["EI"]
                )
            rows.append(
                {
                    "time_pair": pair,
                    "target": "matched_random",
                    "dose": float(dose),
                    "ei_drop_mean": float(np.mean(drops)),
                    "ei_drop_low": float(np.quantile(drops, 0.025)),
                    "ei_drop_high": float(np.quantile(drops, 0.975)),
                    "perturbation": "Pij_row_homogenization",
                }
            )
    return pd.DataFrame(rows)


def summarize_findings(
    cfg: DownstreamConfig,
    metrics: pd.DataFrame,
    decomposition: pd.DataFrame,
    closure: pd.DataFrame,
    single_closure: pd.DataFrame,
    consistency: pd.DataFrame,
    random_null: pd.DataFrame,
    effective: pd.DataFrame,
    correlations: pd.DataFrame,
    perturbation: pd.DataFrame,
) -> dict[str, object]:
    gain = pd.to_numeric(metrics["EI_gain"])
    adjacent = metrics[metrics["lag"] == 1]
    pivot = decomposition.pivot(index="time_pair", columns="space", values=["H_effect", "H_noise"])
    noise_reduction = pivot[("H_noise", "lower")] - pivot[("H_noise", "upper")]
    effect_change = pivot[("H_effect", "upper")] - pivot[("H_effect", "lower")]
    null_summary = []
    for pair in random_null["time_pair"].unique():
        subset = random_null[random_null["time_pair"] == pair]
        observed = float(subset.loc[subset["kind"] == "observed", "EI"].iloc[0])
        values = subset.loc[subset["kind"] == "matched_random", "EI"].to_numpy()
        null_summary.append(
            {
                "time_pair": pair,
                "observed": observed,
                "null_mean": float(values.mean()),
                "z": float((observed - values.mean()) / max(values.std(ddof=1), 1e-12)),
                "p_empirical": float((1 + np.sum(values >= observed)) / (1 + len(values))),
            }
        )
    grn_rows = correlations[
        (correlations["outcome"] == "state_ei")
        & (correlations["predictor"] == "grn_concentration")
    ]
    max_dose = perturbation[np.isclose(perturbation["dose"], 1.0)]
    perturbation_summary = max_dose.groupby("target")["ei_drop_mean"].mean().to_dict()
    return {
        "run_scope": {
            "network_method": cfg.network_method,
            "pij_method": cfg.pij_method,
            "organ": cfg.organ,
            "layer_pair": f"{cfg.lower_layer}->{cfg.upper_layer}",
            "time_points": list(cfg.times),
        },
        "interpretation_boundaries": {
            "matched_random": "Preserves K40 spot counts; it is not a random learned WYT assignment.",
            "grn_cci": "Exploratory associations, not demonstrated biological causality.",
            "virtual_perturbation": "Pij row homogenization, not a full CCI/GRN intervention rerun.",
        },
        "delta_ei_mean": float(gain.mean()),
        "delta_ei_median": float(gain.median()),
        "delta_ei_min": float(gain.min()),
        "delta_ei_max": float(gain.max()),
        "adjacent_delta_ei_mean": float(adjacent["EI_gain"].mean()),
        "positive_fraction": float((gain > 0).mean()),
        "noise_reduction_mean": float(noise_reduction.mean()),
        "effect_diversity_change_mean": float(effect_change.mean()),
        "noise_reduction_dominant_pairs": int((noise_reduction > np.abs(effect_change)).sum()),
        "multistep_relative_error_mean_K40": float(
            closure.loc[closure["space"] == "upper", "relative_frobenius"].mean()
        ),
        "multistep_relative_error_mean_K150": float(
            closure.loc[closure["space"] == "lower", "relative_frobenius"].mean()
        ),
        "single_step_closure_mean_direct_K40": float(
            single_closure.loc[
                single_closure["macro_Q"] == "direct_K40_Pij",
                "relative_frobenius",
            ].mean()
        ),
        "single_step_closure_mean_overlap_Q": float(
            single_closure.loc[
                single_closure["macro_Q"] == "overlap_aggregated",
                "relative_frobenius",
            ].mean()
        ),
        "single_step_closure_mean_best_fit": float(
            single_closure.loc[
                single_closure["macro_Q"] == "clipped_least_squares",
                "relative_frobenius",
            ].mean()
        ),
        "multiscale_relative_error_mean": float(consistency["relative_frobenius"].mean()),
        "random_null": null_summary,
        "effective_states": effective.to_dict(orient="records"),
        "grn_concentration_state_ei_correlation": grn_rows.iloc[0].to_dict() if len(grn_rows) else {},
        "perturbation_mean_full_dose_drop": {
            key: float(value) for key, value in perturbation_summary.items()
        },
    }
