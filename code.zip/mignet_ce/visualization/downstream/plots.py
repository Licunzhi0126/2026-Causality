from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import TwoSlopeNorm
from matplotlib.patches import FancyArrowPatch

from .style import (
    BLUE,
    CYAN,
    DARK,
    DIVERGING,
    GOLD,
    GREEN,
    METHOD_COLORS,
    METHOD_LABELS,
    MUTED,
    NAVY,
    RED,
    SEQUENTIAL,
    TARGET_COLORS,
    TARGET_LABELS,
    TIME_COLORS,
    add_panel_label,
    bar_labels,
    grouped_bars,
    pair_order,
    savefig,
    set_publication_style,
)


def plot_ei_overview(metrics: pd.DataFrame, decomposition: pd.DataFrame, path: Path) -> None:
    """Figure 1: EI gain and its information-theoretic decomposition."""
    set_publication_style()
    order = pair_order(metrics)
    selected = metrics.set_index("time_pair").loc[order].reset_index()
    pivot = decomposition.pivot(
        index="time_pair",
        columns="space",
        values=["H_effect", "H_noise", "EI", "determinism", "degeneracy"],
    ).loc[order]
    x_values = np.arange(len(order))
    fig, axes = plt.subplots(2, 3, figsize=(15.6, 9.2), constrained_layout=True)
    fig.suptitle(
        "Figure 1 | Causal emergence and EI mechanism decomposition",
        color=NAVY,
        fontsize=16,
        weight="bold",
    )

    ax = axes[0, 0]
    grouped_bars(
        ax,
        order,
        [
            ("K150 EI", selected["EI_lower"].to_numpy(), BLUE),
            ("K40 EI", selected["EI_upper"].to_numpy(), RED),
        ],
        "Effective information (bit)",
        "Micro-to-macro EI comparison",
        annotate=True,
    )
    ax.legend(loc="upper center", ncol=2)
    add_panel_label(ax, "A")

    ax = axes[0, 1]
    bars = ax.bar(
        x_values,
        selected["EI_gain"],
        color=[RED if value >= 0 else BLUE for value in selected["EI_gain"]],
    )
    bar_labels(ax, bars)
    ax.axhline(0, color=MUTED, lw=0.9)
    ax.set_xticks(x_values, order, rotation=28, ha="right")
    ax.set_ylabel("Delta EI (bit)")
    ax.set_title("Causal-emergence gain")
    ax.grid(axis="y")
    ax.text(
        0.02,
        0.96,
        f"Positive pairs: {(selected['EI_gain'] > 0).sum()}/{len(selected)}",
        transform=ax.transAxes,
        va="top",
        color=NAVY,
        fontsize=8,
    )
    add_panel_label(ax, "B")

    ax = axes[0, 2]
    ax.plot(x_values, pivot[("H_effect", "lower")], marker="o", color=BLUE, lw=2, label="K150")
    ax.plot(x_values, pivot[("H_effect", "upper")], marker="s", color=RED, lw=2, label="K40")
    ax.set_xticks(x_values, order, rotation=28, ha="right")
    ax.set_ylabel("Effect entropy H(Y) (bit)")
    ax.set_title("Diversity of reachable effects")
    ax.grid(axis="y")
    ax.legend(loc="best")
    add_panel_label(ax, "C")

    ax = axes[1, 0]
    ax.plot(x_values, pivot[("H_noise", "lower")], marker="o", color=BLUE, lw=2, label="K150")
    ax.plot(x_values, pivot[("H_noise", "upper")], marker="s", color=RED, lw=2, label="K40")
    ax.set_xticks(x_values, order, rotation=28, ha="right")
    ax.set_ylabel("Conditional entropy H(Y|X) (bit)")
    ax.set_title("Transition noise after intervention")
    ax.grid(axis="y")
    ax.legend(loc="best")
    add_panel_label(ax, "D")

    ax = axes[1, 1]
    noise_reduction = (
        pivot[("H_noise", "lower")].to_numpy() - pivot[("H_noise", "upper")].to_numpy()
    )
    effect_change = (
        pivot[("H_effect", "upper")].to_numpy() - pivot[("H_effect", "lower")].to_numpy()
    )
    width = 0.31
    ax.bar(x_values - width / 2, noise_reduction, width=width, color=CYAN, label="Noise reduction")
    ax.bar(
        x_values + width / 2,
        effect_change,
        width=width,
        color=GOLD,
        label="Effect-diversity change",
    )
    ax.plot(x_values, selected["EI_gain"], marker="o", color=NAVY, lw=1.8, label="Observed Delta EI")
    ax.axhline(0, color=MUTED, lw=0.9)
    ax.set_xticks(x_values, order, rotation=28, ha="right")
    ax.set_ylabel("Contribution to Delta EI (bit)")
    ax.set_title("Why EI increases")
    ax.grid(axis="y")
    ax.legend(loc="lower right")
    add_panel_label(ax, "E")

    ax = axes[1, 2]
    colors = mpl.colormaps["tab10"](np.linspace(0, 1, len(order)))
    degeneracy_scale = 1e9
    for index, time_pair in enumerate(order):
        subset = decomposition[decomposition["time_pair"] == time_pair].set_index("space")
        lower = subset.loc["lower"]
        upper = subset.loc["upper"]
        arrow = FancyArrowPatch(
            (lower["degeneracy"] * degeneracy_scale, lower["determinism"]),
            (upper["degeneracy"] * degeneracy_scale, upper["determinism"]),
            arrowstyle="-|>",
            mutation_scale=11,
            lw=1.4,
            color=colors[index],
            alpha=0.9,
        )
        ax.add_patch(arrow)
        ax.scatter(
            lower["degeneracy"] * degeneracy_scale,
            lower["determinism"],
            s=36,
            marker="o",
            color=colors[index],
            edgecolor="white",
            zorder=3,
        )
        ax.scatter(
            upper["degeneracy"] * degeneracy_scale,
            upper["determinism"],
            s=48,
            marker="s",
            color=colors[index],
            edgecolor="white",
            zorder=3,
            label=time_pair,
        )
    max_degeneracy = max(float(decomposition["degeneracy"].max()) * degeneracy_scale, 1e-6)
    ax.set_xlim(-0.05 * max_degeneracy, 1.25 * max_degeneracy)
    ax.set_xlabel("Degeneracy (10^-9 bit)")
    ax.set_ylabel("Determinism (bit)")
    ax.set_title("Determinism-degeneracy displacement")
    ax.grid(True)
    ax.legend(
        loc="center left",
        bbox_to_anchor=(1.0, 0.5),
        title="Time pair",
        fontsize=6.7,
        title_fontsize=7.2,
    )
    ax.text(0.03, 0.04, "Circle: K150   Square: K40", transform=ax.transAxes, fontsize=7.2, color=MUTED)
    add_panel_label(ax, "F")
    savefig(fig, path)


def plot_spatial_state_ei(spatial_frames: list[pd.DataFrame], path: Path) -> None:
    """Figure 2: three adjacent time pairs at K150 and K40."""
    set_publication_style()
    layer_rank = {"seurat_k150": 0, "seurat_k40": 1}
    frames = sorted(
        spatial_frames,
        key=lambda frame: (
            layer_rank.get(str(frame["layer"].iloc[0]), 99),
            float(frame["source_time"].iloc[0]),
        ),
    )
    if len(frames) != 6:
        raise ValueError(f"Expected exactly six spatial frames, received {len(frames)}")
    fig, axes = plt.subplots(2, 3, figsize=(15.8, 9.4), constrained_layout=True)
    fig.suptitle(
        "Figure 2 | Spatial distribution of state-level effective information",
        color=NAVY,
        fontsize=16,
        weight="bold",
    )
    for row in range(2):
        row_frames = frames[row * 3 : row * 3 + 3]
        maximum = max(float(frame["state_ei"].quantile(0.98)) for frame in row_frames)
        maximum = max(maximum, 1e-8)
        mappable = None
        for column, frame in enumerate(row_frames):
            ax = axes[row, column]
            layer = str(frame["layer"].iloc[0])
            mappable = ax.scatter(
                frame["x"],
                -frame["y"],
                c=frame["state_ei"],
                cmap=SEQUENTIAL,
                vmin=0,
                vmax=maximum,
                s=6.3 if layer == "seurat_k150" else 8.3,
                linewidths=0,
                rasterized=True,
            )
            ax.set_aspect("equal")
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
            scale = "K150" if layer == "seurat_k150" else "K40"
            ax.set_title(f"{scale} | {frame['source_time'].iloc[0]} to {frame['target_time'].iloc[0]}")
            add_panel_label(ax, chr(ord("A") + row * 3 + column))
        colorbar = fig.colorbar(mappable, ax=axes[row, :].tolist(), fraction=0.018, pad=0.015)
        colorbar.set_label(f"State-level EI at {'K150' if row == 0 else 'K40'} (bit)")
    savefig(fig, path)


def plot_single_step_closure(closure: pd.DataFrame, path: Path) -> None:
    """Figure 3: one-step commutativity test."""
    set_publication_style()
    order = pair_order(closure)
    pivot_error = closure.pivot(index="time_pair", columns="macro_Q", values="relative_frobenius").loc[order]
    pivot_js = closure.pivot(index="time_pair", columns="macro_Q", values="mean_row_js").loc[order]
    pivot_ei = closure.pivot(index="time_pair", columns="macro_Q", values="EI_Q").loc[order]
    methods = [
        method
        for method in ("direct_K40_Pij", "overlap_aggregated", "clipped_least_squares")
        if method in pivot_error.columns
    ]
    fig, axes = plt.subplots(2, 3, figsize=(15.6, 9.2), constrained_layout=True)
    fig.suptitle("Figure 3 | Single-step macro-dynamics closure", color=NAVY, fontsize=16, weight="bold")

    ax = axes[0, 0]
    grouped_bars(
        ax,
        order,
        [(METHOD_LABELS[method], pivot_error[method].to_numpy(), METHOD_COLORS[method]) for method in methods],
        "Relative Frobenius error",
        "Commutativity error",
        annotate=True,
    )
    ax.legend(loc="upper center")
    add_panel_label(ax, "A")

    ax = axes[0, 1]
    grouped_bars(
        ax,
        order,
        [(METHOD_LABELS[method], pivot_js[method].to_numpy(), METHOD_COLORS[method]) for method in methods],
        "Mean row-wise JS divergence (bit)",
        "Distributional mismatch",
        annotate=True,
    )
    add_panel_label(ax, "B")

    ax = axes[0, 2]
    grouped_bars(
        ax,
        order,
        [(METHOD_LABELS[method], pivot_ei[method].to_numpy(), METHOD_COLORS[method]) for method in methods],
        "EI of macro transition Q (bit)",
        "Information retained by Q",
        annotate=True,
    )
    add_panel_label(ax, "C")

    ax = axes[1, 0]
    excess_best = pivot_error["direct_K40_Pij"] - pivot_error["clipped_least_squares"]
    bars = ax.bar(np.arange(len(order)), excess_best, color=RED)
    bar_labels(ax, bars)
    ax.set_xticks(np.arange(len(order)), order, rotation=28, ha="right")
    ax.set_ylabel("Excess relative error")
    ax.set_title("Independent K40 error above best fit")
    ax.grid(axis="y")
    add_panel_label(ax, "D")

    ax = axes[1, 1]
    excess_overlap = pivot_error["direct_K40_Pij"] - pivot_error["overlap_aggregated"]
    bars = ax.bar(np.arange(len(order)), excess_overlap, color=GOLD)
    bar_labels(ax, bars)
    ax.set_xticks(np.arange(len(order)), order, rotation=28, ha="right")
    ax.set_ylabel("Excess relative error")
    ax.set_title("Independent K40 error above overlap Q")
    ax.grid(axis="y")
    add_panel_label(ax, "E")

    ax = axes[1, 2]
    markers = {"direct_K40_Pij": "s", "overlap_aggregated": "o", "clipped_least_squares": "^"}
    for method in methods:
        subset = closure[closure["macro_Q"] == method]
        ax.scatter(
            subset["relative_frobenius"],
            subset["EI_Q"],
            s=65,
            marker=markers[method],
            color=METHOD_COLORS[method],
            edgecolor="white",
            label=METHOD_LABELS[method],
        )
        for _, row in subset.iterrows():
            ax.annotate(
                str(row["time_pair"]),
                (row["relative_frobenius"], row["EI_Q"]),
                xytext=(4, 3),
                textcoords="offset points",
                fontsize=6.4,
                color=DARK,
            )
    ax.set_xlabel("Relative closure error")
    ax.set_ylabel("EI of Q (bit)")
    ax.set_title("Closure-information trade-off")
    ax.grid(True)
    ax.legend(loc="best")
    add_panel_label(ax, "F")
    savefig(fig, path)


def plot_multistep_closure(closure: pd.DataFrame, path: Path) -> None:
    """Figure 4: composed versus direct long-range transitions."""
    set_publication_style()
    order = closure["comparison"].drop_duplicates().tolist()
    fig, axes = plt.subplots(2, 3, figsize=(15.6, 9.2), constrained_layout=True)
    fig.suptitle(
        "Figure 4 | Multi-step closure and long-range prediction",
        color=NAVY,
        fontsize=16,
        weight="bold",
    )
    for ax, metric, ylabel, title in (
        (axes[0, 0], "relative_frobenius", "Relative Frobenius error", "Composed vs direct transition"),
        (axes[0, 1], "mean_row_js", "Mean row-wise JS divergence (bit)", "Row-distribution mismatch"),
    ):
        pivot = closure.pivot(index="comparison", columns="space", values=metric).loc[order]
        grouped_bars(
            ax,
            order,
            [("K150", pivot["lower"].to_numpy(), BLUE), ("K40", pivot["upper"].to_numpy(), RED)],
            ylabel,
            title,
            annotate=True,
        )
        ax.legend(loc="best")
    add_panel_label(axes[0, 0], "A")
    add_panel_label(axes[0, 1], "B")

    for ax, space, scale, panel in (
        (axes[0, 2], "lower", "K150", "C"),
        (axes[1, 0], "upper", "K40", "D"),
    ):
        subset = closure[closure["space"] == space].set_index("comparison").loc[order]
        grouped_bars(
            ax,
            order,
            [
                ("Composed EI", subset["EI_composed"].to_numpy(), CYAN),
                ("Direct EI", subset["EI_direct"].to_numpy(), NAVY),
            ],
            "Effective information (bit)",
            f"{scale}: information after composition",
            annotate=True,
        )
        ax.legend(loc="best")
        add_panel_label(ax, panel)

    ax = axes[1, 1]
    pivot = closure.pivot(index="comparison", columns="space", values="EI_difference").loc[order]
    grouped_bars(
        ax,
        order,
        [("K150", pivot["lower"].to_numpy(), BLUE), ("K40", pivot["upper"].to_numpy(), RED)],
        "Composed EI - direct EI (bit)",
        "Long-range information loss",
        annotate=True,
    )
    ax.axhline(0, color=MUTED, lw=0.9)
    ax.legend(loc="best")
    add_panel_label(ax, "E")

    ax = axes[1, 2]
    for space, color, marker, label in (("lower", BLUE, "o", "K150"), ("upper", RED, "s", "K40")):
        subset = closure[closure["space"] == space]
        ax.scatter(
            subset["relative_frobenius"],
            -subset["EI_difference"],
            s=70,
            marker=marker,
            color=color,
            edgecolor="white",
            label=label,
        )
        for _, row in subset.iterrows():
            ax.annotate(
                str(row["comparison"]),
                (row["relative_frobenius"], -row["EI_difference"]),
                xytext=(4, 3),
                textcoords="offset points",
                fontsize=6.4,
            )
    ax.set_xlabel("Relative closure error")
    ax.set_ylabel("EI loss after composition (bit)")
    ax.set_title("Dynamics error vs information loss")
    ax.grid(True)
    ax.legend(loc="best")
    add_panel_label(ax, "F")
    savefig(fig, path)


def plot_random_null(null_table: pd.DataFrame, path: Path) -> None:
    """Figure 5: matched random coarse-graining null model."""
    set_publication_style()
    pairs = list(dict.fromkeys(null_table["time_pair"].astype(str).tolist()))[:3]
    if len(pairs) != 3:
        raise ValueError(f"Expected three adjacent time pairs, got {pairs}")
    fig, axes = plt.subplots(2, 3, figsize=(15.6, 9.2), constrained_layout=True)
    fig.suptitle(
        "Figure 5 | Matched random coarse-graining null model",
        color=NAVY,
        fontsize=16,
        weight="bold",
    )
    summary_rows: list[dict[str, float | str]] = []
    for index, time_pair in enumerate(pairs):
        ax = axes[0, index]
        subset = null_table[null_table["time_pair"] == time_pair]
        null_values = subset.loc[subset["kind"] == "matched_random", "EI"].to_numpy()
        observed = float(subset.loc[subset["kind"] == "observed", "EI"].iloc[0])
        mean = float(np.mean(null_values))
        standard_deviation = float(np.std(null_values, ddof=1))
        p_value = float((1 + np.sum(null_values >= observed)) / (1 + len(null_values)))
        z_score = float((observed - mean) / max(standard_deviation, 1e-12))
        q025, q975 = np.quantile(null_values, [0.025, 0.975])
        summary_rows.append(
            {
                "time_pair": time_pair,
                "observed": observed,
                "mean": mean,
                "q025": float(q025),
                "q975": float(q975),
                "z": z_score,
                "p": p_value,
            }
        )
        q_low, q_high = np.quantile(null_values, [0.005, 0.995])
        span = max(float(q_high - q_low), 1e-6)
        ax.hist(null_values, bins=28, color="#C9DCE8", edgecolor="white")
        ax.axvline(mean, color=NAVY, ls="--", lw=1.4, label=f"Null mean = {mean:.3f}")
        ax.set_xlim(q_low - 0.08 * span, q_high + 0.08 * span)
        direction = "above" if observed > q_high else "below" if observed < q_low else "inside"
        if direction == "inside":
            annotation = f"Observed = {observed:.3f}\n(inside null range)"
            xy = (observed, ax.get_ylim()[1] * 0.72)
            xycoords = "data"
        else:
            annotation = f"Observed = {observed:.3f}\n(outside null range)"
            xy = (0.985 if direction == "above" else 0.015, 0.82)
            xycoords = "axes fraction"
        ax.annotate(
            annotation,
            xy=xy,
            xycoords=xycoords,
            xytext=(0.68 if direction != "below" else 0.32, 0.82),
            textcoords="axes fraction",
            arrowprops={"arrowstyle": "-|>", "color": RED, "lw": 1.8},
            color=RED,
            fontsize=7.2,
            ha="right" if direction != "below" else "left",
            va="center",
        )
        ax.set_xlabel("Matched-random aggregated EI (bit)")
        ax.set_ylabel("Random assignments")
        ax.set_title(f"{time_pair} | z = {z_score:.1f}, p = {p_value:.4f}")
        ax.grid(axis="y")
        ax.legend(loc="upper right")
        add_panel_label(ax, chr(ord("A") + index))

    summary = pd.DataFrame(summary_rows)
    x_values = np.arange(len(summary))
    ax = axes[1, 0]
    error = np.vstack([summary["mean"] - summary["q025"], summary["q975"] - summary["mean"]])
    ax.errorbar(
        x_values,
        summary["mean"],
        yerr=error,
        fmt="o",
        color=BLUE,
        capsize=4,
        label="Null mean and 95% interval",
    )
    ax.scatter(x_values, summary["observed"], marker="D", s=60, color=RED, label="Observed")
    ax.set_xticks(x_values, summary["time_pair"], rotation=25, ha="right")
    ax.set_ylabel("Aggregated EI (bit)")
    ax.set_title("Observed EI relative to the null interval")
    ax.grid(axis="y")
    ax.legend(loc="best")
    add_panel_label(ax, "D")

    ax = axes[1, 1]
    bars = ax.bar(x_values, summary["z"], color=GOLD)
    bar_labels(ax, bars, fmt=".1f")
    ax.axhline(1.96, color=MUTED, ls="--", lw=1, label="z = 1.96")
    ax.set_xticks(x_values, summary["time_pair"], rotation=25, ha="right")
    ax.set_ylabel("Standardized separation (z)")
    ax.set_title("Effect size relative to null spread")
    ax.grid(axis="y")
    ax.legend(loc="best")
    add_panel_label(ax, "E")

    ax = axes[1, 2]
    significance = -np.log10(summary["p"])
    bars = ax.bar(x_values, significance, color=GREEN)
    bar_labels(ax, bars, fmt=".2f")
    ax.axhline(-np.log10(0.05), color=MUTED, ls="--", lw=1, label="p = 0.05")
    ax.set_xticks(x_values, summary["time_pair"], rotation=25, ha="right")
    ax.set_ylabel("-log10 empirical p")
    ax.set_title("Empirical significance")
    ax.grid(axis="y")
    ax.legend(loc="best")
    add_panel_label(ax, "F")
    savefig(fig, path)


def plot_multiscale(consistency: pd.DataFrame, purity: pd.DataFrame, path: Path) -> None:
    """Figure 6: direct versus hierarchical multiscale consistency."""
    set_publication_style()
    order = pair_order(consistency)
    selected = consistency.set_index("time_pair").loc[order].reset_index()
    times = sorted(purity["time"].astype(str).unique(), key=float)
    fig, axes = plt.subplots(2, 3, figsize=(15.6, 9.2), constrained_layout=True)
    fig.suptitle(
        "Figure 6 | K150-to-K40 multiscale consistency",
        color=NAVY,
        fontsize=16,
        weight="bold",
    )
    x_values = np.arange(len(order))

    ax = axes[0, 0]
    bars = ax.bar(x_values, selected["relative_frobenius"], color=BLUE)
    bar_labels(ax, bars)
    ax.set_xticks(x_values, order, rotation=28, ha="right")
    ax.set_ylabel("Relative Frobenius error")
    ax.set_title("Direct K40 vs route through K150")
    ax.grid(axis="y")
    add_panel_label(ax, "A")

    ax = axes[0, 1]
    bars = ax.bar(x_values, selected["mean_row_js"], color=CYAN)
    bar_labels(ax, bars)
    ax.set_xticks(x_values, order, rotation=28, ha="right")
    ax.set_ylabel("Mean row-wise JS divergence (bit)")
    ax.set_title("Row-level transition mismatch")
    ax.grid(axis="y")
    add_panel_label(ax, "B")

    ax = axes[0, 2]
    grouped_bars(
        ax,
        order,
        [
            ("EI via K150", selected["EI_via_K150"].to_numpy(), GOLD),
            ("Direct K40 EI", selected["EI_direct_K40"].to_numpy(), NAVY),
        ],
        "Effective information (bit)",
        "Information along two coarse-graining routes",
        annotate=True,
    )
    ax.legend(loc="best")
    add_panel_label(ax, "C")

    ax = axes[1, 0]
    bars = ax.bar(
        x_values,
        selected["EI_path_difference"],
        color=[BLUE if value < 0 else RED for value in selected["EI_path_difference"]],
    )
    bar_labels(ax, bars)
    ax.axhline(0, color=MUTED, lw=0.9)
    ax.set_xticks(x_values, order, rotation=28, ha="right")
    ax.set_ylabel("EI via K150 - direct K40 EI (bit)")
    ax.set_title("Path-dependent EI difference")
    ax.grid(axis="y")
    add_panel_label(ax, "D")

    ax = axes[1, 1]
    distributions = [purity.loc[purity["time"].astype(str) == time, "purity"].to_numpy() for time in times]
    boxplot = ax.boxplot(distributions, tick_labels=times, patch_artist=True, widths=0.65, showfliers=False)
    for patch in boxplot["boxes"]:
        patch.set_facecolor("#DCEAF2")
        patch.set_edgecolor(BLUE)
    for median in boxplot["medians"]:
        median.set_color(RED)
        median.set_linewidth(1.6)
    ax.set_ylim(0, 1.03)
    ax.set_xlabel("Embryonic time")
    ax.set_ylabel("K150-to-K40 purity")
    ax.set_title("How uniquely each K150 state maps to K40")
    ax.grid(axis="y")
    add_panel_label(ax, "E")

    ax = axes[1, 2]
    summary = (
        purity.groupby(purity["time"].astype(str))
        .agg(
            median_purity=("purity", "median"),
            fraction_purity_08=("purity", lambda values: float((values >= 0.8).mean())),
            median_entropy=("mapping_entropy_norm", "median"),
        )
        .reindex(times)
    )
    ax.bar(
        np.arange(len(times)),
        summary["fraction_purity_08"],
        color=GREEN,
        label="Fraction with purity >= 0.8",
    )
    ax.plot(np.arange(len(times)), summary["median_purity"], color=RED, marker="o", lw=2, label="Median purity")
    ax.plot(
        np.arange(len(times)),
        1 - summary["median_entropy"],
        color=BLUE,
        marker="s",
        lw=2,
        label="1 - median mapping entropy",
    )
    ax.set_xticks(np.arange(len(times)), times)
    ax.set_ylim(0, 1.03)
    ax.set_xlabel("Embryonic time")
    ax.set_ylabel("Hierarchy clarity")
    ax.set_title("Time-resolved hierarchy quality")
    ax.grid(axis="y")
    ax.legend(loc="lower left")
    add_panel_label(ax, "F")
    savefig(fig, path)


def plot_effective_spatial(effective: pd.DataFrame, state_spatial: pd.DataFrame, path: Path) -> None:
    """Figure 7: effective state usage and spatial morphology."""
    set_publication_style()
    times = sorted(effective["time"].astype(str).unique(), key=float)
    fig, axes = plt.subplots(2, 3, figsize=(15.6, 9.2), constrained_layout=True)
    fig.suptitle(
        "Figure 7 | Effective state usage and spatial morphology",
        color=NAVY,
        fontsize=16,
        weight="bold",
    )
    for ax, metric, ylabel, title, panel in (
        (axes[0, 0], "hardK", "Number of occupied states", "Hard state count", "A"),
        (axes[0, 1], "Keff", "Effective number of states", "Usage-entropy effective count", "B"),
    ):
        for layer, color, marker, name in (
            ("seurat_k150", BLUE, "o", "K150"),
            ("seurat_k40", RED, "s", "K40"),
        ):
            subset = effective[effective["layer"] == layer].copy()
            subset["time"] = subset["time"].astype(str)
            subset = subset.set_index("time").loc[times].reset_index()
            ax.plot(subset["time"], subset[metric], marker=marker, color=color, lw=2.1, label=name)
        ax.set_xlabel("Embryonic time")
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.grid(axis="y")
        ax.legend(loc="best")
        add_panel_label(ax, panel)

    ax = axes[0, 2]
    for layer, color, marker, nominal, name in (
        ("seurat_k150", BLUE, "o", 150, "K150"),
        ("seurat_k40", RED, "s", 40, "K40"),
    ):
        subset = effective[effective["layer"] == layer].copy()
        subset["time"] = subset["time"].astype(str)
        subset = subset.set_index("time").loc[times]
        ax.plot(times, subset["Keff"] / nominal, marker=marker, color=color, lw=2.1, label=name)
    ax.set_ylim(0, 1.02)
    ax.set_xlabel("Embryonic time")
    ax.set_ylabel("Keff / nominal K")
    ax.set_title("Fraction of nominal capacity actually used")
    ax.grid(axis="y")
    ax.legend(loc="best")
    add_panel_label(ax, "C")

    ax = axes[1, 0]
    k40 = effective[effective["layer"] == "seurat_k40"].copy()
    k40["time"] = k40["time"].astype(str)
    k40 = k40.set_index("time").loc[times]
    ax.bar(np.arange(len(times)), k40["max_usage"], color=GOLD, label="Largest state usage")
    ax.plot(np.arange(len(times)), [1 / 40] * len(times), color=NAVY, ls="--", lw=1.4, label="Uniform K40 = 1/40")
    ax.set_xticks(np.arange(len(times)), times)
    ax.set_xlabel("Embryonic time")
    ax.set_ylabel("Usage fraction")
    ax.set_title("K40 occupancy imbalance")
    ax.grid(axis="y")
    ax.legend(loc="best")
    add_panel_label(ax, "D")

    plotted = state_spatial[state_spatial["layer"] == "seurat_k40"].copy()
    ax = axes[1, 1]
    sizes = 18 + 110 * np.sqrt(plotted["spot_count"] / max(plotted["spot_count"].max(), 1))
    scatter = ax.scatter(
        plotted["boundary_ratio"],
        plotted["state_ei"],
        s=sizes,
        c=plotted["moran_i"],
        cmap=SEQUENTIAL,
        alpha=0.83,
        edgecolor="white",
        linewidth=0.3,
    )
    ax.set_xlabel("Boundary ratio")
    ax.set_ylabel("State-level EI (bit)")
    ax.set_title("State EI and spatial interiority")
    ax.grid(True)
    colorbar = fig.colorbar(scatter, ax=ax, fraction=0.047, pad=0.025)
    colorbar.set_label("Moran's I")
    add_panel_label(ax, "E")

    ax = axes[1, 2]
    for time in sorted(plotted["time"].astype(str).unique(), key=float):
        subset = plotted[plotted["time"].astype(str) == time]
        ax.scatter(
            subset["fragmentation"],
            subset["state_ei"],
            s=24 + 75 * np.sqrt(subset["spot_count"] / max(plotted["spot_count"].max(), 1)),
            color=TIME_COLORS.get(time, MUTED),
            alpha=0.75,
            edgecolor="white",
            linewidth=0.3,
            label=time,
        )
    ax.set_xlabel("Fragmentation index")
    ax.set_ylabel("State-level EI (bit)")
    ax.set_title("EI versus spatial fragmentation")
    ax.grid(True)
    ax.legend(title="Source time", loc="best", ncol=2)
    add_panel_label(ax, "F")
    savefig(fig, path)


def plot_mechanism(
    merged: pd.DataFrame,
    correlations: pd.DataFrame,
    coefficients: pd.DataFrame,
    path: Path,
) -> None:
    """Figure 8: exploratory GRN, CCI and spatial correlates of state EI."""
    set_publication_style()
    fig, axes = plt.subplots(2, 3, figsize=(15.6, 9.2), constrained_layout=True)
    fig.suptitle(
        "Figure 8 | GRN, CCI and spatial correlates of state-level EI",
        color=NAVY,
        fontsize=16,
        weight="bold",
    )
    source_time = merged["source_time"].astype(str)
    scatter_specs = (
        ("grn_concentration", "GRN concentration", "State EI vs GRN concentration", "A"),
        ("grn_top10_share", "Top-10 regulator weight share", "State EI vs dominant-regulator share", "B"),
        ("cci_out_log", "log1p CCI out-strength", "State EI vs outgoing communication", "C"),
    )
    for ax, (column, xlabel, title, panel) in zip(axes[0, :], scatter_specs):
        for time in sorted(source_time.unique(), key=float):
            subset = merged[source_time == time]
            ax.scatter(
                subset[column],
                subset["state_ei"],
                s=20 + 65 * subset["spot_count"] / max(merged["spot_count"].max(), 1),
                color=TIME_COLORS.get(time, MUTED),
                alpha=0.7,
                edgecolor="white",
                linewidth=0.25,
                label=time,
            )
        correlation = merged[[column, "state_ei"]].corr().iloc[0, 1]
        ax.set_xlabel(xlabel)
        ax.set_ylabel("State-level EI (bit)")
        ax.set_title(f"{title}\nPearson r = {correlation:.2f}")
        ax.grid(True)
        if panel == "A":
            ax.legend(title="Source time", loc="best", ncol=2)
        add_panel_label(ax, panel)

    ax = axes[1, 0]
    scatter = ax.scatter(
        merged["cci_out_entropy_norm"],
        merged["transition_entropy"],
        c=merged["grn_concentration"],
        cmap=SEQUENTIAL,
        s=35,
        alpha=0.78,
        edgecolor="white",
        linewidth=0.25,
    )
    correlation = merged[["cci_out_entropy_norm", "transition_entropy"]].corr().iloc[0, 1]
    ax.set_xlabel("Normalized CCI output entropy")
    ax.set_ylabel("Transition entropy H(Y|X) (bit)")
    ax.set_title(f"Communication dispersion vs future uncertainty\nPearson r = {correlation:.2f}")
    ax.grid(True)
    colorbar = fig.colorbar(scatter, ax=ax, fraction=0.047, pad=0.025)
    colorbar.set_label("GRN concentration")
    add_panel_label(ax, "D")

    ax = axes[1, 1]
    coefficients = coefficients.sort_values("coefficient")
    colors = [BLUE if value < 0 else RED for value in coefficients["coefficient"]]
    ax.barh(coefficients["predictor"], coefficients["coefficient"], color=colors)
    ax.axvline(0, color=MUTED, lw=0.9)
    ax.set_xlabel("Standardized coefficient")
    r_squared = float(coefficients["model_r2"].iloc[0]) if len(coefficients) else np.nan
    ax.set_title(f"Exploratory multivariable model | R2 = {r_squared:.2f}")
    ax.grid(axis="x")
    add_panel_label(ax, "E")

    ax = axes[1, 2]
    predictors = [
        "grn_concentration",
        "grn_top10_share",
        "cci_out_log",
        "cci_in_log",
        "cci_out_entropy_norm",
        "boundary_ratio",
        "moran_i",
        "spot_count",
    ]
    outcomes = ["state_ei", "transition_entropy"]
    heatmap = correlations.pivot(index="outcome", columns="predictor", values="pearson_r").reindex(
        index=outcomes,
        columns=predictors,
    )
    maximum = max(float(np.nanmax(np.abs(heatmap.to_numpy()))), 0.5)
    image = ax.imshow(
        heatmap.to_numpy(),
        cmap=DIVERGING,
        norm=TwoSlopeNorm(vcenter=0, vmin=-maximum, vmax=maximum),
        aspect="auto",
    )
    ax.set_xticks(
        np.arange(len(predictors)),
        [predictor.replace("_", " ") for predictor in predictors],
        rotation=38,
        ha="right",
    )
    ax.set_yticks(np.arange(len(outcomes)), ["State EI", "Transition entropy"])
    for row in range(heatmap.shape[0]):
        for column in range(heatmap.shape[1]):
            value = heatmap.iloc[row, column]
            if np.isfinite(value):
                ax.text(
                    column,
                    row,
                    f"{value:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.7,
                    color="white" if abs(value) > 0.34 else DARK,
                )
    ax.set_title("Pearson correlation map")
    colorbar = fig.colorbar(image, ax=ax, fraction=0.047, pad=0.025)
    colorbar.set_label("Pearson r")
    add_panel_label(ax, "F")
    savefig(fig, path)


def plot_fate_paths(paths: pd.DataFrame, path: Path) -> None:
    """Figure 9: four-time-point maximum-product macro fate paths."""
    set_publication_style()
    times = [column.removeprefix("state_") for column in paths.columns if column.startswith("state_")]
    times = sorted(times, key=float)
    if len(times) != 4:
        raise ValueError(f"Expected four state columns, got {times}")
    top = paths.sort_values(["source_ei", "path_probability"], ascending=False).head(12).copy()
    fig, axes = plt.subplots(2, 3, figsize=(15.6, 9.2), constrained_layout=True)
    fig.suptitle(
        "Figure 9 | Four-time-point macro fate paths",
        color=NAVY,
        fontsize=16,
        weight="bold",
    )

    ax = axes[0, 0]
    y_positions: dict[tuple[str, str], float] = {}
    for time_index, time in enumerate(times):
        states = list(dict.fromkeys(top[f"state_{time}"].astype(str).tolist()))
        positions = np.linspace(0.08, 0.92, len(states)) if len(states) > 1 else np.asarray([0.5])
        for state, y_value in zip(states, positions):
            y_positions[(time, state)] = float(y_value)
            ax.scatter(time_index, y_value, s=115, color="white", edgecolor=NAVY, linewidth=1.0, zorder=3)
            ax.text(
                time_index,
                y_value,
                state.replace("domain_", "D"),
                ha="center",
                va="center",
                fontsize=5.7,
                color=NAVY,
                zorder=4,
            )
    maximum_probability = max(float(top["path_probability"].max()), 1e-12)
    for _, row in top.iterrows():
        for left, right in zip(times[:-1], times[1:]):
            start = (times.index(left), y_positions[(left, str(row[f"state_{left}"]))])
            end = (times.index(right), y_positions[(right, str(row[f"state_{right}"]))])
            scaled = row["path_probability"] / maximum_probability
            ax.plot(
                [start[0], end[0]],
                [start[1], end[1]],
                color=RED,
                alpha=0.18 + 0.58 * scaled,
                lw=0.6 + 3.8 * scaled,
                zorder=1,
            )
    ax.set_xlim(-0.2, len(times) - 0.8)
    ax.set_ylim(0, 1)
    ax.set_xticks(range(len(times)), times)
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title("Representative high-EI fate graph")
    add_panel_label(ax, "A")

    ax = axes[0, 1]
    ranked = paths.sort_values("path_probability", ascending=False).head(10).copy()
    labels = [
        f"{source.replace('domain_', 'D')} to {target.replace('domain_', 'D')}"
        for source, target in zip(ranked[f"state_{times[0]}"], ranked[f"state_{times[-1]}"])
    ]
    ax.barh(np.arange(len(ranked))[::-1], ranked["path_probability"].to_numpy()[::-1], color=RED)
    ax.set_yticks(np.arange(len(ranked))[::-1], labels[::-1], fontsize=6.5)
    ax.set_xlabel("Maximum-product path probability")
    ax.set_title("Top complete paths")
    ax.grid(axis="x")
    add_panel_label(ax, "B")

    ax = axes[0, 2]
    ax.scatter(
        paths["first_branch_entropy"],
        paths["source_ei"],
        c=paths["path_probability"],
        cmap=SEQUENTIAL,
        s=55,
        edgecolor="white",
        linewidth=0.3,
    )
    ax.set_xlabel("First-step branch entropy (bit)")
    ax.set_ylabel("Source state EI (bit)")
    ax.set_title("High EI and branch concentration")
    ax.grid(True)
    add_panel_label(ax, "C")

    ax = axes[1, 0]
    scatter = ax.scatter(
        paths["source_ei"],
        paths["path_probability"],
        c=paths["first_branch_entropy"],
        cmap=SEQUENTIAL,
        s=55,
        edgecolor="white",
        linewidth=0.3,
    )
    ax.set_xlabel("Source state EI (bit)")
    ax.set_ylabel("Maximum-product path probability")
    ax.set_title("Source information vs path dominance")
    ax.grid(True)
    colorbar = fig.colorbar(scatter, ax=ax, fraction=0.047, pad=0.025)
    colorbar.set_label("First-step branch entropy")
    add_panel_label(ax, "D")

    ax = axes[1, 1]
    scatter = ax.scatter(
        paths["first_branch_entropy"],
        paths["endpoint_entropy"],
        c=paths["source_ei"],
        cmap=SEQUENTIAL,
        s=55,
        edgecolor="white",
        linewidth=0.3,
    )
    ax.set_xlabel("First-step branch entropy (bit)")
    ax.set_ylabel(f"Endpoint entropy at {times[-1]} (bit)")
    ax.set_title("Local branching vs terminal uncertainty")
    ax.grid(True)
    colorbar = fig.colorbar(scatter, ax=ax, fraction=0.047, pad=0.025)
    colorbar.set_label("Source state EI")
    add_panel_label(ax, "E")

    ax = axes[1, 2]
    endpoints = (
        paths.groupby(f"state_{times[-1]}")
        .agg(
            path_count=(f"state_{times[0]}", "size"),
            total_probability=("path_probability", "sum"),
        )
        .sort_values("total_probability", ascending=False)
        .head(10)
    )
    ax.bar(np.arange(len(endpoints)), endpoints["total_probability"], color=GOLD)
    ax.set_xticks(
        np.arange(len(endpoints)),
        [str(state).replace("domain_", "D") for state in endpoints.index],
        rotation=35,
        ha="right",
    )
    ax.set_ylabel("Summed max-path probability")
    ax.set_title("Most frequent terminal states")
    ax.grid(axis="y")
    add_panel_label(ax, "F")
    savefig(fig, path)


def plot_perturbation(curves: pd.DataFrame, path: Path) -> None:
    """Figure 10: Pij row-homogenization dose response."""
    set_publication_style()
    pairs = list(dict.fromkeys(curves["time_pair"].astype(str).tolist()))[:3]
    if len(pairs) != 3:
        raise ValueError(f"Expected three adjacent time pairs, got {pairs}")
    fig, axes = plt.subplots(2, 3, figsize=(15.6, 9.2), constrained_layout=True)
    fig.suptitle(
        "Figure 10 | Pij row-homogenization perturbation dose-response",
        color=NAVY,
        fontsize=16,
        weight="bold",
    )
    target_order = ["high_state_ei", "high_cci_out", "high_grn_concentration", "matched_random"]
    for index, time_pair in enumerate(pairs):
        ax = axes[0, index]
        subset = curves[curves["time_pair"] == time_pair]
        for target in target_order:
            current = subset[subset["target"] == target].sort_values("dose")
            ax.plot(
                current["dose"],
                current["ei_drop_mean"],
                marker="o",
                ms=3.3,
                lw=1.9,
                color=TARGET_COLORS[target],
                label=TARGET_LABELS[target],
            )
            if target == "matched_random":
                ax.fill_between(
                    current["dose"],
                    current["ei_drop_low"],
                    current["ei_drop_high"],
                    color=TARGET_COLORS[target],
                    alpha=0.16,
                )
        ax.set_xlabel("Perturbation dose")
        ax.set_ylabel("EI drop (bit)")
        ax.set_title(time_pair)
        ax.grid(True)
        if index == 2:
            ax.legend(loc="center left", bbox_to_anchor=(1.0, 0.5))
        add_panel_label(ax, chr(ord("A") + index))

    full_dose = curves[np.isclose(curves["dose"], 1.0)].copy()
    ax = axes[1, 0]
    summary = full_dose.groupby("target")["ei_drop_mean"].agg(["mean", "std"]).reindex(target_order)
    bars = ax.bar(
        np.arange(len(target_order)),
        summary["mean"],
        yerr=summary["std"].fillna(0),
        capsize=4,
        color=[TARGET_COLORS[target] for target in target_order],
    )
    bar_labels(ax, bars)
    ax.set_xticks(
        np.arange(len(target_order)),
        [TARGET_LABELS[target] for target in target_order],
        rotation=28,
        ha="right",
    )
    ax.set_ylabel("Mean full-dose EI drop (bit)")
    ax.set_title("Average sensitivity across time pairs")
    ax.grid(axis="y")
    add_panel_label(ax, "D")

    ax = axes[1, 1]
    random_full = full_dose[full_dose["target"] == "matched_random"].set_index("time_pair")["ei_drop_mean"]
    width = 0.24
    x_values = np.arange(len(pairs))
    targeted = ["high_state_ei", "high_cci_out", "high_grn_concentration"]
    for index, target in enumerate(targeted):
        values = (
            full_dose[full_dose["target"] == target].set_index("time_pair")["ei_drop_mean"].reindex(pairs)
            - random_full.reindex(pairs)
        )
        ax.bar(
            x_values + (index - 1) * width,
            values,
            width=width,
            color=TARGET_COLORS[target],
            label=TARGET_LABELS[target],
        )
    ax.axhline(0, color=MUTED, lw=0.9)
    ax.set_xticks(x_values, pairs, rotation=25, ha="right")
    ax.set_ylabel("Targeted drop - matched-random drop (bit)")
    ax.set_title("Perturbation specificity at full dose")
    ax.grid(axis="y")
    ax.legend(loc="best")
    add_panel_label(ax, "E")

    ax = axes[1, 2]
    auc_rows = []
    for (time_pair, target), group in curves.groupby(["time_pair", "target"]):
        group = group.sort_values("dose")
        auc_rows.append(
            {
                "time_pair": time_pair,
                "target": target,
                "auc": float(np.trapz(group["ei_drop_mean"].to_numpy(), group["dose"].to_numpy())),
            }
        )
    auc = pd.DataFrame(auc_rows)
    width = 0.19
    for index, target in enumerate(target_order):
        values = auc[auc["target"] == target].set_index("time_pair")["auc"].reindex(pairs)
        ax.bar(
            x_values + (index - 1.5) * width,
            values,
            width=width,
            color=TARGET_COLORS[target],
            label=TARGET_LABELS[target],
        )
    ax.set_xticks(x_values, pairs, rotation=25, ha="right")
    ax.set_ylabel("Area under EI-drop curve")
    ax.set_title("Dose-integrated perturbation effect")
    ax.grid(axis="y")
    add_panel_label(ax, "F")
    savefig(fig, path)
